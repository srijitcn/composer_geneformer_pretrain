"""Log streaming utilities for CLI workload monitoring.

This module provides log streaming capabilities for monitoring
serverless GPU workloads via the CLI, adapted from Skyrun's log streaming.
"""

import collections
import contextlib
import enum
import logging
import os
import shutil
import tempfile
import threading
import time
from typing import Callable, Dict, Optional, Tuple, List
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys

from rich.console import Console
from rich.spinner import Spinner
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from cli.jobs_api_client import JobsApiClient

log = logging.getLogger(__name__)
logging.getLogger("databricks.sdk").setLevel(logging.WARNING)

# How often to check for new logs
RETRY_CHECK_INTERVAL_SECONDS: int = 3
# How often to check to see if the MLflow run ID has changed (due to a retry)
RETRY_CHECK_INTERVAL_ITERATIONS: int = 5


class LogPathFormat(enum.Enum):
    """Log path format types."""

    WITH_ATTEMPT = "with_attempt"  # logs/attempt_X/node_Y/...
    WITHOUT_ATTEMPT = "without_attempt"  # logs/node_Y/...


# Cache for discovered log path format: {run_id: format_type}
# Format is deployment-specific, not attempt-specific
_LOG_PATH_FORMAT_CACHE: Dict[str, LogPathFormat] = {}
# Lock to protect cache access in multi-threaded scenarios
_LOG_PATH_FORMAT_CACHE_LOCK = threading.Lock()


# TODO: These should be imported and centralized with Skyrun.
# Terminal states where job monitoring should stop
TERMINAL_STATES = {"TERMINATED", "SKIPPED", "INTERNAL_ERROR"}
TERMINAL_RESULT_STATES = {"SUCCESS", "FAILED", "CANCELED"}


# TODO: break this out into a common utils module
def configure_mlflow_for_current_profile() -> None:
    import mlflow

    profile = os.getenv("DATABRICKS_CONFIG_PROFILE")
    if profile:
        # Use that profile from ~/.databrickscfg
        tracking_uri = f"databricks://{profile}"
    else:
        # Fall back to DEFAULT profile
        tracking_uri = "databricks"

    mlflow.set_tracking_uri(tracking_uri)


@contextlib.contextmanager
def _patch_env(**environs: str):
    """Context manager that patches os.environ with environs.

    The original os.environ values are restored at the end.

    Args:
        **environs: Environment variables to set temporarily
    """
    # Capture the original environ values
    original_environs = {k: os.environ.get(k) for k in environs}

    # Patch the environment
    for k, v in environs.items():
        os.environ[k] = v
    try:
        yield
    finally:
        # Restore the original environ values
        for k, v in original_environs.items():
            if v is None:
                if k in os.environ:
                    del os.environ[k]
            else:
                os.environ[k] = v


def _try_download_artifact(run_id: str, artifact_path: str, dst_path: str) -> Optional[str]:
    """Try to download an artifact and return local path if successful.

    Args:
        run_id: The MLflow run ID containing the artifact
        artifact_path: Path to the artifact within the run
        dst_path: Local directory to download artifacts to

    Returns:
        str: Local file path if download succeeded, None otherwise
    """
    try:
        import mlflow

        # Suppress tqdm progress bar for all callers — redirect_stdout/stderr are NOT thread-safe
        with _patch_env(MLFLOW_ENABLE_ARTIFACTS_PROGRESS_BAR="false"):
            profile = os.getenv("DATABRICKS_CONFIG_PROFILE")
            tracking_uri = f"databricks://{profile}" if profile else "databricks"
            mlflow_client = mlflow.MlflowClient(tracking_uri=tracking_uri)
            mlflow_client.download_artifacts(run_id=run_id, path=artifact_path, dst_path=dst_path)

        local_file_path = os.path.join(dst_path, artifact_path)
        if os.path.isfile(local_file_path):
            return local_file_path
    except Exception as e:
        log.debug(f"Failed to download artifact from {artifact_path}: {e}")

    return None


def print_new_logs(
    run_id: str,
    artifact_path: str,
    dst_path: str,
    last_position: int,
    line_callback: Optional[Callable[[str], None]] = None,
) -> int:
    """Fetch and print new content from a log artifact in MLflow.

    Modeled after Skyrun's print_new_logs function.

    Downloads the log file artifact from MLflow and prints any new content
    since the last read position.

    Args:
        run_id: The MLflow run ID containing the artifact
        artifact_path: Path to the log file artifact within the run (includes attempt if applicable)
        dst_path: Local directory to download artifacts to
        last_position: The last read byte position in the file
        line_callback: Optional callback invoked for each line instead of printing to stdout.
            When provided (e.g. for JSON mode), the callback receives each log line (without
            trailing newline) and is responsible for output.

    Returns:
        int: The updated last read byte position after reading new content
    """
    local_file_path = _try_download_artifact(run_id, artifact_path, dst_path)

    if local_file_path is None:
        return last_position

    with open(local_file_path, "r") as file:
        # Move to the last read position
        file.seek(last_position)
        # Read any new content
        new_content = file.read()
        if new_content:
            if line_callback is not None:
                for line in new_content.splitlines():
                    line_callback(line)
            else:
                print(new_content, end="", flush=True)
            # Update the last_position to the current file position
            last_position = file.tell()

    return last_position


def _construct_log_path(node_id: int, attempt: int, use_attempt_prefix: bool) -> str:
    """Construct log artifact path with or without attempt prefix.

    Args:
        node_id: Node ID
        attempt: Attempt number
        use_attempt_prefix: If True, use logs/attempt_X/node_Y format
                           If False, use logs/node_Y format

    Returns:
        Log artifacts path string
    """
    if use_attempt_prefix:
        return f"logs/attempt_{attempt}/node_{node_id}"
    else:
        return f"logs/node_{node_id}"


def _discover_log_path_format(
    mlflow_run_id: str, node_id: int, attempt: int, timeout_seconds: int = 900
) -> LogPathFormat:
    """Discover which log path format exists by polling list_artifacts.

    Polls every 3 seconds until logs appear or timeout is reached. Tries paths in order:
    1. Old format (without attempt): logs/node_X/...
    2. New format (with attempt): logs/attempt_Y/node_X/...

    Args:
        mlflow_run_id: MLflow run ID
        node_id: Node ID
        attempt: Attempt number
        timeout_seconds: Maximum time to wait for logs to appear (default: 300)

    Returns:
        LogPathFormat enum (WITHOUT_ATTEMPT or WITH_ATTEMPT)

    Raises:
        TimeoutError: If logs are not found within timeout_seconds
    """
    import mlflow

    start_time = time.time()
    while time.time() - start_time < timeout_seconds:
        try:
            # List artifacts under logs/ directory (cheap API call, no download)
            artifacts = mlflow.artifacts.list_artifacts(run_id=mlflow_run_id, artifact_path="logs")

            # Check if old format exists (logs/node_X)
            old_format_path = f"logs/node_{node_id}"
            for artifact in artifacts:
                if artifact.path == old_format_path:
                    log.debug(f"Discovered old format (without attempt) for MLflow run {mlflow_run_id}")
                    return LogPathFormat.WITHOUT_ATTEMPT

            # Check if new format exists (logs/attempt_Y)
            new_format_path = f"logs/attempt_{attempt}"
            for artifact in artifacts:
                if artifact.path == new_format_path:
                    log.debug(f"Discovered new format (with attempt) for MLflow run {mlflow_run_id}")
                    return LogPathFormat.WITH_ATTEMPT

            # Neither format found - logs not ready yet, wait and retry
            log.debug(f"Logs not ready yet for MLflow run {mlflow_run_id}, retrying in 3s")

        except Exception as e:
            log.debug(f"Failed to list artifacts for discovery: {e}, retrying in 3s")

        # Wait before retrying
        time.sleep(RETRY_CHECK_INTERVAL_SECONDS)

    # Timeout reached
    raise TimeoutError(f"Timed out after {timeout_seconds}s waiting for logs to appear for MLflow run {mlflow_run_id}")


def _get_mlflow_run_id_and_log_path(
    client: JobsApiClient,
    run_id: str,
    node: int = 0,
    local_rank: int = 0,
    attempt: int = 0,
    task_attempt: Optional[int] = None,
) -> tuple[str | None, str | None, str | None]:
    """Extract MLflow run ID and log path from job output.

    Supports both log path formats with dynamic discovery:
    - Old format (tried first): logs/node_Y/...
    - New format: logs/attempt_X/node_Y/...

    Discovery polls until format is found. Format is deployment-specific (cached by run_id).

    Args:
        client: JobsApiClient instance
        run_id: The job run ID
        node: The node number to fetch logs from (default: 0)
        local_rank: The local rank on the node to fetch logs from (default: 0)
        attempt: Retry attempt number used for log path construction (default: 0)
        task_attempt: Optional attempt number to select a specific retry's task output.
            If None, uses the latest task. If specified, fetches the task with the
            matching attempt_number from the Jobs API.

    Returns:
        Tuple of (mlflow_run_id, log_artifacts_path, log_file_name) or (None, None, None) if not available

        Log structure:
        - Node X, local rank 0: logs/[attempt_Y/]node_X/logs-0.chunk.txt
        - Node X, local rank 1-7: logs/[attempt_Y/]node_X/gpu_Z-0.chunk.txt
    """
    try:
        run_output = client.get_run_output(run_id, task_attempt=task_attempt)
        gen_ai_output = run_output.get("gen_ai_compute_output", {})
        run_info = gen_ai_output.get("run_info", {})
        mlflow_run_id = run_info.get("mlflow_run_id")

        if mlflow_run_id:
            # Use node and local_rank from parameters
            node_id = node

            # Determine log file name based on local rank
            if local_rank == 0:
                log_file_name = "logs-0.chunk.txt"
            else:
                log_file_name = f"gpu_{local_rank}-0.chunk.txt"

            # Thread-safe cache lookup with double-checked locking
            # First check without lock (fast path for cache hits)
            cached_format = _LOG_PATH_FORMAT_CACHE.get(mlflow_run_id)

            if cached_format:
                # Use cached format
                use_attempt_prefix = cached_format == LogPathFormat.WITH_ATTEMPT
                log_artifacts_path = _construct_log_path(node_id, attempt, use_attempt_prefix)
                log.debug(
                    f"Using cached format '{cached_format.value}' for MLflow run {mlflow_run_id}, "
                    f"log path: {log_artifacts_path}/{log_file_name}"
                )
                return mlflow_run_id, log_artifacts_path, log_file_name

            # Format not cached - acquire lock to ensure only one thread performs discovery
            with _LOG_PATH_FORMAT_CACHE_LOCK:
                # Double-check: another thread may have completed discovery while we waited for lock
                cached_format = _LOG_PATH_FORMAT_CACHE.get(mlflow_run_id)
                if cached_format:
                    # Use format discovered by another thread
                    use_attempt_prefix = cached_format == LogPathFormat.WITH_ATTEMPT
                    log_artifacts_path = _construct_log_path(node_id, attempt, use_attempt_prefix)
                    log.debug(
                        f"Using cached format '{cached_format.value}' for MLflow run {mlflow_run_id} "
                        f"(discovered by another thread)"
                    )
                    return mlflow_run_id, log_artifacts_path, log_file_name

                # Still not cached - this thread performs discovery
                discovered_format = _discover_log_path_format(mlflow_run_id, node_id, attempt)

                # Cache the discovered format (still holding lock)
                _LOG_PATH_FORMAT_CACHE[mlflow_run_id] = discovered_format
                log.debug(f"Cached format '{discovered_format.value}' for MLflow run {mlflow_run_id}")

                # Construct path based on discovered format
                use_attempt_prefix = discovered_format == LogPathFormat.WITH_ATTEMPT
                log_artifacts_path = _construct_log_path(node_id, attempt, use_attempt_prefix)

                return mlflow_run_id, log_artifacts_path, log_file_name

    except Exception as e:
        log.debug(f"MLflow run ID not yet available: {e}")

    return None, None, None


def extract_last_n_lines(log_file_path: str, last_n_lines: int = 200) -> Optional[List[str]]:
    """Extract the last N lines of a log file.

    Args:
        log_file_path: Path to log file
        last_n_lines: Number of lines from end of file to scan (default: 500)

    Returns:
        Last N lines of the log file.
        Returns None if the log file does not exist.
    """
    if not os.path.isfile(log_file_path):
        return None

    # Read last N lines efficiently using deque
    try:
        with open(log_file_path, "r", encoding="utf-8", errors="replace") as f:
            last_lines = list(collections.deque(f, maxlen=last_n_lines))
    except Exception as e:
        log.error(f"Failed to read log file {log_file_path}: {e}")
        return None

    return last_lines


def _download_single_node_log(
    node_id: int, run_id: str, dst_path: str, attempt: int = 0, task_attempt: Optional[int] = None
) -> Tuple[int, Optional[str]]:
    """Helper function to download logs from a single node.

    Args:
        node_id: Node ID to download logs from
        run_id: Job run ID
        dst_path: Local directory to download logs to
        attempt: Retry attempt number for log path construction (default: 0)
        task_attempt: Optional attempt number to select a specific retry's task output.

    Returns:
        Tuple of (node_id, local_file_path) or (node_id, None) if download failed
    """
    client = JobsApiClient()

    try:
        # Get MLflow run ID and log path for this node (local rank 0 only)
        mlflow_run_id, log_artifacts_path, log_file_name = _get_mlflow_run_id_and_log_path(
            client,
            run_id,
            node=node_id,
            local_rank=0,
            attempt=attempt,
            task_attempt=task_attempt,
        )

        if not mlflow_run_id or not log_artifacts_path or not log_file_name:
            log.debug(f"No MLflow run ID found for node {node_id}, skipping")
            return (node_id, None)

        # Download the log artifact
        artifact_path = os.path.join(log_artifacts_path, log_file_name)
        local_file_path = _try_download_artifact(mlflow_run_id, artifact_path, dst_path)

        if local_file_path:
            log.debug(f"Downloaded logs for node {node_id}")
            return (node_id, local_file_path)
        else:
            log.debug(f"Log file not found for node {node_id}")
            return (node_id, None)

    except Exception as e:
        log.debug(f"Error processing node {node_id}: {e}")
        return (node_id, None)


def download_all_node_logs(
    run_id: str,
    num_nodes: int,
    dst_path: str,
    max_workers: int = 8,
    attempt: int = 0,
    task_attempt: Optional[int] = None,
) -> Dict[int, str]:
    """Download logs from all nodes in parallel.

    Args:
        run_id: Job run ID
        num_nodes: Total number of nodes in the run
        dst_path: Local directory to download logs to
        max_workers: Maximum number of concurrent downloads
        attempt: Retry attempt number for log path construction (default: 0)
        task_attempt: Optional attempt number to select a specific retry's task output.

    Returns:
        Dict mapping node_id -> local_log_file_path
        Only includes nodes where logs were successfully downloaded
    """
    configure_mlflow_for_current_profile()

    log.debug(f"Downloading logs from {num_nodes} nodes (max {max_workers} concurrent)...")

    node_logs = {}
    completed = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_download_single_node_log, node_id, run_id, dst_path, attempt, task_attempt): node_id
            for node_id in range(num_nodes)
        }

        for future in as_completed(futures):
            node_id, local_file_path = future.result()
            completed += 1
            if local_file_path:
                node_logs[node_id] = local_file_path
                log.info(f"Downloaded node {node_id} ({completed}/{num_nodes})")
            else:
                log.info(f"Skipped node {node_id} ({completed}/{num_nodes})")

    log.debug(f"Successfully downloaded logs from {len(node_logs)} out of {num_nodes} nodes")
    return node_logs


def _get_key() -> str:
    """Read a single keypress from stdin.

    Returns:
        str: The key pressed (e.g., 'q', '\x1b[C' for right arrow)
    """
    import sys
    import tty
    import termios

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
        # Handle arrow keys (escape sequences)
        if ch == "\x1b":
            ch += sys.stdin.read(2)
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def _display_single_node_error(
    console: Console, node_id: int, lines: List[str], current_idx: int, total_nodes: int
) -> None:
    """Display logs from a single node with navigation controls.

    Args:
        console: Rich console for output
        node_id: Node ID
        lines: Log lines to display
        current_idx: Current index in the list of nodes (0-indexed)
        total_nodes: Total number of nodes
    """

    # Clear screen
    console.clear()

    # Show navigation info at top
    nav_text = Text()
    nav_text.append(f"Node {node_id} ", style="bold yellow")
    nav_text.append(f"[{current_idx + 1}/{total_nodes}]\n", style="dim")
    nav_text.append("Navigation: ", style="bold cyan")
    nav_text.append("← Prev  ", style="cyan")
    nav_text.append("→ Next  ", style="cyan")
    nav_text.append("Q Quit\n\n", style="cyan")
    console.print(nav_text)

    # Format header
    header = f"Node {node_id} Logs"

    # Format error content
    error_text = Text()
    for line in lines:
        # Highlight lines with key error keywords
        if any(keyword in line.lower() for keyword in ["error", "failed", "timeout", "exception", "traceback"]):
            error_text.append(line.rstrip("\n") + "\n", style="bold red")
        else:
            error_text.append(line.rstrip("\n") + "\n", style="red")

    console.print(Panel(error_text, title=header, border_style="red", expand=False))

    # Show navigation info at bottom as well
    console.print()
    bottom_nav_text = Text()
    bottom_nav_text.append(f"Node {node_id} ", style="bold yellow")
    bottom_nav_text.append(f"[{current_idx + 1}/{total_nodes}]\n", style="dim")
    bottom_nav_text.append("Navigation: ", style="bold cyan")
    bottom_nav_text.append("← Prev  ", style="cyan")
    bottom_nav_text.append("→ Next  ", style="cyan")
    bottom_nav_text.append("Q Quit", style="cyan")
    console.print(bottom_nav_text)


def display_debug_logs(node_logs: Dict[int, str], last_n_lines: int = 200) -> None:
    """Display debug logs with interactive navigation.

    Shows the last N lines from each node one at a time with arrow key navigation.

    Args:
        node_logs: Dict mapping node_id -> local log file path
        last_n_lines: Number of lines from end of each log to display (default: 200)
    """

    console = Console()

    console.print(f"\n[bold cyan]Analyzing last {last_n_lines} lines from each node...[/bold cyan]\n")

    # Collect the last N lines from each node
    all_node_logs: Dict[int, Optional[List[str]]] = {}

    for node_id in sorted(node_logs.keys()):
        log_file_path = node_logs[node_id]
        lines = extract_last_n_lines(log_file_path, last_n_lines=last_n_lines)
        all_node_logs[node_id] = lines

    # Check if we can use interactive mode
    if sys.stdin.isatty() and sys.stdout.isatty():
        console.print("[dim]Starting interactive viewer... (use arrow keys to navigate)[/dim]\n")
        time.sleep(1)

        # Interactive navigation
        node_ids = sorted(all_node_logs.keys())
        current_idx = 0

        try:
            while True:
                node_id = node_ids[current_idx]
                lines = all_node_logs[node_id]

                _display_single_node_error(console, node_id, lines, current_idx, len(node_ids))

                # Get user input
                key = _get_key()

                if key == "\x1b[C":  # Right arrow
                    current_idx = (current_idx + 1) % len(node_ids)
                elif key == "\x1b[D":  # Left arrow
                    current_idx = (current_idx - 1) % len(node_ids)
                elif key in ("q", "Q"):
                    console.clear()
                    console.print("\n[dim]Exited interactive viewer[/dim]\n")
                    break

        except KeyboardInterrupt:
            console.clear()
            console.print("\n[dim]Exited interactive viewer[/dim]\n")
    else:
        # Non-interactive fallback: display all logs
        console.print("[bold cyan]Node Logs:[/bold cyan]\n")

        for node_id in sorted(all_node_logs.keys()):
            lines = all_node_logs[node_id]

            if lines is None or len(lines) == 0:
                continue

            header = f"Node {node_id} - Last {last_n_lines} lines"

            log_text = Text()
            for line in lines:
                if any(keyword in line.lower() for keyword in ["error", "failed", "timeout", "exception"]):
                    log_text.append(line.rstrip("\n") + "\n", style="bold red")
                else:
                    log_text.append(line.rstrip("\n") + "\n", style="white")

            console.print(Panel(log_text, title=header, border_style="cyan", expand=False))
            console.print()

    console.print(f"\n[dim]Note: Analysis limited to last {last_n_lines} lines per node[/dim]")


def print_all_logs(
    run_id: str,
    node: int = 0,
    local_rank: int = 0,
    num_lines: int | None = None,
    attempt: int = 0,
    json_output: bool = False,
    task_attempt: Optional[int] = None,
) -> bool:
    """Print all logs for a completed run.

    This function fetches and prints the complete logs from a finished job run.
    It does not poll or stream - it's designed for jobs that have already completed.

    Args:
        run_id: The job run ID to get logs from
        node: The node number to fetch logs from (default: 0)
        local_rank: The local rank on the node to fetch logs from (default: 0)
        num_lines: Optional number of lines to print from the end (if None, prints all logs)
        attempt: Retry attempt number for log path construction (default: 0)
        json_output: When True, emit each log line as a JSONL event instead of raw stdout.
        task_attempt: Optional attempt number to select a specific retry's task output.
            If None, uses the latest task.

    Returns:
        bool: True if logs were successfully retrieved, False otherwise
    """
    client = JobsApiClient()
    tmpdir = None

    configure_mlflow_for_current_profile()

    # Build a line callback for JSON mode so each log line becomes a JSONL event.
    line_callback: Optional[Callable[[str], None]] = None
    if json_output:
        from cli.json_output import print_jsonl_event

        def line_callback(line: str) -> None:
            print_jsonl_event("LOG", node=node, line=line)

    try:
        tmpdir = tempfile.mkdtemp()

        # Get the status to verify it's a valid run
        try:
            _ = client.get_workload_status(run_id)
        except Exception as e:
            log.error(f"Failed to get job status: {e}")
            return False

        # Get MLflow run ID and log path (with attempt)
        mlflow_run_id, log_artifacts_path, log_file_name = _get_mlflow_run_id_and_log_path(
            client, run_id, node=node, local_rank=local_rank, attempt=attempt, task_attempt=task_attempt
        )

        if not mlflow_run_id or not log_artifacts_path or not log_file_name:
            log.warning(f"No logs available for run {run_id}, node {node}, local rank {local_rank} yet")
            return False

        artifact_path = os.path.join(log_artifacts_path, log_file_name)

        if num_lines is not None:
            # Download logs and print only last N lines
            try:
                log.info(f"Printing the last {num_lines} lines of logs...")

                local_file_path = _try_download_artifact(mlflow_run_id, artifact_path, tmpdir)

                if local_file_path and os.path.isfile(local_file_path):
                    with open(local_file_path, "r") as file:
                        lines = file.readlines()
                        # Print last N lines
                        for line in lines[-num_lines:]:
                            if line_callback is not None:
                                line_callback(line.rstrip("\n"))
                            else:
                                print(line, end="", flush=True)
                else:
                    log.warning("Log file not found")
                    return False
            except Exception as e:
                log.error(f"Failed to download and print logs: {e}")
                return False
        else:
            # Print all logs from the beginning
            print_new_logs(
                run_id=mlflow_run_id,
                artifact_path=artifact_path,
                dst_path=tmpdir,
                last_position=0,
                line_callback=line_callback,
            )

        return True

    finally:
        if tmpdir is not None:
            shutil.rmtree(tmpdir, ignore_errors=True)


def _match_fatal_pattern(line: str) -> bool:
    """Return True if the line matches a FATAL pattern (warrants ALERT event)."""
    from cli.error_detection import FATAL_PATTERNS

    return any(pat.search(line) for pat in FATAL_PATTERNS)


def _match_warning_pattern(line: str) -> bool:
    """Return True if the line matches a WARNING pattern (warrants ERROR event)."""
    from cli.error_detection import WARNING_PATTERNS

    return any(pat.search(line) for pat in WARNING_PATTERNS)


def monitor_and_stream_logs(
    run_id: str,
    node: int = 0,
    local_rank: int = 0,
    attempt: int = 0,
    json_output: bool = False,
    errors_only: bool = False,
    on_status_change: Optional[Callable[[str, Optional[str]], None]] = None,
    line_accumulator: Optional[List[str]] = None,
    metric_keys: Optional[List[str]] = None,
    metrics_interval_minutes: int = 1,
    no_default_metrics: bool = False,
    task_attempt: Optional[int] = None,
) -> bool:
    """Monitor job status and stream logs in real-time.

    Modeled after Skyrun's monitor_and_log_remote_execution function.

    Continuously polls the job status and streams logs to stdout once
    the job starts running. Continues until the job reaches a terminal state.

    In JSON mode emits a JSONL stream per line:
      LOG    — raw log line (suppressed when errors_only=True)
      ERROR  — log line matching error/fatal keywords
      ALERT  — line matching a FATAL pattern (OOM, NCCL timeout, etc.) warranting
               immediate agent action; always emitted regardless of errors_only.
      METRIC — periodic training metrics snapshot (loss, GPU util, GPU memory)

    Args:
        run_id: The job run ID to monitor
        node: The node number to fetch logs from (default: 0)
        local_rank: The local rank on the node to fetch logs from (default: 0)
        attempt: Retry attempt number for log path construction (default: 0)
        json_output: When True, emit each log line as a JSONL event instead of raw stdout.
        errors_only: When True, suppress raw LOG events; only emit ERROR and ALERT events.
        on_status_change: Optional callback invoked on every lifecycle state change.
            Called with (current_display_status, previous_display_status | None).
        line_accumulator: When provided, every raw log line is appended here
            regardless of errors_only filtering. Should be a deque(maxlen=N) so
            only the trailing N lines are kept — error detection at job end runs
            on this tail, returning newest errors first.
        metric_keys: Additional MLflow metric keys to include beyond auto-detected defaults.
        metrics_interval_minutes: How often to emit METRIC events (default: 1 minute).
        no_default_metrics: When True, suppress auto-detected loss/gpu metrics; only
            emit keys from metric_keys.
        task_attempt: Optional attempt number to select a specific retry's task output.
            If None, uses the latest task.

    Returns:
        bool: True if job completed successfully, False otherwise
    """
    client = JobsApiClient()
    tmpdir: str = ""
    mlflow_run_id: str | None = None
    full_log_file_path: str | None = None
    last_position = 0
    previous_state: str | None = None
    spinner_active = False
    console = Console()
    retry_check_counter = 0
    success: bool = False

    # Metric polling state
    last_metrics_emit_time: float = 0.0
    # Accumulated default keys; starts empty and grows as new metric types appear.
    # GPU metrics often lag training loss by several minutes, so we re-resolve each
    # interval and union the results rather than locking in on first discovery.
    resolved_default_keys: List[str] = []
    metrics_interval_seconds = metrics_interval_minutes * 60

    configure_mlflow_for_current_profile()

    from cli.json_output import print_jsonl_event
    from cli.mlflow_metrics import get_mlflow_client, resolve_and_fetch_metrics

    mlflow_client = get_mlflow_client()

    # Build the line callback based on output mode and filtering options.
    # In JSON mode, ALERT events are always emitted for FATAL patterns regardless of errors_only,
    # giving the agent an immediate actionable signal to cancel and relaunch.
    line_callback: Optional[Callable[[str], None]] = None
    if json_output:
        if errors_only:

            def line_callback(line: str) -> None:
                if line_accumulator is not None:
                    line_accumulator.append(line)
                if _match_fatal_pattern(line):
                    print_jsonl_event("ALERT", node=node, line=line)
                elif _match_warning_pattern(line):
                    print_jsonl_event("ERROR", node=node, line=line)

        else:

            def line_callback(line: str) -> None:
                if line_accumulator is not None:
                    line_accumulator.append(line)
                if _match_fatal_pattern(line):
                    print_jsonl_event("ALERT", node=node, line=line)
                print_jsonl_event("LOG", node=node, line=line)

    elif errors_only:

        def line_callback(line: str) -> None:
            if line_accumulator is not None:
                line_accumulator.append(line)
            if _match_warning_pattern(line):
                print(line, flush=True)

    elif line_accumulator is not None:

        def line_callback(line: str) -> None:
            line_accumulator.append(line)
            print(line, flush=True)

    try:
        tmpdir = tempfile.mkdtemp()

        # Create spinner that shows while waiting for logs to start
        spinner = Spinner("dots", text=f"Waiting for run to start (node {node}, local rank {local_rank})...")
        live = Live(spinner, console=console, refresh_per_second=10)

        while True:
            try:
                status_info = client.get_workload_status(run_id)
            except Exception as e:
                error_str = str(e).lower()
                if "not found" in error_str or "does not exist" in error_str or "resource_does_not_exist" in error_str:
                    log.error(f"Run {run_id} does not exist.")
                    return False
                log.error(f"Failed to get job status: {e}")
                time.sleep(2)
                continue

            state = status_info.get("state", {})
            lifecycle_state = state.get("life_cycle_state", "UNKNOWN")
            result_state = state.get("result_state", "")

            # Start spinner if we haven't printed any logs yet and no terminal state
            if last_position == 0 and not spinner_active and not result_state and not json_output:
                live.start()
                spinner_active = True

            # Only notify on state changes to avoid spam
            current_state = f"{lifecycle_state}:{result_state}" if result_state else lifecycle_state
            if current_state != previous_state:
                display_current = result_state if result_state else lifecycle_state
                display_previous: Optional[str] = None
                if previous_state:
                    parts = previous_state.split(":", 1)
                    display_previous = parts[1] if len(parts) > 1 else parts[0]
                if on_status_change is not None:
                    on_status_change(display_current, display_previous)
                if result_state:
                    log.debug(f"Job status: {result_state}")
                else:
                    log.debug(f"Job status: {lifecycle_state}")
                previous_state = current_state

            # If job is running, try to get MLflow run ID and stream logs
            if lifecycle_state == "RUNNING":
                retry_check_counter += 1

                # Check for new/changed MLflow run ID periodically (every 5 seconds)
                if mlflow_run_id is None or retry_check_counter % RETRY_CHECK_INTERVAL_ITERATIONS == 0:
                    new_mlflow_run_id, new_log_artifacts_path, new_log_file_name = _get_mlflow_run_id_and_log_path(
                        client, run_id, node=node, local_rank=local_rank, attempt=attempt, task_attempt=task_attempt
                    )

                    # Detect if MLflow run ID changed (retry occurred)
                    if new_mlflow_run_id and mlflow_run_id and new_mlflow_run_id != mlflow_run_id:
                        assert new_log_artifacts_path and new_log_file_name
                        # Stop spinner if active before printing message
                        if spinner_active:
                            live.stop()
                            spinner_active = False
                        print("\n⚠️  Job retried, switching to new task run logs...\n", flush=True)
                        mlflow_run_id = new_mlflow_run_id
                        full_log_file_path = os.path.join(new_log_artifacts_path, new_log_file_name)
                        last_position = 0  # Reset to read new logs from beginning
                    elif new_mlflow_run_id and mlflow_run_id is None:
                        # First time getting MLflow run ID
                        assert new_log_artifacts_path and new_log_file_name
                        mlflow_run_id = new_mlflow_run_id
                        full_log_file_path = os.path.join(new_log_artifacts_path, new_log_file_name)

                # If we have the MLflow run ID, stream logs
                if mlflow_run_id and full_log_file_path:
                    new_position = print_new_logs(
                        run_id=mlflow_run_id,
                        artifact_path=full_log_file_path,
                        dst_path=tmpdir,
                        last_position=last_position,
                        line_callback=line_callback,
                    )

                    # Stop spinner once we've actually printed logs (position changed from 0)
                    if new_position > 0 and spinner_active:
                        live.stop()
                        spinner_active = False

                    last_position = new_position

            # Emit periodic METRIC events when mlflow_run_id is available
            if mlflow_run_id and time.time() - last_metrics_emit_time >= metrics_interval_seconds:
                resolved_default_keys, latest = resolve_and_fetch_metrics(
                    mlflow_client, mlflow_run_id, metric_keys, no_default_metrics, resolved_default_keys
                )
                if latest:
                    if json_output:
                        print_jsonl_event("METRIC", metrics=latest)
                    else:
                        metric_str = "  ".join(f"{k}={v:.4g}" for k, v in latest.items())
                        print(f"[metrics] {metric_str}", flush=True)
                last_metrics_emit_time = time.time()

            # Check if job reached terminal state
            if lifecycle_state in TERMINAL_STATES or result_state in TERMINAL_RESULT_STATES:
                # Stop spinner if still active
                if spinner_active:
                    live.stop()
                    spinner_active = False

                # Print any remaining logs
                if mlflow_run_id and full_log_file_path:
                    print_new_logs(
                        run_id=mlflow_run_id,
                        artifact_path=full_log_file_path,
                        dst_path=tmpdir,
                        last_position=last_position,  # Print only remaining logs since last read
                        line_callback=line_callback,
                    )

                success = result_state == "SUCCESS"
                log.info(f"Job status: {result_state}")

                return success

            # Wait before next poll
            time.sleep(RETRY_CHECK_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        if spinner_active:
            live.stop()
        log.warning("Monitoring interrupted by user")
        log.info("Job is still running. Use 'sgcli get status %s' to check status", run_id)
        return False

    finally:
        if spinner_active:
            live.stop()
        if tmpdir is not None:
            shutil.rmtree(tmpdir, ignore_errors=True)
