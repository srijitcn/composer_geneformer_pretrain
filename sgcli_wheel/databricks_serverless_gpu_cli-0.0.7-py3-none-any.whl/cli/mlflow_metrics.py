"""MLflow metric-reading utilities for sgcli.

Shared by `monitor` (streaming METRIC events) and future `get metrics` (one-shot history).
"""

import logging
from typing import Dict, List, Optional, Tuple

import mlflow
import mlflow.tracking

log = logging.getLogger(__name__)


def get_mlflow_client() -> mlflow.tracking.MlflowClient:
    """Return a configured MlflowClient using the current tracking URI.

    Caller is responsible for calling configure_mlflow_for_current_profile()
    before invoking this function.
    """
    return mlflow.tracking.MlflowClient()


def _pick_loss_key(available_keys: List[str]) -> Optional[str]:
    """Select the best loss key from available metric keys.

    Priority: 'train/loss' > 'loss' > first key containing 'loss'.
    """
    loss_keys = [k for k in available_keys if "loss" in k]
    if not loss_keys:
        return None
    if "train/loss" in loss_keys:
        return "train/loss"
    if "loss" in loss_keys:
        return "loss"
    return loss_keys[0]


def _resolve_default_keys_from_available(available_keys: List[str]) -> List[str]:
    """Resolve loss/gpu_utilization/gpu_memory keys from a list of available metric keys.

    Pure function — no I/O. Returns [] if none of the expected patterns are present.
    """
    result: List[str] = []

    # Loss key: prefer 'train/loss' > 'loss' > first key containing 'loss'
    loss_key = _pick_loss_key(available_keys)
    if loss_key:
        result.append(loss_key)

    # GPU utilization: first key containing 'gpu_utilization'
    gpu_util_key = next((k for k in available_keys if "gpu_utilization" in k), None)
    if gpu_util_key:
        result.append(gpu_util_key)

    # GPU memory: first key containing 'gpu_memory'
    gpu_memory_key = next((k for k in available_keys if "gpu_memory" in k), None)
    if gpu_memory_key:
        result.append(gpu_memory_key)

    return result


def resolve_default_metric_keys(client: mlflow.tracking.MlflowClient, mlflow_run_id: str) -> List[str]:
    """Auto-detect loss, gpu_utilization, gpu_memory keys from the run's available metrics.

    Scans run.data.metrics keys for patterns:
      - loss:        keys containing 'loss' (prefer 'train/loss' > 'loss' > first match)
      - gpu_util:    first key containing 'gpu_utilization'
      - gpu_memory:  first key containing 'gpu_memory'

    Returns a list of matched keys. Returns [] if none found yet (e.g., training hasn't
    started logging yet) — caller should retry on the next poll interval.
    """
    try:
        run = client.get_run(mlflow_run_id)
        available_keys = list(run.data.metrics.keys())
    except Exception as e:
        log.debug(f"Failed to get run metrics for key discovery: {e}")
        return []

    return _resolve_default_keys_from_available(available_keys)


def resolve_and_fetch_metrics(
    client: mlflow.tracking.MlflowClient,
    mlflow_run_id: str,
    extra_keys: Optional[List[str]],
    no_default_metrics: bool,
    previously_resolved: List[str],
) -> Tuple[List[str], Dict[str, float]]:
    """Resolve default metric keys and fetch latest values in a single get_run() call.

    Accumulates resolved default keys across calls — the returned list is a superset of
    previously_resolved, growing as new metric types appear. GPU metrics often start
    logging several minutes after training loss, so re-resolving each interval is required
    to pick them up without waiting for a full restart.

    Args:
        client: MLflow tracking client.
        mlflow_run_id: The MLflow run ID to query.
        extra_keys: Additional user-specified metric keys beyond auto-detected defaults.
        no_default_metrics: When True, skip auto-detection; only use extra_keys.
        previously_resolved: Default keys found in prior intervals. Grows monotonically —
            keys are added as they appear but never removed.

    Returns:
        (updated_resolved_keys, metrics_dict):
          - updated_resolved_keys: superset of previously_resolved with any newly
            discovered default keys merged in.
          - metrics_dict: {key: latest_value} for all keys present in the run.
            Empty if all requested keys are missing or on API error.
    """
    try:
        run = client.get_run(mlflow_run_id)
    except Exception as e:
        log.debug(f"Failed to fetch run {mlflow_run_id} for metrics: {e}")
        return previously_resolved, {}

    available_keys = list(run.data.metrics.keys())
    all_metrics = run.data.metrics

    # Accumulate default keys: merge previously found with any newly discovered.
    # GPU metrics often appear later than loss, so we keep re-resolving each interval.
    updated_resolved = previously_resolved
    if not no_default_metrics:
        newly_discovered = _resolve_default_keys_from_available(available_keys)
        if newly_discovered:
            merged = list(dict.fromkeys(previously_resolved + newly_discovered))
            updated_resolved = merged

    # Build final key list: updated defaults + user-specified extras (deduplicated)
    all_keys = list(dict.fromkeys(updated_resolved + list(extra_keys or [])))

    metrics = {k: all_metrics[k] for k in all_keys if k in all_metrics}
    return updated_resolved, metrics


def fetch_latest_metrics(
    client: mlflow.tracking.MlflowClient,
    mlflow_run_id: str,
    keys: List[str],
) -> Dict[str, float]:
    """Return {key: latest_value} for all requested keys present in the run.

    Uses a single get_run() API call. Missing keys are silently skipped
    (metrics may not be logged yet).
    """
    if not keys:
        return {}
    try:
        run = client.get_run(mlflow_run_id)
        all_metrics = run.data.metrics
    except Exception as e:
        log.debug(f"Failed to fetch metrics for run {mlflow_run_id}: {e}")
        return {}
    return {k: all_metrics[k] for k in keys if k in all_metrics}


def fetch_metric_history(
    client: mlflow.tracking.MlflowClient,
    mlflow_run_id: str,
    keys: List[str],
    last_n: int,
) -> Dict[str, List[Dict]]:
    """Return {key: [{step, value, ts}]} for the last_n steps of each key.

    Used by `get metrics` one-shot command. Makes one API call per key.
    Entries are sorted by step ascending.

    Args:
        client: MLflow tracking client.
        mlflow_run_id: The MLflow run ID to query.
        keys: Metric keys to fetch history for.
        last_n: Number of most-recent steps to return. Use 0 as a sentinel to
            return the full history for each key.
    """
    result: Dict[str, List[Dict]] = {}
    for key in keys:
        try:
            history = client.get_metric_history(mlflow_run_id, key)
            sorted_history = sorted(history, key=lambda m: m.step)
            tail = sorted_history[-last_n:] if last_n > 0 else sorted_history
            result[key] = [{"step": m.step, "value": m.value, "ts": m.timestamp} for m in tail]
        except Exception as e:
            log.debug(f"Failed to fetch metric history for key '{key}': {e}")
    return result
