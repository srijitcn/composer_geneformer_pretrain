"""Databricks Serverless GPU CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "0.0.7"
__git_sha__ = "84e65e03753be1cf1a46b7f54dd85d17cddee86e"
