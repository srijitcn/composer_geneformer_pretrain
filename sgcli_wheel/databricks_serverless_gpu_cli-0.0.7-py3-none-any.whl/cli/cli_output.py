"""Colored output utilities for CLI user-facing messages.

This module provides consistent colored output across the CLI using Rich,
making it easier for users to distinguish errors, success messages, and links.
"""

import io
import logging
import traceback as tb
from rich.console import Console
from rich.markup import escape as rich_escape

# Create a global console instance for CLI output
_console = Console()
_stderr_console = Console(stderr=True)
# Discards all output — used in JSON mode to silence human-readable messages.
_null_console = Console(file=io.StringIO())

# When True, all human-readable output is suppressed so stdout stays
# clean for structured JSON envelopes.
_json_mode = False


def set_json_mode(enabled: bool) -> None:
    """Enable or disable JSON output mode.

    In JSON mode, all Rich print_* calls are suppressed so that stdout is
    exclusively used for machine-readable JSON envelopes.
    """
    global _json_mode
    _json_mode = enabled


def is_json_mode() -> bool:
    return _json_mode


def _get_console() -> Console:
    return _null_console if _json_mode else _console


def print_error(message: str) -> None:
    """Print an error message in red.

    Args:
        message: The error message to display
    """
    _get_console().print(f"[red]{message}[/red]")


def print_success(message: str) -> None:
    """Print a success message in green.

    Args:
        message: The success message to display
    """
    _get_console().print(f"[green]{message}[/green]")


def print_info(message: str) -> None:
    """Print an informational message.

    Args:
        message: The info message to display
    """
    _get_console().print(message)


def print_warning(message: str) -> None:
    """Print a warning message in yellow.

    Args:
        message: The warning message to display
    """
    _get_console().print(f"[yellow]{message}[/yellow]")


def print_link(text: str, url: str) -> None:
    """Print a clickable link in cyan.

    Args:
        text: The text to display
        url: The URL to link to
    """
    _get_console().print(f"[cyan][link={url}]{text}[/link][/cyan]")


def print_url(url: str) -> None:
    """Print a URL as a clickable link in cyan.

    Args:
        url: The URL to display and link to
    """
    _get_console().print(f"[cyan][link={url}]{url}[/link][/cyan]")


def print_exception(exc: Exception, show_locals: bool = False) -> None:
    """Print an exception with a colored traceback.

    Args:
        exc: The exception to display
        show_locals: Whether to show local variables in the traceback
    """
    _get_console().print_exception(show_locals=show_locals)


def format_traceback(exc: Exception) -> str:
    """Format an exception traceback as a colored string.

    Args:
        exc: The exception to format

    Returns:
        Formatted traceback string
    """
    return "".join(tb.format_exception(type(exc), exc, exc.__traceback__))


class RichLoggingFormatter(logging.Formatter):
    """Logging formatter that uses Rich for colored output.

    This formatter colorizes log messages based on their level:
    - DEBUG: dim/gray
    - INFO: default/white
    - WARNING: yellow
    - ERROR: red
    - CRITICAL: bold red
    """

    LEVEL_COLORS = {
        logging.DEBUG: "dim",
        logging.INFO: "white",
        logging.WARNING: "yellow",
        logging.ERROR: "red",
        logging.CRITICAL: "bold red",
    }

    def __init__(self, fmt: str = "[%(levelname)s] %(message)s", **kwargs):
        """Initialize the formatter.

        Args:
            fmt: Log format string
            **kwargs: Additional arguments passed to logging.Formatter
        """
        super().__init__(fmt, **kwargs)
        self.console = Console()

    def format(self, record: logging.LogRecord) -> str:
        """Format a log record with colors.

        Args:
            record: The log record to format

        Returns:
            Formatted and colored log message
        """
        # Get the base formatted message and return it
        # The formatMessage method handles the actual colorization
        return super().format(record)

    def formatMessage(self, record: logging.LogRecord) -> str:
        """Format the message with colors applied.

        Args:
            record: The log record to format

        Returns:
            Colored message string
        """
        # Format the base message and escape Rich markup in user content
        # so that brackets (e.g. profile names like [df1]) are not
        # interpreted as Rich style tags.
        message = rich_escape(super().formatMessage(record))

        # Apply color based on log level
        color = self.LEVEL_COLORS.get(record.levelno, "white")

        # For ERROR and CRITICAL, colorize the entire message
        if record.levelno >= logging.ERROR:
            return f"[{color}]{message}[/{color}]"
        # For WARNING, colorize the level tag
        elif record.levelno == logging.WARNING:
            return message.replace("\\[WARNING]", f"[{color}]\\[WARNING][/{color}]")
        # For INFO, keep default
        elif record.levelno == logging.INFO:
            return message
        # For DEBUG, make it dim
        else:
            return f"[{color}]{message}[/{color}]"


class RichLoggingHandler(logging.Handler):
    """Logging handler that outputs through Rich Console for colored output."""

    def __init__(self, level=logging.NOTSET, console: Console = None):
        """Initialize the handler.

        Args:
            level: Minimum log level to handle
            console: Rich Console instance (uses global if not provided)
        """
        super().__init__(level)
        self._explicit_console = console

    @property
    def console(self) -> Console:
        if self._explicit_console is not None:
            return self._explicit_console
        # In JSON mode, log output (-v) still goes to stderr; only Rich print_* calls are suppressed.
        return _stderr_console if _json_mode else _console

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record through Rich Console.

        Args:
            record: The log record to emit
        """
        try:
            msg = self.format(record)
            # Print through Rich console to handle markup
            self.console.print(msg, highlight=False, soft_wrap=True)
        except Exception:
            self.handleError(record)
