"""Image policy handling for SGCLI run command.

This module implements the image policy logic that determines how Docker images
are resolved and registered before launching a workload:

- `auto` (default): Use cached image if available, otherwise register
- `latest`: Always check source registry for SHA updates
"""

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Optional

from cli.image_registration.image_client import (
    ImageClient,
    ImageRegistration,
    ImageStatus,
)

log = logging.getLogger(__name__)


class ImagePolicy(Enum):
    """Image resolution policy for docker images."""

    AUTO = "auto"
    LATEST = "latest"


@dataclass
class ImageRegistrationResult:
    """Result of image resolution."""

    image_updated: bool
    manifest_sha256: Optional[str] = None


class ImagePolicyHandler:
    """Handles image resolution based on the selected policy."""

    def __init__(
        self,
        workspace_host: Optional[str] = None,
        credentials_scope: Optional[str] = None,
        credentials_key: Optional[str] = None,
    ):
        """Initialize the handler.

        Args:
            workspace_host: Optional workspace host URL
            credentials_scope: Databricks secret scope for registry credentials
            credentials_key: Databricks secret key for registry credentials
        """
        self.client = ImageClient(workspace_host=workspace_host)
        self.credentials_scope = credentials_scope
        self.credentials_key = credentials_key

    def resolve_image(
        self,
        docker_image_url: str,
        tag_policy: ImagePolicy = ImagePolicy.AUTO,
        wait_for_ready: bool = True,
        timeout_seconds: int = 900,
        verbose: bool = False,
    ) -> ImageRegistrationResult:
        """Resolve a docker image according to the specified policy.

        Args:
            docker_image_url: Docker image URL from YAML config
            tag_policy: Image resolution tag policy (auto or latest)
            wait_for_ready: Whether to wait for image to become AVAILABLE
            timeout_seconds: Timeout for waiting
            verbose: If True, log progress every 15s (for CI/scripts).
                     If False, use TTY single-line overwrite (default).

        Returns:
            ImageRegistrationResult with image_updated flag and manifest SHA

        Raises:
            RuntimeError: If image registration or resolution fails
            TimeoutError: If waiting for image times out
        """
        log.info(f"Resolving image: {docker_image_url} (tag_policy={tag_policy.value})")

        existing = self.client.get_image(docker_image_url)

        if existing is not None:
            return self._handle_existing(
                docker_image_url=docker_image_url,
                existing=existing,
                tag_policy=tag_policy,
                wait_for_ready=wait_for_ready,
                timeout_seconds=timeout_seconds,
                verbose=verbose,
            )
        else:
            return self._handle_new(
                docker_image_url=docker_image_url,
                wait_for_ready=wait_for_ready,
                timeout_seconds=timeout_seconds,
                verbose=verbose,
            )

    def _handle_existing(
        self,
        docker_image_url: str,
        existing: ImageRegistration,
        tag_policy: ImagePolicy,
        wait_for_ready: bool,
        timeout_seconds: int,
        verbose: bool,
    ) -> ImageRegistrationResult:
        """Handle case where user has an existing registration.

        For AUTO tag policy, uses cached image if AVAILABLE.
        For LATEST tag policy, re-registers to check for SHA updates.
        For FAILED status, re-registers.
        """
        log.info(f"Found existing registration: status={existing.status.value}")

        # Re-register unless already AVAILABLE (or LATEST policy forces re-check).
        # CreateImage is idempotent and reconciles the status against the HarborImage
        # entity, so re-registering a PENDING image will pick up AVAILABLE if the
        # background upload has completed.
        should_reregister = existing.status != ImageStatus.AVAILABLE or tag_policy == ImagePolicy.LATEST

        if should_reregister:
            if existing.status == ImageStatus.FAILED:
                log.warning(f"Previous registration failed: {existing.status_message or 'Unknown error'}")
                log.info("Re-registering image...")
            else:
                log.info("LATEST tag_policy: checking source registry for updates...")

            cached_sha = existing.manifest_sha256

            new_reg = self.client.create_image(
                docker_image_url=docker_image_url,
                credentials_scope=self.credentials_scope,
                credentials_key=self.credentials_key,
            )

            if wait_for_ready and new_reg.status != ImageStatus.AVAILABLE:
                log.info("Waiting for image to become available...")
                new_reg = self.client.wait_for_image_ready(
                    docker_image_url=docker_image_url,
                    timeout_seconds=timeout_seconds,
                    verbose=verbose,
                )
                log.info("Image ready")

            new_sha = new_reg.manifest_sha256
            sha_changed = cached_sha and new_sha and cached_sha != new_sha

            if sha_changed:
                log.info(f"Image updated: {cached_sha[:16]}... -> {new_sha[:16]}...")

            return ImageRegistrationResult(
                image_updated=sha_changed or existing.status == ImageStatus.FAILED,
                manifest_sha256=new_sha or cached_sha,
            )

        # AUTO policy: use cached image if AVAILABLE
        return ImageRegistrationResult(image_updated=False, manifest_sha256=existing.manifest_sha256)

    def _handle_new(
        self,
        docker_image_url: str,
        wait_for_ready: bool,
        timeout_seconds: int,
        verbose: bool,
    ) -> ImageRegistrationResult:
        """Handle case where user has no existing registration.

        Creates a new image registration and optionally waits for it to become AVAILABLE.

        Args:
            docker_image_url: Docker image URL.
            wait_for_ready: Whether to wait for image to become AVAILABLE.
            timeout_seconds: Timeout for waiting.
            verbose: If True, log progress every 15s.

        Returns:
            ImageRegistrationResult with image_updated=True.
        """
        log.info(
            "No existing registration found, creating new registration. "
            "This may take several minutes for larger images as they are replicated."
        )

        registration = self.client.create_image(
            docker_image_url=docker_image_url,
            credentials_scope=self.credentials_scope,
            credentials_key=self.credentials_key,
        )

        log.info(f"Created registration: status={registration.status.value}")

        if wait_for_ready and registration.status != ImageStatus.AVAILABLE:
            log.info("Waiting for image to become available...")
            registration = self.client.wait_for_image_ready(
                docker_image_url=docker_image_url,
                timeout_seconds=timeout_seconds,
                verbose=verbose,
            )
            log.info("Image ready")

        # Get final registration to ensure we have the SHA
        final_reg = self.client.get_image(docker_image_url)
        return ImageRegistrationResult(
            image_updated=True,
            manifest_sha256=final_reg.manifest_sha256 if final_reg else registration.manifest_sha256,
        )


def parse_image_policy(tag_policy_str: str) -> ImagePolicy:
    """Parse an image tag policy string to ImagePolicy enum.

    Args:
        policy_str: Tag policy string ("auto" or "latest")

    Returns:
        ImagePolicy enum value

    Raises:
        ValueError: If tag_policy string is invalid
    """
    tag_policy_str = tag_policy_str.lower().strip()

    try:
        return ImagePolicy(tag_policy_str)
    except ValueError:
        valid = ", ".join(p.value for p in ImagePolicy)
        raise ValueError(f"Invalid image tag policy: '{tag_policy_str}'. Valid options: {valid}")
