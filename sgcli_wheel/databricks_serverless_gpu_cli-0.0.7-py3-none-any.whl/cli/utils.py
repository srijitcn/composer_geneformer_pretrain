"""CLI-compatible utility functions for Databricks API access.

This module provides utilities for accessing Databricks APIs from a local CLI environment,
without dependencies on notebook context (dbutils, IPython, etc.).
"""

import functools
import hashlib
import logging
import os
import random
import string
import subprocess
import time
from enum import Enum
from pathlib import Path
from textwrap import dedent
from typing import Optional, List, Dict, Any, Tuple, Callable, Type, Union
import configparser
import tempfile
from packaging.requirements import Requirement
from cli.compute import GPUType

log = logging.getLogger(__name__)


CODE_SNAPSHOT_BASE_DIR = "/databricks/code_source"


def generate_unique_run_identifier(length: int = 6) -> str:
    """Generate a unique alphanumeric identifier for run names.

    Args:
        length: Length of the identifier (default: 6)

    Returns:
        str: Random alphanumeric identifier (lowercase letters and digits)
    """
    chars = string.ascii_lowercase + string.digits
    return "".join(random.choice(chars) for _ in range(length))


def _extract_status_code(exc: BaseException) -> Optional[int]:
    """
    Best-effort extraction of an HTTP status code from common exception shapes:
    - Databricks SDK errors often expose .status_code
    - requests.HTTPError exposes .response.status_code
    - some wrappers expose .response.status
    """
    # Databricks SDK (and many HTTP wrappers)
    code = getattr(exc, "status_code", None)
    if isinstance(code, int):
        return code

    # requests.HTTPError and similar
    resp = getattr(exc, "response", None)
    if resp is not None:
        code = getattr(resp, "status_code", None)
        if isinstance(code, int):
            return code
        code = getattr(resp, "status", None)
        if isinstance(code, int):
            return code

    return None


def retry(
    exceptions_to_check: Union[Type[Exception], Tuple[Type[Exception], ...]],
    tries: int = 4,
    delay_s: int = 3,
    backoff_s: int = 2,
    logger: Optional[logging.Logger] = None,
    log_level: int = logging.WARNING,
    retry_if: Optional[Callable[[BaseException], bool]] = None,
) -> Callable:
    """Retry decorator with exponential backoff_s.

    retry_if: optional predicate; if provided, only retry when retry_if(exc) is True.
    """
    if tries < 1:
        raise ValueError("tries must be >= 1")
    if delay_s < 0:
        raise ValueError("delay_s must be >= 0")
    if backoff_s < 1:
        raise ValueError("backoff_s must be >= 1")

    def deco(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _delay = delay_s
            last_exc: Optional[BaseException] = None

            for attempt in range(1, tries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions_to_check as e:
                    last_exc = e

                    # If a predicate is provided and it says "don't retry", re-raise immediately
                    if retry_if is not None and not retry_if(e):
                        raise

                    if attempt >= tries:
                        raise

                    if logger is not None:
                        logger.log(
                            log_level,
                            "Retryable failure (attempt %d/%d): %r. Retrying in %ss...",
                            attempt,
                            tries,
                            e,
                            _delay,
                        )
                    time.sleep(_delay)
                    _delay *= backoff_s

            raise last_exc  # type: ignore[misc]

        return wrapper

    return deco


def is_http_5xx(exc: BaseException) -> bool:
    code = _extract_status_code(exc)
    return code is not None and 500 <= code < 600


# ---------------- Authentication ----------------


def find_profile_for_host(host: str) -> Optional[str]:
    """Find a profile in databrickscfg that matches the given host.

    Args:
        host: The workspace host URL to match (e.g., "https://example.databricks.com")

    Returns:
        Optional[str]: The profile name if found, None otherwise.
    """
    # Get config file location
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    # Normalize the target host for comparison
    target_host = host.rstrip("/")
    if not target_host.startswith("http://") and not target_host.startswith("https://"):
        target_host = f"https://{target_host}"

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Search through all profiles for a matching host
        sections_to_check = config.sections() + ["DEFAULT"]
        for section in sections_to_check:
            if config.has_option(section, "host"):
                profile_host = config.get(section, "host").rstrip("/")
                # Normalize profile host
                if not profile_host.startswith("http://") and not profile_host.startswith("https://"):
                    profile_host = f"https://{profile_host}"

                if profile_host == target_host:
                    log.debug("Found matching profile '%s' for host %s", section, target_host)
                    return section

        log.warning("No matching profile found for host %s in %s", target_host, config_path)
        return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def find_host_for_profile(profile: str) -> Optional[str]:
    """Find the host URL for a given profile in databrickscfg.

    Args:
        profile: The profile name to look up (e.g., "DEFAULT", "my-profile")

    Returns:
        Optional[str]: The host URL if found, None otherwise.
    """
    # Get config file location
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Check if the profile exists
        # Note: ConfigParser treats DEFAULT specially - it's accessed via defaults() not has_section()
        if profile == "DEFAULT":
            # Check if DEFAULT section has a host
            if config.has_option("DEFAULT", "host"):
                host = config.get("DEFAULT", "host").rstrip("/")
                # Normalize host to include https:// if missing
                if not host.startswith("http://") and not host.startswith("https://"):
                    host = f"https://{host}"
                log.debug("Found host '%s' for profile '%s'", host, profile)
                return host
            else:
                log.warning("Profile '%s' does not have a 'host' field", profile)
                return None
        else:
            # Regular profile section
            if not config.has_section(profile):
                log.warning("Profile '%s' not found in %s", profile, config_path)
                return None

            # Get the host from the profile
            if config.has_option(profile, "host"):
                host = config.get(profile, "host").rstrip("/")
                # Normalize host to include https:// if missing
                if not host.startswith("http://") and not host.startswith("https://"):
                    host = f"https://{host}"
                log.debug("Found host '%s' for profile '%s'", host, profile)
                return host
            else:
                log.warning("Profile '%s' does not have a 'host' field", profile)
                return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def get_default_profile() -> Optional[str]:
    """Get the default profile name from databrickscfg.

    Returns:
        Optional[str]: The default profile name if found (typically "DEFAULT"), None otherwise.
    """
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Check if DEFAULT profile exists
        # Note: ConfigParser treats DEFAULT specially, so we need to check if it has options
        if config.has_option("DEFAULT", "host") or len(config.defaults()) > 0:
            return "DEFAULT"

        # If no DEFAULT section, return None
        return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def log_auth_context(verbose: bool = False) -> None:
    """Log the authentication context being used for Databricks API calls.

    With verbose=True (debug level):
    - Logs which environment variables are set (DATABRICKS_AUTH_TYPE, DATABRICKS_TOKEN, DATABRICKS_CONFIG_PROFILE)
    - Logs their values (except DATABRICKS_TOKEN, just logs that it's set)

    With verbose=False (info level):
    - Logs the workspace URL and profile being used

    Args:
        verbose: If True, log detailed debug information about env vars
    """
    env = os.environ
    auth_vars = {
        "DATABRICKS_AUTH_TYPE": env.get("DATABRICKS_AUTH_TYPE"),
        "DATABRICKS_TOKEN": env.get("DATABRICKS_TOKEN"),
        "DATABRICKS_CONFIG_PROFILE": env.get("DATABRICKS_CONFIG_PROFILE"),
        "DATABRICKS_HOST": env.get("DATABRICKS_HOST"),
    }

    if verbose:
        for key, val in auth_vars.items():
            if not val:
                log.debug(f"{key} is not set")
            elif key == "DATABRICKS_TOKEN":
                log.debug(f"{key} is set")
            else:
                log.debug(f"{key} is set: %s", val)

    if auth_vars["DATABRICKS_TOKEN"] and auth_vars["DATABRICKS_HOST"]:
        log.info("Using PAT token for authentication")
        log.info("Using Workspace set by DATABRICKS_HOST: %s", auth_vars["DATABRICKS_HOST"])
        return

    # Determine profile and workspace using fallbacks
    active_profile = auth_vars["DATABRICKS_CONFIG_PROFILE"] or get_default_profile()
    workspace_url = auth_vars["DATABRICKS_HOST"] or (find_host_for_profile(active_profile) if active_profile else None)

    # Log info level message based on availability
    if active_profile and workspace_url:
        log.info("Using Profile: [%s] with Workspace: %s", active_profile, workspace_url)
    elif active_profile:
        log.info("Using Profile: [%s] (workspace not configured)", active_profile)
    elif workspace_url:
        log.info("Using Workspace: %s (no profile configured)", workspace_url)
    else:
        log.info("No authentication context configured")


@functools.lru_cache(maxsize=None)
def _cached_workspace_client(host: Optional[str], profile: Optional[str]):
    """Cache WorkspaceClient by (host, profile) to avoid repeated auth token subprocess calls."""
    from databricks.sdk import WorkspaceClient

    if host and profile:
        return WorkspaceClient(profile=profile)
    elif host:
        return WorkspaceClient(host=host)
    return WorkspaceClient()


def get_workspace_client(workspace_host: Optional[str] = None):
    """Get a WorkspaceClient instance with appropriate configuration.

    Authentication priority:
    1. Use DATABRICKS_CONFIG_PROFILE environment variable if set
    2. Find matching profile in ~/.databrickscfg (or DATABRICKS_CONFIG_FILE)
       and use profile-based auth
    3. If no profile found, fall back to default WorkspaceClient() which will use
       'databricks auth token' command

    Args:
        workspace_host: Optional workspace host URL. If not provided, checks DATABRICKS_HOST
                       environment variable, then uses default config.

    Returns:
        WorkspaceClient: Configured workspace client instance.
    """
    # If no workspace_host provided, check DATABRICKS_HOST environment variable
    if not workspace_host:
        workspace_host = os.environ.get("DATABRICKS_HOST")

    if workspace_host:
        # Ensure host has https:// prefix
        host = workspace_host
        if not host.startswith("http://") and not host.startswith("https://"):
            host = f"https://{host}"

        # Step 1: Check if DATABRICKS_CONFIG_PROFILE is set
        profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")
        if profile:
            log.debug("Using DATABRICKS_CONFIG_PROFILE='%s' for authentication", profile)
            os.environ.pop("DATABRICKS_TOKEN", None)
            return _cached_workspace_client(host, profile)

        # Step 2: Try to find a matching profile in databrickscfg
        profile = find_profile_for_host(host)
        if profile:
            log.debug("Using profile '%s' from databrickscfg for authentication", profile)
            # Add this line so following calls to this function can use profile
            os.environ["DATABRICKS_CONFIG_PROFILE"] = profile
            return _cached_workspace_client(host, profile)

        # Step 3: Fall back to default (will use 'databricks_token')
        log.debug("No token or profile found, falling back to 'databricks auth token' command")
        return _cached_workspace_client(host, None)

    return _cached_workspace_client(None, None)


# ---------------- Enums ----------------


class ScriptType(str, Enum):
    """Type of script to execute."""

    BASH = "bash"
    COMMAND = "command"


def get_compute_options(gpu_type: GPUType, host: Optional[str] = None) -> List[Dict[str, Any]]:
    """Get available compute options for a specific GPU type.

    Args:
        gpu_type (GPUType): The GPU type to query options for.

    Returns:
        List[Dict[str, Any]]: List of available compute options for the specified GPU type.
    """
    method = "GET"
    endpoint = "compute-options"
    headers: dict[str, str] = {
        "Content-Type": "application/json",
    }
    payload = {}
    action = {
        "method": method,
        "path": f"/api/2.0/genai-mapi/air/{endpoint}",
        "headers": headers,
        "query": payload,
    }
    w = get_workspace_client(host)
    compute_options = w.api_client.do(**action).get("options", None)
    return [compute_option for compute_option in compute_options if compute_option["gpu_type"] == gpu_type.value]


def get_dl_runtime_image() -> str:
    """Get the deep learning runtime image to use.

    This is used as a fallback when client_image is not specified in YAML.

    Priority order for dl_runtime_image selection:
    1. client_image field in YAML environment section (checked in _build_jobs_payload)
    2. DATABRICKS_DL_RUNTIME_IMAGE environment variable (checked here)
    3. Default value 'CLIENT-GPU-4' (returned here)

    Returns:
        str: The runtime image name. Reads from DATABRICKS_DL_RUNTIME_IMAGE env var
    """
    image = os.environ.get("DATABRICKS_DL_RUNTIME_IMAGE", "CLIENT-GPU-4")
    log.debug(f"Using DL runtime image: {image}")
    return image


def get_usage_policy_id() -> Optional[str]:
    """Get the usage policy ID.

    Returns:
        Optional[str]: The usage policy ID from DATABRICKS_USAGE_POLICY_ID env var,
                      or None.
    """
    policy_id = os.environ.get("DATABRICKS_USAGE_POLICY_ID")
    if policy_id:
        log.debug(f"Using usage policy: {policy_id}")
    return policy_id


@functools.lru_cache(maxsize=None)
def get_current_user_email() -> str:
    """Get the authenticated user's email address.

    Returns:
        str: The user's email address from the authenticated WorkspaceClient.
             Works for any email domain (not just @databricks.com).

    Result is cached to avoid repeated SCIM /Me calls within a single CLI invocation.
    """
    w = get_workspace_client()
    return w.current_user.me().user_name


def get_user_workspace_dir() -> str:
    """Get the user's workspace directory path.

    Returns:
        str: The workspace directory path. Uses the authenticated user's email
             from WorkspaceClient.current_user.me().user_name, or falls back to
             DATABRICKS_INTERNAL_USER_WORKSPACE_DIR environment variable.
    """
    # Check for explicit override first
    override_dir = os.environ.get("DATABRICKS_INTERNAL_USER_WORKSPACE_DIR")
    if override_dir:
        return override_dir

    # Get the authenticated user's email
    # This works for any email domain, not just @databricks.com
    user_email = get_current_user_email()

    return f"/Workspace/Users/{user_email}"


def get_cli_launch_dir(experiment_name: str) -> str:
    """Get the directory for CLI launch artifacts.

    Args:
        experiment_name: The experiment name to create a subdirectory for.

    Returns:
        str: Path to the CLI launch directory under .serverless_gpu/cli_launch.
    """
    base_path = get_user_workspace_dir()
    import time

    timestamp = int(time.time())
    return os.path.join(base_path, ".serverless_gpu", "cli_launch", f"{experiment_name}_{timestamp}")


def upload_file_to_workspace(local_path: str, workspace_path: str) -> str:
    """Upload a local file to the Databricks Workspace.

    Args:
        local_path: Path to the local file to upload.
        workspace_path: Target workspace path. Can be:
            - Workspace files path:  /Workspace/Users/... or /Workspace/Shared/...
            - Legacy path:          /Users/... or /Shared/...
          If ends with /, the local filename will be appended.
        use_rest_api: If True, use direct REST API instead of SDK (limited to ~10MB).

    Returns:
        str: The final workspace path where the file was uploaded.

    Raises:
        RuntimeError: If workspace API is unavailable or timing out.
    """
    from pathlib import Path

    import signal
    from contextlib import contextmanager
    from databricks.sdk.service import workspace as ws

    @contextmanager
    def timeout_handler(seconds: int):
        """Context manager to timeout long-running operations."""

        def handle_timeout(signum, frame):
            raise TimeoutError(f"Operation timed out after {seconds} seconds")

        old_handler = signal.signal(signal.SIGALRM, handle_timeout)
        signal.alarm(seconds)
        try:
            yield
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

    w = get_workspace_client()

    # --- Normalize workspace path (DO NOT strip /Workspace) ---
    path = workspace_path.strip()
    if not path.startswith("/"):
        path = "/" + path

    # If path ends with /, append the local filename
    if path.endswith("/"):
        path = path.rstrip("/") + f"/{Path(local_path).name}"

    # Ensure parent directory exists with timeout
    try:
        with timeout_handler(30):
            try:
                w.workspace.mkdirs(str(Path(path).parent))
            except Exception as e:
                error_msg = str(e).lower()
                if "503" in error_msg or "unavailable" in error_msg or "timeout" in error_msg:
                    raise RuntimeError(
                        "Workspace API is currently unavailable (503 Service Unavailable). "
                        "This is typically a temporary issue with the workspace infrastructure. "
                        "Please try again in a few minutes or contact your workspace admin."
                    ) from e
                raise
    except TimeoutError as e:
        raise RuntimeError(
            "Workspace directory creation timed out after 30 seconds. "
            "The workspace API may be experiencing issues. "
            "Please check workspace availability and try again later."
        ) from e

    # --- Upload using streaming API (no 10MB limit on content) ---
    try:
        with timeout_handler(60):  # slightly longer for big files
            with open(local_path, "rb") as f:
                w.workspace.upload(
                    path=path,
                    content=f,  # file-like object
                    format=ws.ImportFormat.AUTO,  # let Databricks decide notebook vs file
                    overwrite=True,
                )
    except TimeoutError as e:
        raise RuntimeError(
            "Workspace file upload timed out. "
            "The workspace API may be experiencing issues or the file is very large. "
            "Please check workspace availability and try again."
        ) from e
    except Exception as e:
        error_msg = str(e).lower()
        if "503" in error_msg or "unavailable" in error_msg or "timeout" in error_msg:
            raise RuntimeError(
                "Workspace API is currently unavailable (503 Service Unavailable). "
                "This is typically a temporary issue with the workspace infrastructure. "
                "Please try again in a few minutes or contact your workspace admin."
            ) from e
        raise

    log.debug(f"Uploaded {local_path} to workspace {path} using SDK upload()")
    return path


def upload_file_to_volume(local_path: str, volume_path: str) -> str:
    """Upload a local file to a Databricks Volume.

    Args:
        local_path: Path to the local file to upload.
        volume_path: Target volume path. Must start with /Volumes/.
                    If ends with /, the local filename will be appended.

    Returns:
        str: The final volume path where the file was uploaded.

    Raises:
        ValueError: If volume_path doesn't start with /Volumes/.
    """
    w = get_workspace_client()

    # Normalize volume path
    path = volume_path.strip()
    if not path.startswith("/Volumes/"):
        raise ValueError(f"Volume path must start with '/Volumes/', got: {path}")

    # If path ends with /, append the local filename
    if path.endswith("/"):
        path = path.rstrip("/") + f"/{Path(local_path).name}"

    parent = os.path.dirname(path)
    w.files.create_directory(parent)

    # Upload file to volume using Files API
    w.files.upload(
        file_path=path,
        contents=open(local_path, "rb"),
        overwrite=True,
    )
    log.debug(f"Uploaded {local_path} to volume {path}")
    return path


def upload_python_script_as_zip(local_script_path: str, workspace_dir: str) -> Tuple[str, str]:
    """Upload a Python script to workspace with .dat extension.

    We upload with .dat extension to prevent workspace from treating it as a notebook
    or auto-extracting it. The bash script will copy it to $HOME and rename back to .py.

    Args:
        local_script_path: Path to the local .py file to upload.
        workspace_dir: Workspace directory to upload the script to.

    Returns:
        Tuple[str, str]: A tuple containing:
            - workspace_dat_path: Path to the uploaded .dat file in workspace
            - script_filename: Original Python filename (with .py extension)
    """
    script_path = Path(local_script_path)
    script_filename = script_path.name

    # Upload with .dat extension to avoid notebook conversion or auto-extraction
    workspace_dat_path = os.path.join(workspace_dir, f"{script_path.stem}.dat")
    uploaded_path = upload_file_to_workspace(local_script_path, workspace_dat_path)

    log.debug(f"Uploaded Python script as .dat file: {uploaded_path}")
    return uploaded_path, script_filename


def upload_parameters_as_yaml(parameters: Dict[str, Any], func_dir: str) -> str:
    """Upload parameters dict as a YAML file to workspace.

    Args:
        parameters: Dictionary containing hyperparameters/config.
        func_dir: Remote workspace directory to upload to.

    Returns:
        str: Remote workspace path to the uploaded YAML file.
    """
    import yaml

    # Create temporary YAML file with parameters
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
        temp_params_file = f.name
        yaml.safe_dump(parameters, f, default_flow_style=False, sort_keys=False)

    try:
        # Upload to workspace
        remote_path = os.path.join(func_dir, "hyperparameters.yaml")
        uploaded_path = upload_file_to_workspace(temp_params_file, remote_path)
        log.debug(f"Uploaded hyperparameters YAML to: {uploaded_path}")
        return uploaded_path
    finally:
        # Clean up temp file
        try:
            os.unlink(temp_params_file)
        except Exception as e:
            log.warning(f"Failed to delete temp parameters file {temp_params_file}: {e}")


def _ensure_workspace_prefix(path: str) -> str:
    """Ensure a workspace path has the /Workspace prefix for use in bash scripts.

    Args:
        path: Workspace path that may or may not have /Workspace prefix

    Returns:
        str: Path with /Workspace prefix for use in job bash scripts
    """
    if path.startswith("/Workspace/") or path == "/Workspace":
        return path
    elif path.startswith("/"):
        return f"/Workspace{path}"
    else:
        return f"/Workspace/{path}"


def _build_tarball_acquire_script(tar_workspace_path: str) -> str:
    """Return bash snippet that copies the tarball to $HOME/data.tar.gz.

    Both Volumes and Workspace paths are copied locally via copy_with_retry
    before extraction so that the extraction step is identical for both sources.
    """
    if tar_workspace_path.startswith("/Volumes/"):
        tar_path = tar_workspace_path
    else:
        tar_path = _ensure_workspace_prefix(tar_workspace_path)
    return dedent(f"""\
        TAR_PATH="{tar_path}"
        if [ ! -f "$TAR_PATH" ]; then
            echo "ERROR: Tarball not found at {tar_path}"
            exit 1
        fi
        LOCAL_TAR=$HOME/data.tar.gz
        echo "Copying tarball to local..."
        copy_with_retry "$TAR_PATH" $LOCAL_TAR
        """)


def prepare_launch_script_simple(
    gpus: int,
    gpus_per_node: int,
    workspace_zip_path: Optional[str],
    script_filename: str,
    func_dir: str,
    script_type: ScriptType = ScriptType.BASH,
    tar_workspace_path: Optional[str] = None,
    env_variables: Optional[Dict[str, str]] = None,
    env_variables_secrets: Optional[Dict[str, str]] = None,
    requirements_filename: Optional[str] = None,
    parameters_yaml_path: Optional[str] = None,
    sanity_check_script_path: Optional[str] = None,
    mlflow_system_metrics_script_path: Optional[str] = None,
    docker_image_url: Optional[str] = None,
    run_name: Optional[str] = None,
) -> str:
    """Create a launch script for distributed training or bash script execution.

    This creates a bash script that sets up the environment and runs either a Python script
    with distributed training (torchrun) or a user bash script directly.

    Args:
        gpus: Total number of GPUs to allocate for the workload.
        gpus_per_node: Number of GPUs per compute node.
        workspace_zip_path: Path to the .dat file in workspace (containing the script).
        script_filename: Name of the script.
        func_dir: Remote workspace directory where the launch script should be uploaded.
        script_type: Type of script, bash or command.
        tar_workspace_path: Optional path to tarball in workspace to extract before running script.
        env_variables: Optional dict of regular environment variables to export.
        env_variables_secrets: Optional dict mapping "scope/key" to "ENV_VAR_NAME" for secrets.
        requirements_filename: Optional name of requirements.yaml file (e.g., 'requirements.yaml') uploaded to workspace.
        parameters_yaml_path: Optional path to hyperparameters YAML file in workspace.
        sanity_check_script_path: Optional path to node sanity check script in workspace.
        mlflow_system_metrics_script_path: Optional path to MLflow system metrics monitoring script in workspace.
        docker_image_url: Optional custom docker image URL in format "organization/repository:tag" (e.g., "pytorch/pytorch:2.0.1").
                         When provided, skips requirements installation, MLflow system metrics, and MLflow run name updates.

    Returns:
        str: Remote workspace path to the uploaded launch script.
    """
    # Default to empty dict if None
    if env_variables is None:
        env_variables = {}

    # Prepare script components
    dbruntime_version = os.environ.get("DATABRICKS_RUNTIME_VERSION", "15.4")

    # Determine requirements.yaml path - always in func_dir (uploaded from local machine)
    if requirements_filename:
        requirements_yaml_path = os.path.join(func_dir, requirements_filename)
    else:
        requirements_yaml_path = None

    # Build bash script header
    script_content = dedent(f"""\
        #!/bin/bash
        set -e

        # Record start time
        START_TIME=$(date +%s)
        echo "Environment setup started at $(date)"


        cleanup_mlflow_metrics() {{
            if [ -n "${{MLFLOW_METRICS_PID:-}}" ]; then
                kill -TERM "$MLFLOW_METRICS_PID" 2>/dev/null || true
                for _mlflow_i in $(seq 30); do
                    kill -0 "$MLFLOW_METRICS_PID" 2>/dev/null || break
                    sleep 1
                done
                if kill -9 "$MLFLOW_METRICS_PID" 2>/dev/null; then
                    echo "MLflow system metrics monitor (PID $MLFLOW_METRICS_PID) did not exit cleanly; force killed."
                    echo "SYSTEM_ERROR: mlflow metrics not terminated" >> /dev/termination-log
                fi
            fi
        }}

        # Error handler: clean up MLflow metrics on failure
        handle_error() {{
            local exit_code=$?
            local current_time=$(date +%s)
            local elapsed=$((current_time - START_TIME))

            echo "ERROR: Script failed with exit code $exit_code after ${{elapsed}}s"

            exit $exit_code
        }}

        copy_with_retry() {{
            local src="$1"
            local dst="$2"
            local max_retries=5
            local base_delay=1
            local attempt=0

            until cp "$src" "$dst"; do
                attempt=$((attempt + 1))
                if ((attempt >= max_retries)); then
                    echo "Failed after $max_retries attempts" >&2
                    return 1
                fi

                # Exponential backoff_s: 1, 2, 4, 8, 16...
                delay_s=$((base_delay * (2 ** (attempt - 1))))
                echo "Attempt $attempt failed. Retrying in ${{delay_s}}s..." >&2
                sleep "$delay_s"
            done
        }}


        # Trap errors and call handler
        trap 'handle_error' ERR
        # Ensure MLflow metrics process is cleaned up on any exit
        trap 'cleanup_mlflow_metrics' EXIT

        # Set environment variables
        export DATABRICKS_RUNTIME_VERSION={dbruntime_version}
        export NCCL_DEBUG=WARN
    """)

    # MLflow configuration for experiment tracking
    # These environment variables enable MLflow to automatically integrate with Databricks:
    # - MLFLOW_TRACKING_URI=databricks: Configures MLflow to use Databricks as the tracking server,
    #   allowing experiment runs, metrics, and parameters to be logged to the Databricks workspace.
    # - MLFLOW_SYSTEM_METRICS_NODE_ID: Enables system metrics collection (CPU, GPU, memory) with
    #   unique node identifiers in distributed training scenarios.
    script_content += dedent("""\
        # MLflow configuration for experiment tracking
        # MLFLOW_TRACKING_URI: Directs MLflow to use Databricks as the tracking backend
        # MLFLOW_SYSTEM_METRICS_NODE_ID: Enables system metrics collection with node identification
        export MLFLOW_TRACKING_URI=databricks
        export MLFLOW_SYSTEM_METRICS_NODE_ID="node_${NODE_RANK:-0}"

        """)

    # Export hyperparameters path if provided
    if parameters_yaml_path:
        hyperparameters_full_path = _ensure_workspace_prefix(parameters_yaml_path)
        script_content += dedent(f"""\
            # Export hyperparameters YAML file path
            export HYPERPARAMETERS_PATH={hyperparameters_full_path}

            """)

    # Export code source path
    script_content += dedent(f"""\
        # Export code source path
        export CODE_SOURCE_PATH={CODE_SNAPSHOT_BASE_DIR}

        """)

    # User-provided environment variables
    if env_variables:
        script_content += "# Export user-defined environment variables\n"
        for var_name, var_value in env_variables.items():
            escaped_value = var_value.replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`")
            script_content += f'export {var_name}="{escaped_value}"\n'
        script_content += "\n"

    # Fetch and export secrets as environment variables
    if env_variables_secrets:
        # Upload the get_env_secrets.py helper script with .dat extension
        # (to avoid workspace treating it as a notebook)
        get_env_secrets_local = str(Path(__file__).parent / "get_env_secrets.py")
        get_env_secrets_remote = os.path.join(func_dir, "get_env_secrets.dat")
        upload_file_to_workspace(get_env_secrets_local, get_env_secrets_remote)

        # Build the command-line arguments for the secrets script
        secrets_args = ""
        for env_var_name, secret_ref in env_variables_secrets.items():
            scope, key = secret_ref.split("/", 1)
            secrets_args += f" --secret {env_var_name} {scope} {key}"

        get_env_secrets_full_path = _ensure_workspace_prefix(get_env_secrets_remote)
        script_content += dedent(f"""\
            # Fetch secrets from Databricks Secrets and export as environment variables
            echo 'Fetching secrets from Databricks Secrets...'
            copy_with_retry {get_env_secrets_full_path} $HOME/get_env_secrets.py
            python3 $HOME/get_env_secrets.py{secrets_args}

            # Source the secrets into current environment
            if [ -f $HOME/secrets_env.sh ]; then
                source $HOME/secrets_env.sh
                rm $HOME/secrets_env.sh
                echo 'Successfully exported all secrets as environment variables'
            else
                echo 'ERROR: Failed to create secrets environment file'
                exit 1
            fi

            """)

    # Add script acquisition section (workspace copy)
    target_script_path = f"$HOME/{script_filename}"
    workspace_zip_full_path = _ensure_workspace_prefix(workspace_zip_path)
    script_content += dedent(f"""\
        # Copy script from workspace
        copy_with_retry {workspace_zip_full_path} {target_script_path}

        """)

    # Copy and untar snapshot if provided
    if tar_workspace_path:
        script_content += "# Extract directory tarball\n"
        script_content += "tarball_extract_start_time=$(date +%s)\n"
        # During snapshotting, all files are packed under a top-level directory
        # in the tarball (e.g. "my_project/"). Extraction places them at
        # /databricks/code_source/my_project/.
        #
        # A symlink is created so legacy paths still work:
        #   /root/my_project -> /databricks/code_source/my_project
        script_content += _build_tarball_acquire_script(tar_workspace_path)
        script_content += dedent("""\
            echo "Extracting tarball..."
            COMPONENT_NAME=$(tar -tzf $LOCAL_TAR | head -1 | cut -d/ -f1)
            mkdir -p $CODE_SOURCE_PATH
            tar -xzf $LOCAL_TAR -C $CODE_SOURCE_PATH --warning=no-unknown-keyword
            rm "$LOCAL_TAR"
            ln -sfn $CODE_SOURCE_PATH/$COMPONENT_NAME "$HOME/$COMPONENT_NAME"
            echo "Created symlink: $HOME/$COMPONENT_NAME -> $CODE_SOURCE_PATH/$COMPONENT_NAME"
            tarball_extract_end_time=$(date +%s)
            tarball_extract_duration=$((tarball_extract_end_time - tarball_extract_start_time))
            echo "Tarball extraction completed in ${tarball_extract_duration}s"
            echo 'Code source available at $CODE_SOURCE_PATH'

            """)

    # Add dependencies installation section
    # Requirements.yaml is ALWAYS uploaded to func_dir from local machine
    if not docker_image_url and requirements_yaml_path:
        script_content += dedent(f"""\
            # Install dependencies from requirements.yaml
            requirements_install_start_time=$(date +%s)
            if [ -f {requirements_yaml_path} ]; then
                echo "Installing dependencies from requirements.yaml: {requirements_yaml_path}..."
                # Parse YAML and run multiple pip install commands
                # This supports scoped flags (--no-deps, --no-build-isolation) per dependency
                python3 -c "
import yaml
import subprocess
import sys
import shlex
import os

# Affects specific dependency
SCOPED_FLAGS = {{'--no-deps', '--no-build-isolation', '--no-cache-dir', '--force-reinstall'}}

# Affects all dependencies
STICKY_PREFIXES = {{'--index-url', '--extra-index-url', '--find-links', '-f', '--trusted-host'}}

try:
    with open('{requirements_yaml_path}', 'r') as f:
        data = yaml.safe_load(f) or {{}}

    deps = data.get('dependencies', [])
    if not deps:
        print('No dependencies found in requirements.yaml')
        sys.exit(0)

    sticky = []          # apply to every pip call (index urls, find-links, trusted-host)
    bulk = []            # installed together with deps enabled
    pending = []         # scoped flags collected for the next requirement-ish entry
    scoped = []          # list of per-item installs: (flags + requirement tokens)

    for entry in deps:
        # Expand environment variables in the entry before tokenizing
        # This allows using $HOME, $USER, etc. in paths like: -r $HOME/requirements.txt
        entry_str = os.path.expandvars(str(entry))
        tokens = shlex.split(entry_str)
        if not tokens:
            continue

        # sticky settings (e.g., '--index-url https://...')
        if tokens[0] in STICKY_PREFIXES:
            sticky.extend(tokens)
            continue

        # scoped flag line like: '--no-deps'
        if len(tokens) == 1 and tokens[0] in SCOPED_FLAGS:
            pending.append(tokens[0])
            continue

        # scoped flag inline like: '--no-deps https://...whl'
        if tokens[0] in SCOPED_FLAGS:
            pending.append(tokens[0])
            tokens = tokens[1:]
            if not tokens:
                continue

        if pending:
            scoped.append(pending + tokens)
            pending = []
        else:
            bulk.extend(tokens)

    if pending:
        print(f'ERROR: scoped flag(s) with no following dependency: {{pending}}', file=sys.stderr)
        sys.exit(1)

    # Install bulk dependencies with normal resolution
    if bulk:
        print(f'Installing {{len(bulk)}} dependencies with dependency resolution...')
        cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade'] + sticky + bulk
        result = subprocess.run(cmd)

        if result.returncode != 0:
            print('ERROR: Failed to install dependencies')
            print('\\nPossible causes:')
            print('  - Dependency conflicts between packages')
            print('  - Inaccessible packages (private repos, incorrect URLs)')
            print('  - Network issues preventing package downloads')
            print('  - Invalid package specifications in requirements.yaml')
            sys.exit(1)

    # Install scoped dependencies individually
    for i, item in enumerate(scoped, 1):
        print(f'Installing scoped dependency {{i}}/{{len(scoped)}} with flags: {{item[:-1]}}...')
        cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade'] + sticky + item
        result = subprocess.run(cmd)

        if result.returncode != 0:
            print('ERROR: Failed to install dependencies')
            print('\\nPossible causes:')
            print('  - Dependency conflicts between packages')
            print('  - Inaccessible packages (private repos, incorrect URLs)')
            print('  - Network issues preventing package downloads')
            print('  - Invalid package specifications in requirements.yaml')
            sys.exit(1)

    print('Successfully installed all dependencies')
except Exception as e:
    print(f'ERROR: Failed to process requirements.yaml: {{e}}', file=sys.stderr)
    import traceback
    traceback.print_exc()
    sys.exit(1)
"
                requirements_install_end_time=$(date +%s)
                requirements_install_duration=$((requirements_install_end_time - requirements_install_start_time))
                echo "Dependency installation completed in ${{requirements_install_duration}}s"
            else
                echo "ERROR: requirements.yaml not found at {requirements_yaml_path}"
                exit 1
            fi

            """)

    # Run sanity check script if provided
    if sanity_check_script_path:
        sanity_check_full_path = _ensure_workspace_prefix(sanity_check_script_path)
        script_content += dedent(f"""\
            # Run node sanity check script
            echo "Running node sanity check..."
            bash {sanity_check_full_path}
            """)

    # Start MLflow system metrics monitoring as a background sidecar process
    # Only start on local rank 0 to avoid duplicate metrics (one per node, not per GPU)
    # Skip for custom docker images: the host runtime may not have mlflow installed,
    # and MLflow tracking may not be configured for custom docker environments.
    if mlflow_system_metrics_script_path and not docker_image_url:
        mlflow_metrics_full_path = _ensure_workspace_prefix(mlflow_system_metrics_script_path)
        script_content += dedent(f"""\
            # Start MLflow system metrics monitoring in background
            if [ -n "${{MLFLOW_RUN_ID:-}}" ] && [ "${{LOCAL_RANK:-0}}" = "0" ]; then
                echo "Starting MLflow system metrics monitoring..."
                python3 {mlflow_metrics_full_path} \\
                    --run-id "${{MLFLOW_RUN_ID}}" \\
                    --parent-pid $$ \\
                    --sampling-interval 2 \\
                    --node-id "node_${{NODE_RANK:-0}}" \\
                    2>&1 &
                MLFLOW_METRICS_PID=$!
                echo "MLflow system metrics monitor started with PID $MLFLOW_METRICS_PID"
            fi

            """)

    # Update MLflow run name (always set, either custom or job run name)
    # Only runs on rank 0 node
    # Skip for custom docker images: MLflow tracking integration may not be available.
    if run_name and not docker_image_url:
        # Escape single quotes for bash
        escaped_run_name = run_name.replace("'", "'\\''")
        script_content += dedent(f"""\
            # Update MLflow run name (only on rank 0 node)
            if [ -n "${{MLFLOW_RUN_ID:-}}" ]; then
                # Check if this is rank 0 node
                if [ "${{NODE_RANK:-0}}" = "0" ]; then
                    echo "MLflow run name set to: {run_name}"
                    python3 -c '
            import os
            from databricks.sdk import WorkspaceClient

            mlflow_run_id = os.environ.get("MLFLOW_RUN_ID")
            run_name = "{escaped_run_name}"

            if mlflow_run_id:
                try:
                    w = WorkspaceClient()
                    w.api_client.do(
                        "POST",
                        "/api/2.0/mlflow/runs/update",
                        body={{"run_id": mlflow_run_id, "run_name": run_name}},
                    )
                    print(f"Successfully updated MLflow run name to: {{run_name}}")
                except Exception as e:
                    print(f"Warning: Failed to update MLflow run name: {{e}}")
            ' || true
                fi
            fi

            """)

    script_content += dedent("""\
        # Mark the start of user code execution
        user_code_start_time=$(date +%s)
        echo "Environment setup completed, starting user code execution..."

        """)

    # Add script execution section
    script_content += dedent(f"""\
        # Run the bash script directly
        chmod +x {target_script_path}
        {target_script_path}
        """)

    # Add timing summary at the end
    script_content += dedent("""
        # Calculate and display execution time
        END_TIME=$(date +%s)
        TOTAL_DURATION=$((END_TIME - START_TIME))
        ENV_SETUP_DURATION=$((user_code_start_time - START_TIME))
        USER_CODE_DURATION=$((END_TIME - user_code_start_time))

        echo "================================"
        echo "Execution Summary"
        echo "================================"
        echo "Environment setup time: ${ENV_SETUP_DURATION}s"
        echo "User code execution time: ${USER_CODE_DURATION}s"
        echo "Execution completed at $(date)"
        echo "================================"
        """)

    # Write script to temporary file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False, encoding="utf-8") as f:
        temp_launch_script = f.name
        f.write(script_content)

    try:
        # Upload to remote workspace
        remote_launch_script_path = os.path.join(func_dir, "launch_script.sh")
        remote_path = upload_file_to_workspace(temp_launch_script, remote_launch_script_path)

        log.debug(f"Created and uploaded launch script to: {remote_path}")
        return remote_path
    finally:
        # Clean up the local temporary file
        try:
            os.unlink(temp_launch_script)
        except Exception as e:
            log.warning(f"Failed to delete temporary launch script {temp_launch_script}: {e}")


def get_gpu_pool_id(gpu_type: GPUType) -> Optional[str]:
    """
    Get the GPU pool ID for a given GPU type.
    Priority order:
    1. DATABRICKS_USE_RESERVED_GPU_POOL=false (explicit opt-out overrides everything)
    2. DATABRICKS_REMOTE_GPU_POOL_ID environment variable (explicit pool selection)
    3. Auto-detected pool from notebook session (if not opted out)
    4. DATABRICKS_USE_RESERVED_GPU_POOL=true (explicit opt-in overrides inherited OD usage from notebook session)
    5. Default to on-demand (None)

    Args:
        gpu_type (GPUType): The GPU type to get the GPU pool ID for.

    Returns:
        Optional[str]: The GPU pool ID for the given GPU type.
    """
    compute_options = get_compute_options(gpu_type)
    if len(compute_options) == 0:
        raise Exception(
            f"No compute options found for {gpu_type.value}. Please contact your workspace provider to obtain access to Serverless GPU Compute."
        )

    pool_compute_options = [opt for opt in compute_options if "reserved_pool" in opt]

    # Check if explicitly opted out of pools
    # Priority: DATABRICKS_USE_RESERVED_GPU_POOL (latest) > DATABRICKS_USE_POOL (new) > SGC_USE_POOL (old) > constant default
    use_pool_env = False
    if use_pool_env in ["false", "0", "no"]:
        log.info("DATABRICKS_USE_RESERVED_GPU_POOL=false, using on-demand compute")
        return None

    # Check if user specified a specific pool
    override_pool_id = os.environ.get("DATABRICKS_REMOTE_GPU_POOL_ID", os.environ.get("REMOTE_GPU_POOL_ID", None))
    if override_pool_id:
        if pool_compute_options and override_pool_id in [opt["reserved_pool"]["id"] for opt in pool_compute_options]:
            log.info(f"Using DATABRICKS_REMOTE_GPU_POOL_ID={override_pool_id}")
            return override_pool_id
        else:
            raise Exception(
                f"The GPU pool ID {override_pool_id} is not available for {gpu_type.value}. "
                f"Available pools: {[opt['reserved_pool']['id'] for opt in pool_compute_options]}."
                f"Alternatively, try using On-Demand compute instead! (unset DATABRICKS_REMOTE_GPU_POOL_ID or REMOTE_GPU_POOL_ID)"
            )

    # Auto-detect if notebook is pool-attached
    detected_pool_id = False
    if detected_pool_id:
        # Verify it's valid for this GPU type
        if pool_compute_options and detected_pool_id in [opt["reserved_pool"]["id"] for opt in pool_compute_options]:
            log.info(f"Using auto-detected pool {detected_pool_id}")
            return detected_pool_id
        else:
            log.warning(
                f"Detected pool {detected_pool_id} not available for {gpu_type.value}, falling back to on-demand"
            )

    # Check if explicitly opted into pools
    if use_pool_env in ["true", "1", "yes"]:
        if len(pool_compute_options) == 0:
            log.warning("DATABRICKS_USE_RESERVED_GPU_POOL=true but no pools available, using on-demand")
            return None
        pool_id = pool_compute_options[0]["reserved_pool"]["id"]
        log.info(f"DATABRICKS_USE_RESERVED_GPU_POOL=true, using pool {pool_id}")
        return pool_id

    # Default to on-demand
    log.info("Using on-demand compute (default)")
    return None


IGNORED_PREFIXES = (
    "#",
    "-r ",
    "--requirement ",
    "-c ",
    "--constraint ",
    "--extra-index-url",
    "--index-url",
    "--find-links",
    "--trusted-host",
    "--no-binary",
    "--only-binary",
)


def validate_requirements_syntax(req_file: str) -> list[str]:
    """
    Returns a list of human-readable errors. Empty list == valid.
    Does not contact the network or import pip.
    """
    errors = []
    p = Path(req_file)
    if not p.exists():
        return [f"File not found: {req_file}"]

    for i, raw in enumerate(p.read_text().splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # ignore known options/directives; they're valid for pip but not Requirement()
        if any(line.startswith(pref) for pref in IGNORED_PREFIXES):
            continue
        # allow VCS/URL/paths to pass basic shape check; Requirement supports url@name
        try:
            r = Requirement(line)
            # force-parse common parts so we catch typos early
            _ = r.specifier  # type: SpecifierSet
            if r.marker:  # type: Marker|None
                _ = r.marker  # will raise on invalid marker expr
        except Exception as e:
            errors.append(f"Line {i}: {line!r} → {e.__class__.__name__}: {e}")
    return errors


def get_git_sha(repo_path: Path) -> Optional[str]:
    """Get the current git commit SHA for a repository.

    Args:
        repo_path: Path to the git repository.

    Returns:
        str: The current git commit SHA, or None if not a git repo or error occurs.
    """

    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        log.warning(f"Failed to get git SHA for {repo_path}")
        return None


def is_git_repository(repo_path: Path) -> bool:
    """Check if a directory is a git repository.

    Handles both regular repositories (.git directory) and git worktrees
    or submodules (.git file containing a gitdir pointer).

    Args:
        repo_path: Path to check

    Returns:
        True if directory contains .git entry (directory or file), False otherwise
    """
    git_dir = repo_path / ".git"
    return git_dir.exists()


def has_uncommitted_changes(repo_path: Path) -> bool:
    """Check if a git repository has uncommitted changes.

    Args:
        repo_path: Path to the git repository.

    Returns:
        bool: True if there are uncommitted changes, False otherwise.
    """

    try:
        # Check for uncommitted changes (staged or unstaged)
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        return bool(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        log.warning(f"Failed to check git status for {repo_path}")
        return False


def has_uncommitted_changes_in_paths(repo_path: Path, include_paths: List[str]) -> tuple[bool, List[str]]:
    """Check if a git repository has uncommitted changes within specified paths.
    Args:
        repo_path: Path to the git repository.
        include_paths: List of paths to check for uncommitted changes.
    Returns:
        Tuple of (has_changes, changed_files) where:
            - has_changes: True if there are uncommitted changes in the specified paths
            - changed_files: List of files with uncommitted changes in the specified paths
    Raises:
        FileNotFoundError: If git is not installed or repo_path is not a git repository.
    """
    if not include_paths:
        return False, []

    try:
        result = subprocess.run(
            ["git", "status", "--porcelain", "-z"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        if not result.stdout:
            return False, []

        # -z flag uses NUL as terminator between entries (not newlines)
        # Each entry is: "XY filename" or "XY old\x00new" for renames
        entries = result.stdout.split("\x00")
        changed_files_in_paths = []

        i = 0
        while i < len(entries):
            entry = entries[i]
            if len(entry) < 3:
                i += 1
                continue

            status = entry[:2]
            filename = entry[3:]

            # Renames/copies: with -z, the new name is the next NUL-delimited token
            if status[0] in ("R", "C"):
                i += 1
                if i < len(entries):
                    filename = entries[i]  # new filename is the next entry

            # Check if file falls within any of the include_paths
            for include_path in include_paths:
                include_path_normalized = include_path.rstrip("/")
                if not include_path_normalized:
                    continue
                if filename == include_path_normalized or filename.startswith(include_path_normalized + "/"):
                    changed_files_in_paths.append(filename)
                    break

            i += 1

        return bool(changed_files_in_paths), changed_files_in_paths

    except subprocess.CalledProcessError as e:
        raise FileNotFoundError(f"Failed to check git status for {repo_path}: {e.stderr.strip()}") from e
    except FileNotFoundError:
        raise FileNotFoundError(f"git is not installed or {repo_path} is not a git repository")


def detect_remote_name(repo_path: Path, branch: Optional[str] = None) -> str:
    """Detect the remote name for a git repository.

    Args:
        repo_path: Path to git repository
        branch: Optional branch name to check for tracking remote

    Returns:
        Remote name (e.g., "origin", "upstream")

    Priority:
        1. If branch specified, get tracking remote: git config branch.<branch>.remote
        2. Get current branch's tracking remote
        3. Get first remote: git remote | head -n1
        4. Default to "origin" if no remotes found
    """
    try:
        # Try branch tracking remote
        if branch:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "config", f"branch.{branch}.remote"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()

        # Try current branch tracking remote
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            current_branch = result.stdout.strip()
            if current_branch != "HEAD":
                result = subprocess.run(
                    ["git", "-C", str(repo_path), "config", f"branch.{current_branch}.remote"],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if result.returncode == 0 and result.stdout.strip():
                    return result.stdout.strip()

        # Get first remote
        result = subprocess.run(
            ["git", "-C", str(repo_path), "remote"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().split("\n")[0]

    except subprocess.TimeoutExpired:
        log.error(f"Failed to detect remote name for {repo_path} due to timeout")

    # Default fallback
    return "origin"


def check_workspace_file_exists(workspace_path: str) -> bool:
    """Check if a file exists in Databricks Workspace.

    Args:
        workspace_path: Path to the file in workspace (e.g., /Users/user@db.com/.serverless_gpu/...)

    Returns:
        bool: True if the file exists, False otherwise.
    """
    from databricks.sdk.errors.platform import NotFound

    w = get_workspace_client()

    # Normalize path: remove /Workspace prefix if present
    path = workspace_path.strip()
    if path.startswith("/Workspace/"):
        path = path[len("/Workspace") :]
    if not path.startswith("/"):
        path = "/" + path

    try:
        w.workspace.get_status(path)
        return True
    except NotFound:
        return False
    except Exception as e:
        log.error(f"Failed to check if file exists at {workspace_path}: {e}")
        return False


def check_volume_file_exists(volume_path: str) -> bool:
    """Check if a file exists in a Databricks Volume.

    Args:
        volume_path: Path to the file in the volume (must start with /Volumes/).

    Returns:
        bool: True if the file exists, False otherwise.
    """
    from databricks.sdk.errors.platform import NotFound

    w = get_workspace_client()
    try:
        w.files.get_metadata(volume_path)
        return True
    except NotFound:
        return False
    except Exception as e:
        log.error(f"Failed to check if file exists at {volume_path}: {e}")
        return False


def fetch_branch_sha(repo_path: Path, branch: str, remote_name: str = "origin") -> str:
    """Get the commit SHA for a branch using git ls-remote

    This is much faster than creating a shallow clone:
    1. Uses git ls-remote to query the SHA from remote
    2. Checks if the commit exists locally
    3. If not, fetches only that specific commit

    Args:
        repo_path: Path to local git repository
        branch: Branch name to resolve (e.g., 'main' or 'feature/my-branch')
        remote_name: Name of the remote (default: "origin")

    Returns:
        str: Commit SHA of the branch

    Raises:
        RuntimeError: If the branch doesn't exist or fetch fails
    """

    log.debug(f"Resolving branch {branch} from remote {remote_name} using git ls-remote")

    try:
        # Step 1: Query remote for the branch SHA
        result = subprocess.run(
            ["git", "-C", str(repo_path), "ls-remote", remote_name, f"refs/heads/{branch}"],
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )

        if not result.stdout.strip():
            # Best-effort: find similarly-named branches to help diagnose naming mismatches.
            # Wrapped in try/except so any failure here never masks the primary error.
            similar = []
            try:
                suggestions_result = subprocess.run(
                    ["git", "-C", str(repo_path), "ls-remote", "--heads", remote_name],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                similar = [
                    line.split("refs/heads/", 1)[1]
                    for line in suggestions_result.stdout.splitlines()
                    if f"/{branch}" in line or line.endswith(branch)
                ]
            except Exception:
                pass
            hint = f" Did you mean one of: {similar}?" if similar else ""
            raise RuntimeError(
                f"Branch '{branch}' not found on remote '{remote_name}'.{hint} "
                f"Ensure the branch has been pushed and that git_branch matches the remote branch name exactly."
            )

        # Extract SHA from output (format: "SHA\trefs/heads/branch")
        commit_sha = result.stdout.split()[0]
        log.debug(f"Remote branch {branch} is at commit {commit_sha[:8]}")

        # Step 2: Check if we already have this commit locally
        # Use rev-list with GIT_NO_LAZY_FETCH to avoid triggering promisor fetch
        check_result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-list", "-n", "1", commit_sha],
            capture_output=True,
            text=True,
            timeout=5,
            env={**os.environ, "GIT_NO_LAZY_FETCH": "1"},
        )

        if check_result.returncode == 0:
            # We already have the commit locally
            log.debug(f"Commit {commit_sha[:8]} already exists locally, skipping fetch")
            return commit_sha

        # Step 3: Commit not local, fetch just this specific commit
        # Use --filter=blob:none to avoid downloading file contents
        # Git archive (done later) will fetch only the blobs it needs for the specified paths
        # This is much faster than creating a shallow clone
        log.info(f"Commit {commit_sha[:8]} not found locally, fetching from remote with partial clone")
        subprocess.run(
            [
                "git",
                "-C",
                str(repo_path),
                "fetch",
                "--depth=1",
                "--filter=blob:none",
                remote_name,
                commit_sha,
            ],
            capture_output=True,
            text=True,
            check=True,
            timeout=300,  # 5 minute timeout for fetch
        )
        log.debug(f"Successfully fetched commit {commit_sha[:8]} (trees only, no blobs)")

        return commit_sha

    except subprocess.TimeoutExpired as e:
        log.error(f"Git operation timed out for branch {branch}")
        raise RuntimeError(
            f"Git operation timed out for branch '{branch}'. " f"This may indicate network issues."
        ) from e
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.strip() if e.stderr else str(e)
        log.error(f"Failed to resolve branch {branch}: {error_msg}")
        raise RuntimeError(
            f"Failed to resolve branch '{branch}' from remote. "
            f"Ensure the branch exists and you have access. Error: {error_msg}"
        ) from e


def get_git_metadata(repo_path: Path, remote_name: str = "origin") -> Dict[str, Any]:
    """Get git metadata for a repository.

    Args:
        repo_path: Path to git repository
        remote_name: Name of the remote (default: "origin")

    Returns:
        Dict containing git metadata (commit_sha, repo_url, etc.)
    """
    from datetime import datetime

    metadata = {
        "snapshot_mode": "git_archive",
        "generated_at_utc": datetime.utcnow().isoformat() + "Z",
    }

    try:
        # Get commit SHA
        result = subprocess.run(
            ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
        )
        metadata["commit_sha"] = result.stdout.strip()

        # Get remote URL (best effort)
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "remote", "get-url", remote_name],
                capture_output=True,
                text=True,
                check=True,
            )
            metadata["repo_url"] = result.stdout.strip()
        except subprocess.CalledProcessError:
            metadata["repo_url"] = None

        # Get current branch (best effort)
        try:
            result = subprocess.run(
                ["git", "-C", str(repo_path), "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True,
                text=True,
                check=True,
            )
            branch = result.stdout.strip()
            metadata["branch"] = branch if branch != "HEAD" else None
        except subprocess.CalledProcessError:
            metadata["branch"] = None

        # Check dirty state
        result = subprocess.run(
            ["git", "-C", str(repo_path), "status", "--porcelain"],
            capture_output=True,
            text=True,
            check=True,
        )
        metadata["dirty"] = bool(result.stdout.strip())

    except Exception as e:
        log.warning(f"Failed to get git metadata for {repo_path}: {e}")

    return metadata


def validate_include_paths_exist(repo_path: Path, commit_sha: str, include_paths: List[str]) -> None:
    """Validate that all include_paths exist at the given commit.

    Args:
        repo_path: Path to git repository
        commit_sha: Commit SHA to check paths at
        include_paths: List of paths to validate

    Raises:
        ValueError: If any path doesn't exist at commit_sha
    """

    missing_paths = []
    for path in include_paths:
        # Use git ls-tree to check if path exists at commit
        result = subprocess.run(
            ["git", "-C", str(repo_path), "ls-tree", "-d", commit_sha, path],
            capture_output=True,
            check=True,
            text=True,
        )
        if not result.stdout.strip():
            missing_paths.append(path)

    if missing_paths:
        raise ValueError(
            f"The following paths in include_paths do not exist at commit {commit_sha[:8]}: "
            f"{', '.join(missing_paths)}"
        )


def validate_include_paths_exist_on_disk(repo_path: Path, include_paths: List[str]) -> None:
    """Validate that all include_paths exist on disk relative to repo_path.

    Used for non-git directories where git ls-tree is not available.

    Args:
        repo_path: Path to the directory
        include_paths: List of relative paths to validate

    Raises:
        ValueError: If any path doesn't exist on disk
    """
    missing_paths = []
    for path in include_paths:
        full_path = repo_path / path
        if not full_path.exists():
            missing_paths.append(path)

    if missing_paths:
        raise ValueError(
            f"The following paths in include_paths do not exist in {repo_path}: " f"{', '.join(missing_paths)}"
        )


# Bump this version when packaging logic changes in a way that invalidates existing caches
# (e.g., tarball structure, metadata format, path handling semantics).
SNAPSHOT_PACKAGING_VERSION = "v1"


def compute_snapshot_cache_key(
    commit_sha: str,
    include_paths: Optional[List[str]],
) -> str:
    """Compute a stable cache key for a snapshot tarball.

    The key is a SHA-256 digest of (commit_sha, normalized include_paths,
    SNAPSHOT_PACKAGING_VERSION). Changing any of these inputs produces a
    different cache entry.

    Args:
        commit_sha: The full or partial git commit SHA.
        include_paths: Optional list of paths to include in the snapshot.

    Returns:
        A 64-character hex string (SHA-256 digest).
    """
    normalized_paths = "\n".join(sorted(p.strip() for p in include_paths)) if include_paths else ""
    key_material = f"{commit_sha}\n{normalized_paths}\n{SNAPSHOT_PACKAGING_VERSION}"
    return hashlib.sha256(key_material.encode()).hexdigest()


def create_git_archive_snapshot(
    repo_path: Path,
    commit_sha: str,
    include_paths: Optional[List[str]],
    output_tarball: str,
    directory_name: str,
) -> None:
    """Create a tarball using git archive.

    Args:
        repo_path: Path to git repository
        commit_sha: Commit SHA to archive
        include_paths: Optional list of relative paths to include. If None, archives entire repo.
        output_tarball: Path to output .tar.gz file
        directory_name: Archive name prefix (directory name in tarball)
    """
    import tempfile
    import json

    log.debug(f"Creating git archive snapshot from {repo_path}")
    log.debug(f"  Commit: {commit_sha}")
    if include_paths:
        log.debug(f"  Include paths: {include_paths}")
    else:
        log.debug("  Include paths: (all - entire repository)")

    # Get git metadata
    # Eventually we should record this as part of the workload metadata
    metadata = get_git_metadata(repo_path)
    metadata["commit_sha"] = commit_sha  # Use resolved SHA
    metadata["included_paths"] = include_paths if include_paths else []
    metadata["repo_path"] = str(repo_path)

    # Create temporary directory for archive construction
    with tempfile.TemporaryDirectory(prefix="git_archive_") as temp_dir:
        temp_path = Path(temp_dir)

        # Step 1: Create git archive
        archive_tar = temp_path / "archive.tar"
        cmd = [
            "git",
            "-C",
            str(repo_path),
            "archive",
            "--format=tar",
            f"--prefix={directory_name}/",
            "-o",
            str(archive_tar),
            commit_sha,
        ]

        # Only add paths if specified, otherwise archives entire repo
        if include_paths:
            cmd.extend(include_paths)

        try:
            subprocess.run(cmd, capture_output=True, text=True, check=True)
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to create git archive: {e.stderr}\n" f"Command: {' '.join(cmd)}") from e

        # Step 2: Extract archive to temp directory
        extract_dir = temp_path / "extracted"
        extract_dir.mkdir()
        subprocess.run(
            ["tar", "-xf", str(archive_tar), "-C", str(extract_dir)],
            capture_output=True,
            text=True,
            check=True,
        )

        # Step 3: Write metadata file into extracted directory
        metadata_dir = extract_dir / directory_name
        metadata_dir.mkdir(parents=True, exist_ok=True)
        metadata_file = metadata_dir / "SNAPSHOT_METADATA.json"

        with open(metadata_file, "w") as f:
            json.dump(metadata, f, indent=2)
        log.debug("Injected SNAPSHOT_METADATA.json into archive")

        # Step 4: Repack with metadata included
        # Use directory_name instead of "." so tarball entries are "repo_name/..."
        # rather than "./repo_name/...". The launch script parses the directory
        # name via `head -1 | cut -d/ -f1`; "./" entries yield "." which causes
        # the symlink to target $HOME/. instead of $HOME/repo_name.
        subprocess.run(
            ["tar", "-czf", output_tarball, "-C", str(extract_dir), directory_name],
            capture_output=True,
            text=True,
            check=True,
        )

    log.debug(f"Created git archive snapshot: {output_tarball}")


def _parse_gitignore(gitignore_path: Path) -> List[str]:
    """Parse a .gitignore file and return a list of patterns to exclude.

    Skips comments and empty lines. Strips trailing '/' (directory markers) since
    tar's --exclude flag doesn't distinguish files from directories.

    Negation patterns ('!' prefix) are not supported by tar's --exclude mechanism
    and are skipped with a warning.

    GNU tar's --exclude doesn't support '**' as a path-separator-agnostic wildcard
    (it treats '**' like '*', so '**/venv' only excludes venv one level deep).
    Common forms are normalized:
      - '**/foo'  → 'foo'  (basename match, tar excludes it anywhere)
      - 'foo/**'  → 'foo'  (tar excludes the whole subtree)
      - 'foo/**/bar' → skipped with a warning (no tar equivalent)
    """
    patterns = []
    for line in gitignore_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.rstrip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("!"):
            log.debug(
                f"Skipping negation pattern '{line}' in {gitignore_path}: "
                "negation is not supported for plain tarball snapshots"
            )
            continue
        line = line.rstrip("/")
        # tar --exclude doesn't support **: normalize common forms.
        # "**/foo" means "foo anywhere" → bare "foo" (basename match in tar).
        # "foo/**" means "everything under foo" → "foo" (tar excludes the subtree).
        # "foo/**/bar" has no tar equivalent; skip with a warning.
        if "**" in line:
            if line.startswith("**/"):
                line = line[3:]
            elif line.endswith("/**"):
                line = line[:-3]
            else:
                log.debug(
                    f"Skipping pattern '{line}' in {gitignore_path}: "
                    "'**' in the middle of a path is not supported for plain tarball snapshots"
                )
                continue
        patterns.append(line)
    return patterns


def create_plain_tarball(
    repo_path: Path,
    output_tarball: str,
    include_paths: Optional[List[str]] = None,
) -> None:
    """Create a tarball from a directory.

    Creates a plain tar.gz archive without using git archive.
    Can optionally archive only specific subdirectories.

    Uses tar directly to handle symlinks, special files, and other edge cases
    correctly without manual file copying. The tarball preserves the original
    directory name from the local filesystem.

    Args:
        repo_path: Path to directory to archive
        output_tarball: Path to output .tar.gz file
        include_paths: Optional list of relative paths to include. If None, archives entire directory.
    """
    if include_paths:
        log.debug(f"Creating plain tarball from {repo_path} with include_paths: {include_paths}")
    else:
        log.debug(f"Creating plain tarball from {repo_path}")

    tar_cmd = ["tar", "-czf", output_tarball]

    # Apply .gitignore exclusions if present. --exclude flags are compatible with
    # both the full-directory and include_paths forms of the tar invocation below,
    # so gitignore is honored in all cases (non-git dirs and uncommitted-changes paths).
    gitignore_file = repo_path / ".gitignore"
    if gitignore_file.exists():
        log.debug(f"Honoring .gitignore at {gitignore_file}")
        archive_root = repo_path.name
        for pattern in _parse_gitignore(gitignore_file):
            if "/" in pattern:
                # Anchor path-relative patterns to the archive root so they don't
                # match identically-named paths in subdirectories.
                tar_cmd.append(f"--exclude={archive_root}/{pattern.lstrip('/')}")
            else:
                tar_cmd.append(f"--exclude={pattern}")

    tar_cmd.append("-C")

    if include_paths:
        # Archive from parent with directory name prefix so include_paths are nested
        # under the repo directory name, matching the git archive --prefix behavior.
        # e.g. tar -C /home/user universe/research produces universe/research/... in tarball
        tar_cmd.append(str(repo_path.parent))
        tar_cmd.extend([f"{repo_path.name}/{path}" for path in include_paths])
    else:
        # Archive from parent so the directory name is preserved in the tarball
        tar_cmd.extend([str(repo_path.parent), repo_path.name])

    try:
        subprocess.run(tar_cmd, capture_output=True, text=True, check=True)
        log.debug(f"Created plain tarball: {output_tarball}")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to create plain tarball: {e.stderr}\nCommand: {' '.join(tar_cmd)}") from e
