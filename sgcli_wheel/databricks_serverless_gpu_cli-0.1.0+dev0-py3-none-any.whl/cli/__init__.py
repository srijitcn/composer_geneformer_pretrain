"""Databricks Serverless GPU CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "0.1.0+dev0"
__git_sha__ = "8dad2f628668a4dd9d94f7ba32b3337025258a80"
