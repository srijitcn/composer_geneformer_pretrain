# Custom Image Builder for SGC DCS

Guide users through building custom Docker images for Serverless GPU Compute Docker Container Service (SGC DCS).

---

## Entry Point

Start by asking the user:

> **Do you want to use Databricks base images or build your image from scratch?**
>
> 1. **Databricks base images** (recommended) — pre-configured with CUDA, NCCL, and the correct networking stack for your cloud. You just add your ML framework and application code on top.
> 2. **Build from scratch** — full control, but you must install CUDA, NCCL, and the cloud-specific RDMA/networking stack yourself.

Wait for the user's answer before proceeding.

---

## Option 1: Use Databricks Base Images

### Available Base Images

There are 4 base images published on Docker Hub at [`databricksruntime/environment-test`](https://hub.docker.com/r/databricksruntime/environment-test/tags):

| Image Tag | Cloud | CUDA Variant | Size | Use Case |
|-----------|-------|-------------|------|----------|
| `sgcdcs-test-runtime-aws` | AWS | Runtime | ~4.7 GB | `pip install` pre-built wheels only (torch, tensorflow) |
| `sgcdcs-test-devel-aws` | AWS | Devel | ~11 GB | Compile CUDA extensions (flash-attn, apex, custom kernels) |
| `sgcdcs-test-runtime-azure` | Azure | Runtime | ~4.1 GB | `pip install` pre-built wheels only |
| `sgcdcs-test-devel-azure` | Azure | Devel | ~10.3 GB | Compile CUDA extensions |

**Choosing runtime vs devel:**
- Pick **runtime** if you only `pip install` pre-built wheels (e.g., `torch`, `tensorflow`). Smaller image, faster pulls.
- Pick **devel** if you need `nvcc` to compile CUDA extensions (e.g., `flash-attn`, `apex`, custom CUDA kernels). Includes CUDA 12.9 headers and NCCL dev libraries.

**Expected final image sizes:** The sizes above are for the base image only. Adding PyTorch 2.6 adds ~5.6 GB (torch wheel + nvidia pip packages). Expect final images around **~10 GB** for runtime + PyTorch or **~17 GB** for devel + PyTorch.

### What the base images provide

All 4 variants include:
- **Ubuntu 24.04** (Noble)
- **Python 3.12.3** (symlinked to `/databricks/python/bin/python`)
- **CUDA 12.9.0** runtime libraries
- **NCCL 2.26.5** runtime (`libnccl2`)
- **cuda-compat** for forward driver compatibility
- Common tools: `curl`, `git`, `wget`, `openssh-client`, `iputils-ping`
- `OPENSSL_FORCE_FIPS_MODE=0` (workaround for Ubuntu 24.04 FIPS kernel issue)
- `NVIDIA_VISIBLE_DEVICES=all` and `NVIDIA_DRIVER_CAPABILITIES=compute,utility`

**Devel-only additions:** `nvcc` (CUDA 12.9 compiler), 168 CUDA header files, NCCL dev headers, `hwloc`/`libhwloc-dev`.

**AWS-specific networking (EFA):**
- AWS EFA 1.42.0 installer (libfabric, OpenMPI 4.1.7, aws-ofi-nccl 1.15.0 pre-built)
- `libcudart.so` symlink for GPU-direct RDMA (`FI_HMEM_CUDA`)
- `FI_EFA_USE_DEVICE_RDMA=1`
- `LD_LIBRARY_PATH` includes `/opt/amazon/ofi-nccl/lib`, `/opt/amazon/openmpi/lib`, `/opt/amazon/efa/lib`
- `PATH` includes `/opt/amazon/openmpi/bin`, `/opt/amazon/efa/bin`

**Azure-specific networking (InfiniBand):**
- `rdma-core` 50.0, `ibverbs-utils`, `infiniband-diags`, `perftest`
- `libibverbs-dev`, `librdmacm-dev`

### Example: Deriving a PyTorch training image

```dockerfile
FROM databricksruntime/environment-test:sgcdcs-test-runtime-aws

# Install PyTorch (default PyPI wheel ships cu124, compatible with CUDA 12.9)
RUN python3 -m pip install --no-cache-dir --break-system-packages \
    torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0

# Install your training dependencies
COPY requirements.txt /tmp/requirements.txt
RUN python3 -m pip install --no-cache-dir --break-system-packages -r /tmp/requirements.txt

# Copy your training code
COPY . /app
```

> **Note on `requirements.txt`:** Do not duplicate packages already installed above (e.g., `torch`, `torchvision`). Only list additional dependencies here.

For Azure, replace the base image tag with `sgcdcs-test-runtime-azure` (or `sgcdcs-test-devel-azure` if you need `nvcc`).

> **Arca / internal dev machines:** `pypi.org` is unreachable from Arca. Add `--index-url https://pypi-proxy.dev.databricks.com/simple` to every `pip install` command in the Dockerfile. Example:
> ```dockerfile
> RUN python3 -m pip install --no-cache-dir --break-system-packages \
>     --index-url https://pypi-proxy.dev.databricks.com/simple \
>     torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0
> ```
> This is not needed when building on a personal laptop or CI system with internet access.

### Example: Image that compiles flash-attention

```dockerfile
FROM databricksruntime/environment-test:sgcdcs-test-devel-aws

RUN python3 -m pip install --no-cache-dir --break-system-packages \
    torch==2.6.0
RUN python3 -m pip install --no-cache-dir --break-system-packages \
    flash-attn --no-build-isolation
```

**Note:** `flash-attn` requires `nvcc`, so you must use a `devel` variant.

### Important: WORKDIR is not honored at runtime

SGC does not use the Docker `WORKDIR` directive when running your command. Your command always runs from a platform-controlled directory (not your image's `WORKDIR`). **Always use absolute paths** when referencing files baked into the image:

```yaml
# WRONG — will fail with "No such file"
command: |-
  python train.py

# CORRECT — use the absolute path where you COPYed your code
command: |-
  python /app/train.py
```

For this reason, the examples above use `COPY . /app` (rather than `WORKDIR /workspace`) and you should reference `/app/your_script.py` in your sgcli YAML.

### Recommended: Add a `.dockerignore`

Create a `.dockerignore` in your project root to avoid bloating the image with unnecessary files:

```
__pycache__
*.pyc
.git
*.pt
*.ckpt
data/
wandb/
.venv/
```

### Dockerfiles reference

The Dockerfiles for these base images are in the universe repo at:
[`docker-images/sgc-dcs-base/`](https://github.com/databricks-eng/universe/tree/master/docker-images/sgc-dcs-base)

```
docker-images/sgc-dcs-base/
├── aws/
│   ├── runtime/Dockerfile
│   ├── devel/Dockerfile
│   ├── runtime-pytorch/Dockerfile   # example derived image
│   └── devel-pytorch/Dockerfile     # example derived image
└── azure/
    ├── runtime/Dockerfile
    ├── devel/Dockerfile
    ├── runtime-pytorch/Dockerfile   # example derived image
    └── devel-pytorch/Dockerfile     # example derived image
```

The `*-pytorch/` Dockerfiles are examples of how to derive images from the base — they add `torch==2.6.0`, `torchvision==0.21.0`, and `torchaudio==2.6.0`.

---

## Option 2: Build from Scratch

If building from scratch, you need to choose a base image and install the required components yourself.

### Step 1: Choose your base image

Ask the user:

> **Which base image do you want to start from?**
>
> We recommend the **NVIDIA CUDA base images** (they ship CUDA runtime/toolkit on Ubuntu):
> - `nvidia/cuda:12.9.0-runtime-ubuntu24.04` — runtime only (no `nvcc`), smaller image
> - `nvidia/cuda:12.9.0-devel-ubuntu24.04` — includes `nvcc`, CUDA headers (needed to compile CUDA extensions like flash-attn)
>
> You can also specify your own base image if you have one (e.g., a corporate base image with security patches, a different Ubuntu/CUDA version, etc.). Just tell me the full image reference.

Wait for the user's answer. If they provide a custom image, use it as the `FROM` line. If they pick an NVIDIA image, ask whether they need runtime or devel. Then proceed with the remaining steps — the networking and environment setup below applies regardless of the base image chosen.

**If using a custom base image**, warn the user:
- The instructions below assume Ubuntu 24.04 with CUDA 12.9.0. If their image uses a different OS or CUDA version, package names, paths, or versions may differ.
- They must ensure CUDA runtime libraries and NCCL are available in their image (either pre-installed or added in subsequent steps).

```dockerfile
# Recommended: NVIDIA CUDA base images
# For runtime-only (no nvcc):
FROM nvidia/cuda:12.9.0-runtime-ubuntu24.04

# For development (includes nvcc, CUDA headers):
FROM nvidia/cuda:12.9.0-devel-ubuntu24.04

# Or your own base image:
# FROM <your-registry>/<your-image>:<tag>
```

### Step 2: Install system packages and Python

```dockerfile
ENV DEBIAN_FRONTEND=noninteractive
# Workaround for Ubuntu 24.04 FIPS kernel issue
ENV OPENSSL_FORCE_FIPS_MODE=0

RUN apt-get update && apt-get install -y --no-install-recommends \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    ca-certificates \
    curl \
    git \
    wget \
    openssh-client \
    iputils-ping \
    && rm -rf /var/lib/apt/lists/*

# Databricks expects Python at this path
RUN mkdir -p /databricks/python/bin && \
    ln -sf /usr/bin/python3 /databricks/python/bin/python
```

### Step 3: Install cloud-specific networking

#### AWS: Install EFA (Elastic Fabric Adapter)

EFA is required for multi-node GPU communication on AWS. The EFA installer bundles libfabric, OpenMPI, and aws-ofi-nccl (the NCCL plugin for EFA).

```dockerfile
# Install hwloc (needed for topology-aware placement)
RUN apt-get update && apt-get install -y --no-install-recommends \
    hwloc libhwloc-dev \
    && rm -rf /var/lib/apt/lists/*

# Install AWS EFA (includes libfabric, OpenMPI 4.1.7, aws-ofi-nccl 1.15.0)
ARG EFA_VERSION=1.42.0
RUN cd /tmp && \
    curl -sL https://s3-us-west-2.amazonaws.com/aws-efa-installer/aws-efa-installer-${EFA_VERSION}.tar.gz \
      -o aws-efa-installer.tar.gz && \
    tar xzf aws-efa-installer.tar.gz && \
    cd aws-efa-installer && \
    apt-get update && \
    ./efa_installer.sh -y --skip-kmod --skip-limit-conf --no-verify && \
    rm -rf /var/lib/apt/lists/* && \
    cd /tmp && rm -rf aws-efa-installer aws-efa-installer.tar.gz

# libfabric needs libcudart.so (unversioned) for GPU-direct RDMA (FI_HMEM_CUDA)
RUN ln -sf libcudart.so.12 /usr/local/cuda/lib64/libcudart.so

# Environment for EFA
ENV LD_LIBRARY_PATH=/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:/opt/amazon/openmpi/lib:/opt/amazon/efa/lib${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}
ENV PATH=/opt/amazon/openmpi/bin:/opt/amazon/efa/bin${PATH:+:${PATH}}
ENV FI_EFA_USE_DEVICE_RDMA=1
```

**Note:** If building in an environment with SSL issues downloading from S3, pre-download the tarball on the host and use `COPY` instead of `curl`.

#### Azure: Install InfiniBand / RDMA

Azure uses InfiniBand for multi-node GPU communication. You need rdma-core and the associated userspace libraries.

```dockerfile
# Install RDMA/InfiniBand packages
RUN apt-get update && apt-get install -y --no-install-recommends \
    rdma-core \
    ibverbs-utils \
    infiniband-diags \
    perftest \
    libibverbs-dev \
    librdmacm-dev \
    && rm -rf /var/lib/apt/lists/*
```

**What each package provides:**
- `rdma-core` — core RDMA userspace libraries and drivers
- `ibverbs-utils` — InfiniBand verbs utilities (e.g., `ibv_devinfo`, `ibv_devices`)
- `infiniband-diags` — diagnostic tools (`ibstat`, `ibdiagnet`)
- `perftest` — RDMA bandwidth/latency benchmarks (`ib_write_bw`, `ib_read_lat`)
- `libibverbs-dev` — development headers for ibverbs (needed if compiling RDMA-aware code)
- `librdmacm-dev` — development headers for RDMA connection manager

### Step 4: Set GPU visibility

```dockerfile
ENV NVIDIA_VISIBLE_DEVICES=all
ENV NVIDIA_DRIVER_CAPABILITIES=compute,utility
```

### Step 5: Install your ML framework and application

```dockerfile
# Install PyTorch (torch 2.6.0 default wheel ships cu124, compatible with CUDA 12.9)
RUN python3 -m pip install --no-cache-dir --break-system-packages \
    torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0

# Your application dependencies
COPY requirements.txt /tmp/requirements.txt
RUN python3 -m pip install --no-cache-dir --break-system-packages \
    -r /tmp/requirements.txt

# Copy your code (use absolute path in sgcli command, e.g., python /app/train.py)
COPY . /app
```

> **Arca users:** Add `--index-url https://pypi-proxy.dev.databricks.com/simple` to every `pip install` (see Option 1 note above).

### Complete from-scratch Dockerfile (AWS example)

```dockerfile
FROM nvidia/cuda:12.9.0-runtime-ubuntu24.04

ENV DEBIAN_FRONTEND=noninteractive
ENV OPENSSL_FORCE_FIPS_MODE=0

# System packages + Python
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3 python3-pip python3-venv python3-dev \
    ca-certificates curl git wget openssh-client iputils-ping \
    hwloc libhwloc-dev \
    && rm -rf /var/lib/apt/lists/*

RUN mkdir -p /databricks/python/bin && \
    ln -sf /usr/bin/python3 /databricks/python/bin/python

# AWS EFA
ARG EFA_VERSION=1.42.0
RUN cd /tmp && \
    curl -sL https://s3-us-west-2.amazonaws.com/aws-efa-installer/aws-efa-installer-${EFA_VERSION}.tar.gz \
      -o aws-efa-installer.tar.gz && \
    tar xzf aws-efa-installer.tar.gz && \
    cd aws-efa-installer && \
    apt-get update && \
    ./efa_installer.sh -y --skip-kmod --skip-limit-conf --no-verify && \
    rm -rf /var/lib/apt/lists/* && \
    cd /tmp && rm -rf aws-efa-installer aws-efa-installer.tar.gz

RUN ln -sf libcudart.so.12 /usr/local/cuda/lib64/libcudart.so

ENV LD_LIBRARY_PATH=/opt/amazon/ofi-nccl/lib/x86_64-linux-gnu:/opt/amazon/openmpi/lib:/opt/amazon/efa/lib${LD_LIBRARY_PATH:+:${LD_LIBRARY_PATH}}
ENV PATH=/opt/amazon/openmpi/bin:/opt/amazon/efa/bin${PATH:+:${PATH}}
ENV FI_EFA_USE_DEVICE_RDMA=1
ENV NVIDIA_VISIBLE_DEVICES=all
ENV NVIDIA_DRIVER_CAPABILITIES=compute,utility

# ML framework (default PyPI wheel ships cu124, compatible with CUDA 12.9)
RUN python3 -m pip install --no-cache-dir --break-system-packages \
    torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0

# Your code (reference via absolute path in sgcli command: python /app/train.py)
COPY . /app
```

### Complete from-scratch Dockerfile (Azure example)

```dockerfile
FROM nvidia/cuda:12.9.0-runtime-ubuntu24.04

ENV DEBIAN_FRONTEND=noninteractive
ENV OPENSSL_FORCE_FIPS_MODE=0

# System packages + Python
RUN apt-get update && apt-get install -y --no-install-recommends \
    python3 python3-pip python3-venv python3-dev \
    ca-certificates curl git wget openssh-client iputils-ping \
    && rm -rf /var/lib/apt/lists/*

RUN mkdir -p /databricks/python/bin && \
    ln -sf /usr/bin/python3 /databricks/python/bin/python

# Azure InfiniBand / RDMA
RUN apt-get update && apt-get install -y --no-install-recommends \
    rdma-core ibverbs-utils infiniband-diags perftest \
    libibverbs-dev librdmacm-dev \
    && rm -rf /var/lib/apt/lists/*

ENV NVIDIA_VISIBLE_DEVICES=all
ENV NVIDIA_DRIVER_CAPABILITIES=compute,utility

# ML framework (default PyPI wheel ships cu124, compatible with CUDA 12.9)
RUN python3 -m pip install --no-cache-dir --break-system-packages \
    torch==2.6.0 torchvision==0.21.0 torchaudio==2.6.0

# Your code (reference via absolute path in sgcli command: python /app/train.py)
COPY . /app
```

---

## Compatibility Check

**After generating the Dockerfile, always perform this compatibility check before telling the user to build.** This is a best-effort static analysis — verify each item and report a summary table to the user.

### Step 1: Look up the host GPU driver version

Read the GPU driver versions from `kubernetes/node-image/ansible/common_vars_gpu.yml`. The key variables are:

| Cloud | Variable | Current Driver |
|-------|----------|---------------|
| AWS (EKS Ubuntu) | `UBUNTU_CUDA_DRIVER_VERSION` | 550.144.03 |
| Azure (AKS Azure Linux) | `AZURE_LINUX_CUDA_DRIVER_VERSION` | 580.105.08 |
| AWS (AL2023) | `AL2023_CUDA_DRIVER_VERSION` | 580.126.16 |

**Always read the file fresh** — these versions change over time. Use:

```bash
grep -E '(UBUNTU_CUDA_DRIVER_VERSION|AZURE_LINUX_CUDA_DRIVER_VERSION|AL2023_CUDA_DRIVER_VERSION)' \
  kubernetes/node-image/ansible/common_vars_gpu.yml
```

Also check image-specific overrides if the user mentions a specific node image type.

### Step 2: Check CUDA toolkit vs host driver compatibility

The NVIDIA CUDA toolkit requires a minimum driver version. Reference matrix (common versions):

| CUDA Toolkit | Minimum Driver (Linux) |
|-------------|----------------------|
| 12.9.x | 570.86.15+ |
| 12.8.x | 570.86.15+ |
| 12.6.x | 560.28.03+ |
| 12.4.x | 550.54.14+ |
| 12.2.x | 535.54.03+ |
| 11.8.x | 520.61.05+ |

If the host driver is older than the minimum required:
- Check if the base image includes `cuda-compat` (the Databricks base images do). With `cuda-compat`, the container can use a newer CUDA toolkit than the host driver natively supports, as long as the GPU architecture is supported.
- If building from scratch without `cuda-compat`, warn the user to install it: `apt-get install -y cuda-compat` or pick a CUDA toolkit version compatible with the host driver.

### Step 3: Check PyTorch vs CUDA compatibility

| PyTorch | Default PyPI wheel | Compatible CUDA Toolkit | PyTorch index variant |
|---------|-------------------|------------------------|----------------------|
| 2.6.x | cu124 | CUDA 12.4+ (works on 12.9 via minor version compat) | cu126 available via `--index-url https://download.pytorch.org/whl/cu126` |
| 2.5.x | cu124 | CUDA 12.4+ | cu126 available |
| 2.7.x | cu128 | CUDA 12.8+ (**may fail on 12.9 depending on APIs used**) | cu126 available |
| 2.4.x | cu124 | CUDA 12.4+ | — |
| 2.3.x | cu121 | CUDA 12.1+ | — |

**Key rules:**
- `torch>=2.7` from the default PyPI index ships cu128. If you need cu126 compatibility, use the PyTorch index URL.
- The default `pip install torch==2.6.0` installs `torch==2.6.0+cu124`, **not** cu126. This still works on CUDA 12.9 via forward compatibility.
- Always verify with `python3 -c "import torch; print(torch.version.cuda)"` after building.

### Step 4: Check NCCL compatibility

- NCCL 2.x is generally backward-compatible within major version.
- The NCCL version in the image should be >= the version expected by the installed PyTorch. PyTorch bundles its own NCCL, so this is usually not an issue unless the user is overriding NCCL.
- If the user installs a standalone NCCL, check it matches the CUDA major version.

### Step 5: Check EFA / RDMA version compatibility

- **AWS EFA**: The EFA installer version should match what's tested on the node image. Check `kubernetes/node-image/ansible/common_vars_gpu.yml` for `EFA_INSTALLER_VERSION` if present, or note the version used in the Databricks base images (currently 1.42.0).
- **Azure RDMA**: `rdma-core` from Ubuntu apt is generally compatible. No special version pinning needed.

### Step 6: Report compatibility summary

Present a table to the user:

```
## Compatibility Check

| Check | Status | Details |
|-------|--------|---------|
| CUDA toolkit vs host driver | OK/WARN | CUDA X.Y needs driver >= Z; host has W [+cuda-compat] |
| PyTorch vs CUDA | OK/FAIL | torch A.B ships cuXYZ, image has CUDA X.Y |
| NCCL vs CUDA | OK/WARN | NCCL X.Y.Z with CUDA X.Y |
| EFA/RDMA version | OK/WARN | EFA X.Y.Z matches/differs from node image |
| Python version | OK/WARN | Python X.Y matches/differs from Environment v5 |
```

If any check is FAIL, stop and help the user fix the Dockerfile before proceeding. If WARN, explain the risk and let the user decide.

---

## Version Alignment

These images are aligned with [Serverless GPU Environment Version 5](https://docs.databricks.com/aws/en/release-notes/serverless/environment-version/five-gpu):

| Component | Base Images | Environment v5 |
|-----------|------------|----------------|
| Ubuntu | 24.04 | 24.04 |
| Python | 3.12.3 | 3.12.3 |
| CUDA | 12.9.0 | 12.9 |
| NCCL | 2.26.5 | 2.27.5 |

---

## Verification

After building your image, verify the components are installed correctly:

```bash
docker run --rm <your-image> bash -c '
  echo "Python: $(python3 --version)"
  python3 -c "import torch; print(f\"PyTorch: {torch.__version__}, CUDA: {torch.version.cuda}\")" 2>/dev/null || echo "PyTorch: not installed"
  nvcc --version 2>/dev/null || echo "nvcc: not available (runtime image)"
  dpkg -l | grep -E "nccl|efa|fabric|rdma" | awk "{print \$2, \$3}"
'
```

---

## Pushing Your Image

Push to a Docker registry accessible from your Databricks workspace:

```bash
docker tag <your-image> <registry>/<repo>:<tag>
docker push <registry>/<repo>:<tag>
```

## Registering and Running Your Image

Before you can use a custom image with sgcli, you must **register** it. Registration tells the platform to pull and cache your image — this is a one-time step per image SHA.

### Step 1: Register the image

```bash
sgcli register image <registry>/<repo>:<tag> -p <profile>
```

For private registries, provide credentials:
```bash
sgcli register image <registry>/<repo>:<tag> -p <profile> --interactive-authenticate
```

Registration takes **2–6 minutes** depending on image size (the status will show `PENDING` while the platform pulls and caches the image). The command blocks until the image is ready.

### Step 2: Reference the image in your sgcli YAML

```yaml
experiment_name: my-training-job

compute:
  gpus: 1
  gpu_type: a10

environment:
  docker_image:
    url: <registry>/<repo>:<tag>

command: |-
  python /app/train.py --epochs 5
```

> **Important:** Use absolute paths in `command` (e.g., `/app/train.py`) — the Docker `WORKDIR` is not honored at runtime. See the "WORKDIR is not honored" section above.

### Step 3: Submit the job

```bash
sgcli run -f my_config.yaml -p <profile> --watch
```
