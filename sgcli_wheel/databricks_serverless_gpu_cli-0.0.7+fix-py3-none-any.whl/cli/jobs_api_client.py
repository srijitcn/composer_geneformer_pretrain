"""Jobs API client for Skyrun workload management (CLI version).

This module provides a CLI-compatible client for interacting with the Databricks Jobs API.
It works outside the notebook environment by using environment variables and config files
for authentication instead of dbutils.
"""

import json
import logging
import time
import sys
from typing import Dict, Any, Optional, List
import requests
import subprocess
import uuid

from datetime import datetime
from cli.base_client import WorkloadClient, WorkloadClientType
from cli.compute import GPUType
from cli.utils import (
    get_current_user_email,
    get_dl_runtime_image,
    get_usage_policy_id,
    prepare_launch_script_simple,
    ScriptType,
    get_workspace_client,
)
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.iam import AccessControlRequest, PermissionLevel as SdkPermissionLevel
from databricks.sdk.errors.platform import ResourceAlreadyExists, ResourceDoesNotExist
from cli.cli_output import print_error, print_info, print_success, is_json_mode
from rich.console import Console

log = logging.getLogger(__name__)
_console = Console()
logging.getLogger("databricks.sdk").setLevel(logging.WARNING)


class SubmissionError(Exception):
    """Raised when workload submission fails after retries."""


def _attempt_auto_login(host: str) -> bool:
    """Attempt to automatically login the user by running databricks auth login.

    This will:
    1. Prompt the user to confirm they want to login
    2. Run 'databricks auth login' which should open the browser automatically
    3. Parse output for URLs and try to open them if browser doesn't open automatically

    Args:
        host: The workspace host URL to login to

    Returns:
        bool: True if login attempt was made (success unknown), False if user declined
    """
    # Check if we're in an interactive terminal
    if not sys.stdin.isatty():
        return False

    try:
        # Prompt user
        print_info(f"\nAuthentication required for {host}")
        print("Would you like to login now? This will open your browser. [Y/n]: ", end="", flush=True)
        response = input().strip().lower()

        if response in ["n", "no"]:
            return False

        print_info(f"\nOpening browser to login to {host}...")
        print_info("You will be prompted to enter a profile name.\n")

        # Run databricks auth login - let it run interactively so user can:
        # - See prompts for profile name
        # - See the browser opening message
        # - Complete OAuth flow
        result = subprocess.run(
            ["databricks", "auth", "login", "--host", host],
            timeout=300,  # 5 minute timeout for completing login
        )

        if result.returncode == 0:
            print_success("\n✓ Login successful!")
            return True
        else:
            print_error(f"\n✗ Login failed. Please try manually: databricks auth login --host {host}")
            return False

    except subprocess.TimeoutExpired:
        print_error("\n✗ Login timed out after 5 minutes. Please try again.")
        return False
    except KeyboardInterrupt:
        print_error("\n✗ Login cancelled by user.")
        return False
    except Exception as e:
        log.debug("Auto-login failed with error: %s", e)
        return False


def _get_auth_headers(w: WorkspaceClient, retry_login: bool = True) -> Dict[str, str]:
    """Get authentication headers for API requests.

    Args:
        w: WorkspaceClient instance to use for authentication.
        retry_login: If True, attempt automatic login on auth failure (default: True).

    Returns:
        Dict[str, str]: Headers dictionary with Authorization header.

    Raises:
        RuntimeError: If authentication fails or times out.

    Note:
        TODO: Add token caching with 1hr TTL to avoid repeated auth calls.
    """

    host = w.config.host.rstrip("/")

    # If the client was configured with a token directly, use it
    if w.config.token:
        return {"Authorization": f"Bearer {w.config.token}"}

    # Otherwise, get a fresh OAuth token from the databricks CLI with timeout

    try:
        token_output = subprocess.check_output(
            ["databricks", "auth", "token", host], text=True, timeout=30, stderr=subprocess.PIPE
        ).strip()
        token_data = json.loads(token_output)
        access_token = token_data["access_token"]
        return {"Authorization": f"Bearer {access_token}"}
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(
            "Authentication timed out after 30 seconds. "
            "The 'databricks auth token' command did not respond. "
            "Please check your authentication configuration with 'databricks auth profiles'."
        ) from e
    except subprocess.CalledProcessError as e:
        stderr = e.stderr.decode() if e.stderr else ""

        # Try automatic login if this is the first attempt
        if retry_login and _attempt_auto_login(host):
            # Retry authentication once after successful login
            try:
                return _get_auth_headers(w, retry_login=False)
            except Exception:
                # If retry still fails, fall through to original error
                pass

        raise RuntimeError(
            f"Authentication failed with exit code {e.returncode}. "
            f"Error: {stderr}\n"
            f"Please run 'databricks auth login --host {host}' to re-authenticate."
        ) from e
    except json.JSONDecodeError as e:
        # Try automatic login if this is the first attempt
        if retry_login and _attempt_auto_login(host):
            # Retry authentication once after successful login
            try:
                return _get_auth_headers(w, retry_login=False)
            except Exception:
                # If retry still fails, fall through to original error
                pass

        raise RuntimeError(
            f"Failed to parse authentication token response. "
            f"The 'databricks auth token' command returned invalid JSON. "
            f"Please run 'databricks auth login --host {host}' to re-authenticate."
        ) from e


def get_mlflow_experiment_name(
    w: WorkspaceClient, experiment_name: str, experiment_directory: Optional[str] = None
) -> str:
    """Get the MLflow experiment name.

    Args:
        w: WorkspaceClient instance.
        experiment_name: Name of the experiment.
        experiment_directory: Optional custom experiment directory. If provided, must start with /Workspace.
                             If not provided, defaults to /Users/{user_name}.

    Returns:
        Full experiment path (e.g., /Users/user@example.com/experiment_name or /Workspace/shared/experiment_name)
    """
    if experiment_directory:
        # Custom directory provided - append experiment name
        return f"{experiment_directory.rstrip('/')}/{experiment_name}"
    else:
        # Default to user's home directory
        return f"/Users/{get_current_user_email()}/{experiment_name}"


def get_or_create_mlflow_experiment(w: WorkspaceClient, experiment_name: str) -> str:
    """Get an existing MLflow experiment or create it if it doesn't exist.

    Args:
        w: WorkspaceClient instance.
        experiment_name: The full MLflow experiment path (e.g., /Users/user@example.com/name).

    Returns:
        The experiment_id of the existing or newly created experiment.
    """
    try:
        existing = w.experiments.get_by_name(experiment_name)
        if existing and existing.experiment and existing.experiment.experiment_id:
            log.debug(f"Found existing MLflow experiment: {experiment_name}")
            return existing.experiment.experiment_id

    except ResourceDoesNotExist:
        log.debug(f"Experiment {experiment_name} does not exist. Creating it.")

    log.debug(f"Creating MLflow experiment: {experiment_name}")
    try:
        created = w.experiments.create_experiment(name=experiment_name)
        return created.experiment_id
    except ResourceAlreadyExists:
        # Race condition: another process created the experiment between our get and create.
        # Fall back to fetching the now-existing experiment.
        log.debug(f"Experiment {experiment_name} was created concurrently, fetching it.")
        existing = w.experiments.get_by_name(experiment_name)
        if existing and existing.experiment and existing.experiment.experiment_id:
            return existing.experiment.experiment_id
        raise RuntimeError(f"MLflow experiment '{experiment_name}' exists but could not be fetched after conflict.")


def grant_workload_permissions(
    w: WorkspaceClient,
    job_id: str,
    experiment_id: str,
    permission_grants: Optional[List[Any]],
) -> None:
    """Grant permissions on both the job and MLflow experiment to users, groups, or service principals.

    This function adds permissions without removing existing ones (like the owner's permissions).
    It uses permissions.update() instead of permissions.set() to preserve existing permissions.

    Permissions are granted on both:
    1. The Databricks job (for job management access)
    2. The MLflow experiment (for experiment/run viewing and management)

    Args:
        w: WorkspaceClient instance.
        job_id: The job ID to grant permissions on.
        experiment_id: The MLflow experiment ID. Use get_or_create_mlflow_experiment
            to obtain this before calling, ensuring the experiment exists.
        permission_grants: List of PermissionGrant objects from yaml_config.

    Raises:
        Exception: If permission granting fails.
    """
    if not permission_grants:
        return

    JOB_TO_EXPERIMENT_PERMISSION = {
        SdkPermissionLevel.CAN_VIEW: SdkPermissionLevel.CAN_READ,
        SdkPermissionLevel.CAN_MANAGE_RUN: SdkPermissionLevel.CAN_EDIT,
        SdkPermissionLevel.CAN_MANAGE: SdkPermissionLevel.CAN_MANAGE,
        SdkPermissionLevel.IS_OWNER: SdkPermissionLevel.CAN_MANAGE,
    }

    try:
        # Convert permission grants to AccessControlRequest objects
        job_access_control_list = []
        experiment_access_control_list = []
        for grant in permission_grants:
            # Map permission level string to SDK enum (name-based lookup).
            # grant.permission_level is validated as a PermissionLevel.value string
            # in yaml_config.py — this works because PermissionLevel enum names
            # match their values (e.g. CAN_MANAGE = "CAN_MANAGE").
            permission_level = SdkPermissionLevel[grant.permission_level]
            experiment_permission_level = JOB_TO_EXPERIMENT_PERMISSION[permission_level]

            # Create AccessControlRequest based on type
            if grant.type.value == "user":
                job_access_control_list.append(
                    AccessControlRequest(user_name=grant.name, permission_level=permission_level)
                )
                experiment_access_control_list.append(
                    AccessControlRequest(user_name=grant.name, permission_level=experiment_permission_level)
                )
            elif grant.type.value == "group":
                job_access_control_list.append(
                    AccessControlRequest(group_name=grant.name, permission_level=permission_level)
                )
                experiment_access_control_list.append(
                    AccessControlRequest(group_name=grant.name, permission_level=experiment_permission_level)
                )
            elif grant.type.value == "service_principal":
                job_access_control_list.append(
                    AccessControlRequest(service_principal_name=grant.name, permission_level=permission_level)
                )
                experiment_access_control_list.append(
                    AccessControlRequest(
                        service_principal_name=grant.name, permission_level=experiment_permission_level
                    )
                )
        # Grant permissions on the job
        log.debug(f"Granting permissions on job {job_id} to {len(job_access_control_list)} principals")
        w.permissions.update(
            request_object_type="jobs", request_object_id=job_id, access_control_list=job_access_control_list
        )

        # Grant permissions on the MLflow experiment
        log.debug(
            f"Granting permissions on experiment {experiment_id} to {len(experiment_access_control_list)} principals"
        )
        w.permissions.update(
            request_object_type="experiments",
            request_object_id=experiment_id,
            access_control_list=experiment_access_control_list,
        )

        log.debug(f"Successfully granted permissions on job {job_id} and experiment")

    except Exception as e:
        log.error(f"Failed to grant permissions on workload: {e}")
        raise


def submit_workload(
    payload: dict,
    w: WorkspaceClient,
    idempotency_token: str,
    max_attempts: int = 3,
    backoff_seconds: float = 2.0,
) -> dict:
    """Submit a workload to the Jobs API endpoint.

    Args:
        payload: The Jobs API payload dictionary for runs/submit.
        w: WorkspaceClient instance to use for authentication.
        idempotency_token: Token to ensure idempotent submission (required, max 64 chars).
        max_attempts: Maximum number of submission attempts (default: 3).
        backoff_seconds: Initial backoff_s time for retries (default: 2.0).

    Returns:
        dict: Response from the API including run_id and run_url.
    """
    host = w.config.host.rstrip("/")
    headers = _get_auth_headers(w)
    headers["Content-Type"] = "application/json"

    url = f"{host}/api/2.2/jobs/runs/submit"
    submit_payload = dict(payload)

    # Inject idempotency token (Databricks caps this at 64 chars; be defensive)
    token = idempotency_token[:64]
    submit_payload["idempotency_token"] = token
    log.debug(f"Using idempotency_token={token!r} for runs/submit")

    last_exception: Optional[Exception] = None

    for attempt in range(1, max_attempts + 1):
        try:
            log.debug(
                "Submitting one-time run (attempt %s/%s)...",
                attempt,
                max_attempts,
            )
            submit_response = requests.post(
                url=url,
                headers=headers,
                json=submit_payload,
                timeout=120,
            )
            submit_response.raise_for_status()
            submit_data = submit_response.json()

            run_id = submit_data.get("run_id")
            if run_id is None:
                raise SubmissionError(f"runs/submit response missing run_id: {submit_data}")

            log.debug(f"Jobs API runs/submit response: {submit_data}")

            # Construct the run hyperlink
            response_data: Dict[str, Any] = {"run_id": run_id}

            try:
                workspace_id = w.get_workspace_id()
                if workspace_id:
                    run_url = f"{host}/jobs/runs/{run_id}?o={workspace_id}"
                else:
                    run_url = None
                    log.warning("Missing workspace_id, unable to construct full run URL")
                response_data["run_url"] = run_url
            except Exception as e:
                log.warning(f"Failed to construct full run URL: {e}")
                response_data["run_url"] = None

            return response_data

        except (requests.Timeout, requests.ConnectionError) as e:
            # Transient network issues: we can safely retry with same token
            last_exception = e
            log.warning(
                "Transient error during runs/submit (attempt %s/%s): %s",
                attempt,
                max_attempts,
                e,
            )
            if attempt < max_attempts:
                sleep_for = backoff_seconds * (2 ** (attempt - 1))
                log.info("Retrying in %.1f seconds...", sleep_for)
                time.sleep(sleep_for)
            continue

        except requests.HTTPError as e:
            # For HTTP errors, it's often better NOT to hammer retries,
            # but we still allow a couple of attempts in case of 5xx.
            last_exception = e
            status = e.response.status_code if e.response is not None else None
            body = e.response.text if e.response is not None else "<no body>"

            log.error(
                "HTTP error from runs/submit (status=%s) on attempt %s/%s: %s\nBody: %s",
                status,
                attempt,
                max_attempts,
                e,
                body,
            )

            # Retry only on 5xx; 4xx are usually permanent (bad payload, perms, etc.)
            if status is not None and 500 <= status < 600 and attempt < max_attempts:
                sleep_for = backoff_seconds * (2 ** (attempt - 1))
                log.info("Retrying in %.1f seconds due to 5xx...", sleep_for)
                time.sleep(sleep_for)
                continue

            raise

    # If we exhausted the loop
    raise SubmissionError(f"Failed to submit workload after {max_attempts} attempts") from last_exception


class JobsApiClient(WorkloadClient):
    """Client for Databricks Jobs API workload management.

    This client encapsulates all Jobs API specific logic for workload creation,
    monitoring, and management. This CLI version works without notebook context.
    """

    def __init__(self, workspace_host: Optional[str] = None):
        """Initialize the JobsApiClient.

        Args:
            workspace_host: Optional workspace host URL. If provided, this will be used
                           instead of the default configuration.
        """
        self.workspace_host = workspace_host

    def _get_workspace_client(self) -> WorkspaceClient:
        """Get a WorkspaceClient instance with appropriate configuration.

        Returns:
            WorkspaceClient: Configured workspace client instance.
        """
        return get_workspace_client(workspace_host=self.workspace_host)

    @property
    def client_type(self) -> WorkloadClientType:
        """Get the client type for logging and debugging."""
        return WorkloadClientType.JOBS_API

    def create_workload(
        self,
        gpus: int,
        gpus_per_node: int,
        workspace_zip_path: Optional[str],
        script_filename: str,
        func_dir: str,
        experiment_name: str,
        timeout_seconds: int,
        param_to_args: dict,
        env_sync_timeout: int,
        gpu_type: GPUType,
        yaml_config_path: str,
        max_retries: int = 0,
        script_type: ScriptType = ScriptType.BASH,
        tar_workspace_path: Optional[str] = None,
        tar_directory_name: Optional[str] = None,
        env_variables: Optional[dict] = None,
        env_variables_secrets: Optional[dict] = None,
        requirements_filename: Optional[str] = None,
        parameters_yaml_path: Optional[str] = None,
        sanity_check_script_path: Optional[str] = None,
        mlflow_system_metrics_script_path: Optional[str] = None,
        docker_image_url: Optional[str] = None,
        runtime_version: Optional[str] = None,
        gpu_node_pool_id: Optional[str] = None,
        idempotency_token: Optional[str] = None,
        use_foreach: bool = False,
        foreach_iterations: int = 3,
        run_name: Optional[str] = None,
        experiment_directory: Optional[str] = None,
        grant_permissions: Optional[List[Any]] = None,
        budget_policy_id: Optional[str] = None,
        notification_email: Optional[str] = None,
        priority: Optional[int] = None,
        dry_run: bool = False,
    ) -> str:
        """Create workload via Jobs API.

        This method prepares the launch script, builds the Jobs API payload, and submits the workload.
        Multiple calls to create_workload with the same idempotency_token will be deduplicated by
        the API, ensuring that only a single workload is created.

        Args:
            gpus: Total number of GPUs to allocate for the workload
            gpus_per_node: Number of GPUs per compute node (determines node count)
            workspace_zip_path: Optional path to the zip file in workspace containing the script
            script_filename: Name of the script inside the zip file
            func_dir: Directory containing the function artifacts and scripts
            experiment_name: Name of the function/workload for identification
            run_name: Name of execution instance of this workload. This is used to identify the run in MLflow and in Jobs.
            timeout_seconds: Maximum execution time in seconds before timeout
            param_to_args: Dictionary of parameters to pass to the function
            env_sync_timeout: Timeout in seconds for environment synchronization
            gpu_type: Type of GPU to use (e.g., H100, A100, etc.)
            yaml_config_path: Path to YAML configuration file in workspace
            max_retries: Maximum number of retries for failed tasks (default: 0)
            script_type: Type of script - ScriptType.BASH or ScriptType.COMMAND (default: ScriptType.BASH)
            tar_workspace_path: Optional path to tarball in workspace to extract before running script
            tar_directory_name: Top-level directory name inside the tarball (equivalent to repo_path.name).
                Required when tar_workspace_path is set.
            env_variables: Optional dict of regular environment variables to export
            env_variables_secrets: Optional dict mapping "scope/key" to "ENV_VAR_NAME" for secrets
            requirements_filename: Optional name of requirements.yaml file uploaded to workspace (always local, e.g., 'requirements.yaml')
            parameters_yaml_path: Optional path to hyperparameters YAML file in workspace
            sanity_check_script_path: Optional path to node sanity check script in workspace
            mlflow_system_metrics_script_path: Optional path to MLflow system metrics monitoring script in workspace
            docker_image_url: Optional custom docker image URL. When specified, overrides the default DL runtime image.
            runtime_version: Optional runtime version string (integer >= 4, e.g., '4' or '5') extracted from requirements.yaml. Converted to CLIENT-GPU-{version}.
            gpu_node_pool_id: Optional GPU node pool ID for compute placement
            idempotency_token: Optional token to ensure idempotent submission. If not provided, a unique UUID is generated.
            use_foreach: Whether to wrap the task in a ForEach task for hyperparameter sweeps (default: False)
            foreach_iterations: Number of ForEach iterations to create (default: 3, only used when use_foreach=True)
            experiment_directory: Optional custom experiment directory (must start with /Workspace). If not provided, defaults to /Users/{user_name}.
            grant_permissions: Optional list of PermissionGrant objects to grant permissions on the job after submission.
            dry_run: If True, prepare workload but skip submitting to Jobs API (default: False)

        Returns:
            str: The run_id of the created Jobs API workload (None for dry-run)

        Raises:
            RuntimeError: If workload creation fails due to API errors
        """
        print_info(f"Creating workload via Jobs API for experiment: {experiment_name}")

        # Job run name is always the experiment_name
        # run_name parameter (if provided) is only used for MLflow run name
        job_run_name = experiment_name
        mlflow_run_name = run_name if run_name else experiment_name

        # Prepare launch script with distributed training configuration
        launch_script = prepare_launch_script_simple(
            gpus=gpus,
            gpus_per_node=gpus_per_node,
            workspace_zip_path=workspace_zip_path,
            script_filename=script_filename,
            func_dir=func_dir,
            script_type=script_type,
            tar_workspace_path=tar_workspace_path,
            tar_directory_name=tar_directory_name,
            env_variables=env_variables or {},
            env_variables_secrets=env_variables_secrets or {},
            requirements_filename=requirements_filename,
            parameters_yaml_path=parameters_yaml_path,
            sanity_check_script_path=sanity_check_script_path,
            mlflow_system_metrics_script_path=mlflow_system_metrics_script_path,
            docker_image_url=docker_image_url,
            run_name=mlflow_run_name,
        )

        mlflow_experiment_name = get_mlflow_experiment_name(
            w=self._get_workspace_client(),
            experiment_name=experiment_name,
            experiment_directory=experiment_directory,
        )

        # Build Jobs API payload
        payload = self._build_jobs_payload(
            experiment_name=experiment_name,
            job_run_name=job_run_name,
            timeout_seconds=timeout_seconds,
            launch_script=launch_script,
            gpus=gpus,
            gpu_type=gpu_type,
            yaml_config_path=yaml_config_path,
            max_retries=max_retries,
            mlflow_experiment_name=mlflow_experiment_name,
            docker_image_url=docker_image_url,
            runtime_version=runtime_version,
            gpu_node_pool_id=gpu_node_pool_id,
            use_foreach=use_foreach,
            foreach_iterations=foreach_iterations,
            budget_policy_id=budget_policy_id,
            notification_email=notification_email,
            priority=priority,
        )

        # Log the payload for debugging
        log.debug("Jobs API payload: %s", json.dumps(payload, indent=2))

        # Generate idempotency token if not provided
        if idempotency_token is None:
            idempotency_token = str(uuid.uuid4())
            log.debug("Generated idempotency token: %s", idempotency_token)
        else:
            log.debug("Using provided idempotency token: %s", idempotency_token)

        if dry_run:
            log.info("dry-run mode: skipping job submission to Jobs API")
            return {
                "run_id": None,
                "run_url": None,
                "job_run_name": job_run_name,
            }

        try:
            w = self._get_workspace_client()

            # Pre-create the MLflow experiment before job submission so permissions can be
            # granted immediately after, avoiding the race condition where the experiment
            # node doesn't exist yet when the job is first submitted.
            experiment_id: Optional[str] = None
            if grant_permissions and mlflow_experiment_name:
                try:
                    experiment_id = get_or_create_mlflow_experiment(w, mlflow_experiment_name)
                except Exception as e:
                    log.warning(f"Unable to get or create MLflow experiment. Skipping permission grant: {e}")

            result = submit_workload(payload, w, idempotency_token=idempotency_token)
            run_id = result.get("run_id")
            run_url = result.get("run_url")

            print_success(f"Submitted workload with Job Run ID: {run_id}")
            if run_url and not is_json_mode():
                _console.print(f"View job run at: [cyan][link={run_url}]{run_url}[/link][/cyan]")

            # Add job_run_name to result so caller can use it
            result["job_run_name"] = job_run_name

            # Grant permissions if specified
            if grant_permissions and experiment_id:
                try:
                    # Get the job_id from the run to grant permissions
                    run = w.jobs.get_run(run_id=int(run_id))
                    job_id = str(run.job_id)
                    grant_workload_permissions(
                        w=w, job_id=job_id, experiment_id=experiment_id, permission_grants=grant_permissions
                    )
                except Exception as e:
                    log.warning(f"Failed to grant permissions on workload: {e}")
                    log.warning("Job was created successfully, but permissions could not be granted.")

            # For foreach sweeps, wait briefly and fetch nested task IDs
            if use_foreach:
                log.info("Waiting for sweep tasks to initialize...")
                time.sleep(1)

                try:
                    # Fetch run details to get the ForEach task
                    w = self._get_workspace_client()
                    run = w.jobs.get_run(run_id=int(run_id))

                    foreach_task_run_id = None
                    if run.tasks:
                        for task in run.tasks:
                            # Find the ForEach task
                            if hasattr(task, "for_each_task") and task.for_each_task:
                                foreach_task_run_id = task.run_id
                                break

                    # Now fetch the ForEach task's run to get iteration tasks
                    iteration_task_ids = []
                    if foreach_task_run_id:
                        foreach_run = w.jobs.get_run(run_id=int(foreach_task_run_id))
                        # Iteration tasks are in the 'iterations' field
                        if hasattr(foreach_run, "iterations") and foreach_run.iterations:
                            for iteration in foreach_run.iterations:
                                if hasattr(iteration, "run_id") and iteration.run_id:
                                    iteration_task_ids.append(iteration.run_id)

                    log.info("Sweep run ID: %s", run_id)
                    if iteration_task_ids:
                        log.info("Task IDs: %s", ", ".join(str(tid) for tid in iteration_task_ids))
                    else:
                        log.info("Iteration tasks not yet available. Use 'get status %s' to see details.", run_id)
                except Exception as e:
                    log.warning("Could not fetch task IDs immediately: %s", e)
                    log.info("Use 'get status %s' to see task details once initialized.", run_id)

            return result

        except requests.exceptions.RequestException as e:
            log.error("Failed to create Jobs API workload: %s", e)
            raise RuntimeError(f"Jobs API workload creation failed: {e}") from e

    def get_workload_status(self, workload_id: str) -> Dict[str, Any]:
        """Get workload status via Jobs API SDK.

        This method uses the Databricks SDK to get run status information.

        Args:
            workload_id: The run_id of the workload to get status for

        Returns:
            Dict[str, Any]: Dictionary containing workload status and details with structure:
                {
                    "run_id": str,
                    "job_id": int,
                    "state": {
                        "life_cycle_state": str,
                        "result_state": str
                    },
                    "start_time": int (milliseconds),
                    "end_time": int (milliseconds) or None,
                    "tasks": List[Dict] with attempt_number,
                    "yaml_parameters_file_path": str or None (path to training config YAML),
                    "task_type": str ("gen_ai_compute" or "for_each"),
                    "for_each_stats": Dict or None (ForEach iteration statistics if applicable)
                }

        Raises:
            Exception: If the run doesn't exist or API call fails
        """
        w = self._get_workspace_client()

        try:
            run = w.jobs.get_run(run_id=int(workload_id))

            # Convert SDK Run object to dictionary format
            result = {
                "run_id": run.run_id,
                "job_id": run.job_id,
                "state": {
                    "life_cycle_state": run.state.life_cycle_state.value
                    if run.state and run.state.life_cycle_state
                    else "UNKNOWN",
                    "result_state": run.state.result_state.value if run.state and run.state.result_state else "",
                },
                "start_time": run.start_time,
                "end_time": run.end_time,
                "tasks": [],
                "yaml_parameters_file_path": None,
                "task_type": "gen_ai_compute",
                "for_each_stats": None,
            }

            # Extract task information including attempt numbers and yaml_parameters_file_path
            if run.tasks:
                for task in run.tasks:
                    task_info = {
                        "task_key": task.task_key,
                        "attempt_number": task.attempt_number if task.attempt_number is not None else 0,
                        "state": {
                            "life_cycle_state": task.state.life_cycle_state.value
                            if task.state and task.state.life_cycle_state
                            else "UNKNOWN",
                            "result_state": task.state.result_state.value
                            if task.state and task.state.result_state
                            else "",
                        },
                    }

                    # Include gen_ai_compute_task if available (for experiment name, etc.)
                    if hasattr(task, "gen_ai_compute_task") and task.gen_ai_compute_task:
                        gen_ai_task = task.gen_ai_compute_task
                        gen_ai_task_dict = {}
                        if hasattr(gen_ai_task, "mlflow_experiment_name"):
                            gen_ai_task_dict["mlflow_experiment_name"] = gen_ai_task.mlflow_experiment_name
                        if hasattr(gen_ai_task, "yaml_parameters_file_path"):
                            gen_ai_task_dict["yaml_parameters_file_path"] = gen_ai_task.yaml_parameters_file_path
                        if gen_ai_task_dict:
                            task_info["gen_ai_compute_task"] = gen_ai_task_dict

                    result["tasks"].append(task_info)

                    # Check if this is a ForEach task
                    if hasattr(task, "for_each_task") and task.for_each_task:
                        result["task_type"] = "for_each"
                        # Extract ForEach stats if available
                        if hasattr(task.state, "for_each_stats") and task.state.for_each_stats:
                            # Convert ForEach stats to dict
                            for_each_stats = task.state.for_each_stats
                            stats_dict = {}
                            if hasattr(for_each_stats, "task_run_stats") and for_each_stats.task_run_stats:
                                task_run_stats = for_each_stats.task_run_stats
                                stats_dict["task_run_stats"] = {
                                    "total_iterations": getattr(task_run_stats, "total_iterations", 0),
                                    "scheduled_iterations": getattr(task_run_stats, "scheduled_iterations", 0),
                                    "active_iterations": getattr(task_run_stats, "active_iterations", 0),
                                    "failed_iterations": getattr(task_run_stats, "failed_iterations", 0),
                                    "succeeded_iterations": getattr(task_run_stats, "succeeded_iterations", 0),
                                    "completed_iterations": getattr(task_run_stats, "completed_iterations", 0),
                                }
                            result["for_each_stats"] = stats_dict

                    # Extract yaml_parameters_file_path from gen_ai_compute_task
                    if hasattr(task, "gen_ai_compute_task") and task.gen_ai_compute_task:
                        gen_ai_task = task.gen_ai_compute_task
                        if hasattr(gen_ai_task, "yaml_parameters_file_path") and gen_ai_task.yaml_parameters_file_path:
                            result["yaml_parameters_file_path"] = gen_ai_task.yaml_parameters_file_path

            return result

        except Exception as e:
            log.error("Failed to get run status: %s", e)
            raise

    def get_compute_config(self, workload_id: str) -> Dict[str, Any]:
        """Extract compute configuration from a workload.

        Args:
            workload_id: The run_id of the workload

        Returns:
            Dict[str, Any]: Dictionary containing:
                {
                    "num_gpus": int,  # Total number of GPUs
                    "gpu_type": str,  # GPU type (e.g., "h100_80gb")
                    "gpus_per_node": int,  # GPUs per node (8 for H100, 1 for A10)
                    "num_nodes": int  # Number of nodes (num_gpus / gpus_per_node)
                }

        Raises:
            RuntimeError: If compute config cannot be extracted
        """
        from cli.compute import GPUType, get_gpus_per_node

        w = self._get_workspace_client()

        try:
            run = w.jobs.get_run(run_id=int(workload_id))

            if not run.tasks or len(run.tasks) == 0:
                raise RuntimeError(f"No tasks found for run {workload_id}")

            task = run.tasks[0]
            if not hasattr(task, "gen_ai_compute_task") or not task.gen_ai_compute_task:
                raise RuntimeError(f"Run {workload_id} is not a gen_ai_compute task")

            gen_ai_task = task.gen_ai_compute_task
            if not hasattr(gen_ai_task, "compute") or not gen_ai_task.compute:
                raise RuntimeError(f"No compute configuration found for run {workload_id}")

            compute = gen_ai_task.compute
            num_gpus = compute.num_gpus if hasattr(compute, "num_gpus") else None
            gpu_type_str = compute.gpu_type if hasattr(compute, "gpu_type") else None

            if num_gpus is None:
                raise RuntimeError(f"Could not extract num_gpus from run {workload_id}")
            if gpu_type_str is None:
                raise RuntimeError(f"Could not extract gpu_type from run {workload_id}")

            # Convert gpu_type string to GPUType enum and get GPUs per node
            gpu_type = GPUType(gpu_type_str)
            gpus_per_node = get_gpus_per_node(gpu_type)

            # Calculate number of nodes: total GPUs / GPUs per node
            num_nodes = num_gpus // gpus_per_node
            if num_gpus % gpus_per_node != 0:
                log.warning(f"num_gpus ({num_gpus}) is not evenly divisible by gpus_per_node ({gpus_per_node})")

            return {
                "num_gpus": num_gpus,
                "gpu_type": gpu_type_str,
                "gpus_per_node": gpus_per_node,
                "num_nodes": num_nodes,
            }

        except Exception as e:
            log.error("Failed to get compute config for run %s: %s", workload_id, e)
            raise

    def get_run_output(self, workload_id: str, task_attempt: Optional[int] = None) -> Dict[str, Any]:
        """Get the full run output including task output.

        This method is modeled/copied from Skyrun's get_run_output function.

        This method retrieves the complete run information including task outputs,
        which contains the gen_ai_compute_output with MLflow run information.

        For ForEach tasks, returns ForEach statistics instead of task output.

        This follows the same two-step process as Skyrun:
        1. Get the task run ID from the parent job run
        2. Get the task output using the task run ID (or ForEach stats)

        Args:
            workload_id: The run_id of the workload to get output for
            task_attempt: Optional attempt number to select a specific retry's task.
                If None, uses the latest task (last in list). If specified, finds the
                task with the matching attempt_number.

        Returns:
            Dict[str, Any]: Dictionary containing complete run output including:
                - For regular tasks: gen_ai_compute_output with mlflow_run_id
                - For ForEach tasks: for_each_stats with iteration statistics
                - metadata: Job run metadata

        Raises:
            Exception: If the run doesn't exist or API call fails
            ValueError: If task_attempt is specified but no matching task is found
        """
        w = get_workspace_client()
        host = w.config.host.rstrip("/")
        headers = _get_auth_headers(w)

        try:
            # Step 1: Get the task run ID from the parent job run
            url = f"{host}/api/2.2/jobs/runs/get"
            params = {"run_id": workload_id}

            # Retry logic to handle timing issues where tasks might not be available yet
            max_retries = 5
            retry_delay = 1

            for attempt in range(max_retries):
                response = requests.get(url, headers=headers, params=params, timeout=30)
                response.raise_for_status()
                response_json = response.json()

                # Check if tasks are available
                if "tasks" in response_json and response_json["tasks"]:
                    tasks = response_json["tasks"]

                    # Select task based on task_attempt parameter
                    if task_attempt is not None:
                        # Find the task with the matching attempt_number
                        task = None
                        for t in tasks:
                            if t.get("attempt_number", 0) == task_attempt:
                                task = t
                                break
                        if task is None:
                            available = [t.get("attempt_number", 0) for t in tasks]
                            raise ValueError(
                                f"No task found with attempt_number={task_attempt}. " f"Available attempts: {available}"
                            )
                    else:
                        # Use the latest task (last in list) to handle retries
                        task = tasks[-1]

                    # Check if this is a ForEach task
                    if "for_each_task" in task:
                        # Return ForEach statistics
                        task_key = task.get("task_key", "unknown")
                        state = task.get("state", {})
                        for_each_stats = state.get("for_each_stats", {})

                        return {
                            "run_id": workload_id,
                            "task_key": task_key,
                            "task_type": "for_each",
                            "for_each_stats": for_each_stats,
                            "task_run_stats": for_each_stats.get("task_run_stats", {}),
                        }

                    task_id = task["run_id"]
                    break

                # If this is the last attempt, return metadata only
                if attempt == max_retries - 1:
                    log.debug("Tasks not yet available, returning metadata only")
                    return {"metadata": response_json}

                # Wait before retrying with exponential backoff_s
                time.sleep(retry_delay)
                retry_delay *= 2

            # Step 2: Get the task output using the task run ID (for non-ForEach tasks)
            url = f"{host}/api/2.2/jobs/runs/get-output"
            params = {"run_id": task_id}

            response = requests.get(url, headers=headers, params=params, timeout=30)
            response.raise_for_status()
            run_output = response.json()

            return run_output

        except requests.exceptions.RequestException as e:
            log.error("Failed to get run output: %s", e)
            raise RuntimeError(f"Jobs API get-output failed: {e}") from e
        except Exception as e:
            log.error("Failed to get run output: %s", e)
            raise

    def terminate_workload(self, workload_id: str, reason: Optional[str] = None) -> bool:
        """Terminate workload via Jobs API.

        This method calls the Jobs API directly to cancel a running workload.

        Args:
            workload_id: The run_id of the workload to terminate
            reason: Optional reason for termination (currently unused but kept for interface compatibility)

        Returns:
            bool: True if termination request was accepted

        Raises:
            RuntimeError: If termination fails due to API errors
        """
        w = self._get_workspace_client()
        host = w.config.host.rstrip("/")
        headers = _get_auth_headers(w)
        url = f"{host}/api/2.2/jobs/runs/cancel"
        params = {"run_id": workload_id}

        try:
            response = requests.post(url, headers=headers, params=params)
            response.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            log.error("Failed to cancel run %s: %s", workload_id, e)
            raise RuntimeError(f"Jobs API workload termination failed: {e}") from e

    def list_workloads(
        self,
        active_only: bool = True,
        expand_tasks: bool = True,
        page_token: Optional[str] = None,
        limit: Optional[int] = None,
        run_type: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """List workloads via Jobs API.

        This method provides the Jobs API listing functionality that was previously
        hardcoded in the get_calls() function. It calls the Jobs API runs/list endpoint
        and enhances the response with task IDs for foreach runs.

        Args:
            active_only: Whether to only return active runs
            expand_tasks: Whether to expand task details in the response
            page_token: Optional pagination token for retrieving next page
            limit: Optional maximum number of results to return
            run_type: Optional run type filter (e.g. "SUBMIT_RUN" or "JOB_RUN")

        Returns:
            Dictionary containing runs and pagination info from Jobs API.
            For foreach runs, includes task_ids in each run.

        Raises:
            RuntimeError: If listing fails
        """
        w = self._get_workspace_client()
        host = w.config.host.rstrip("/")
        headers = _get_auth_headers(w)
        url = f"{host}/api/2.2/jobs/runs/list"

        params = {"active_only": str(active_only).lower(), "expand_tasks": str(expand_tasks).lower()}

        if page_token:
            params["page_token"] = page_token

        if limit:
            params["limit"] = str(limit)

        if run_type:
            params["run_type"] = run_type

        try:
            response = requests.get(url, headers=headers, params=params, timeout=30)
            response.raise_for_status()

            result = response.json()
            log.debug("Successfully listed Jobs API workloads, found %d runs", len(result.get("runs", [])))
            return result

        except requests.exceptions.RequestException as e:
            log.error("Failed to list Jobs API workloads: %s", e)
            raise RuntimeError(f"Jobs API workload listing failed: {e}") from e

    def enhance_run_with_task_info(self, run: Dict[str, Any]) -> None:
        """Enhance a run dictionary with task information for foreach runs.

        Adds is_foreach_sweep flag to the run dict if it's a foreach sweep.

        Args:
            run: Run dictionary from Jobs API
        """
        if "tasks" not in run or not run["tasks"]:
            return

        # Check if any task is a foreach task with gen_ai_compute nested
        for task in run["tasks"]:
            if "for_each_task" in task:
                # Check if nested task is gen_ai_compute
                nested_task = task.get("for_each_task", {}).get("task", {})
                if "gen_ai_compute_task" in nested_task:
                    # This is a foreach sweep - mark it
                    run["is_foreach_sweep"] = True
                    break

    def _build_jobs_payload(
        self,
        experiment_name: str,
        job_run_name: str,
        timeout_seconds: int,
        launch_script: str,
        gpus: int,
        gpu_type: GPUType,
        yaml_config_path: str,
        mlflow_experiment_name: str,
        max_retries: int = 0,
        docker_image_url: Optional[str] = None,
        runtime_version: Optional[str] = None,
        gpu_node_pool_id: Optional[str] = None,
        use_foreach: bool = False,
        foreach_iterations: int = 3,
        budget_policy_id: Optional[str] = None,
        notification_email: Optional[str] = None,
        priority: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Build the Jobs API payload.

        Creates the JSON payload required for Jobs API workload submission.

        Args:
            experiment_name: Name of the function/workload for identification
            job_run_name: Name for the job run
            timeout_seconds: Maximum execution time in seconds before timeout
            launch_script: Path to the launch script to execute
            gpus: Total number of GPUs to allocate
            gpu_type: Type of GPU to use (e.g., H100, A100, etc.)
            yaml_config_path: Path to YAML configuration file in workspace
            max_retries: Maximum number of retries for failed tasks (default: 0)
            docker_image_url: Optional custom docker image URL. When specified, overrides the default DL runtime image.
            runtime_version: Optional runtime version string (integer >= 4, e.g., '4' or '5') from requirements.yaml. When specified, converted to CLIENT-GPU-{version} format and takes precedence over environment variable and default.
            gpu_node_pool_id: Optional GPU node pool ID for compute placement
            use_foreach: Whether to wrap the task in a ForEach task (default: False)
            foreach_iterations: Number of ForEach iterations (default: 3, only used when use_foreach=True)
            budget_policy_id: Optional budget policy UUID to assign to this workload
            notification_email: Optional email address for job success/failure notifications
            priority: Optional scheduling priority (0-999) for pool workloads

        Returns:
            Dict[str, Any]: Jobs API payload dictionary ready for submission
        """

        compute_config = {
            "num_gpus": gpus,
            "gpu_type": gpu_type.value,
            "gpu_node_pool_id": gpu_node_pool_id,
        }

        # Priority for dl_runtime_image:
        # 1. runtime_version from requirements.yaml (if specified) - converted to CLIENT-GPU-{version} format
        # 2. Environment variable DATABRICKS_DL_RUNTIME_IMAGE (via get_dl_runtime_image())
        # 3. Default "CLIENT-GPU-4" (via get_dl_runtime_image())
        # Note: docker_image_url uses a completely different path and is set elsewhere
        if runtime_version:
            runtime_image = f"CLIENT-GPU-{runtime_version}"
        else:
            runtime_image = get_dl_runtime_image()

        # Build the gen_ai_compute_task
        gen_ai_task = {
            "dl_runtime_image": runtime_image,
            "compute": compute_config,
            "training_script_path": launch_script,
            "yaml_parameters_file_path": yaml_config_path,
            "mlflow_experiment_name": mlflow_experiment_name,
        }

        if docker_image_url:
            gen_ai_task["docker_image_url"] = docker_image_url

        email_notifications = (
            {"on_success": [notification_email], "on_failure": [notification_email]} if notification_email else {}
        )

        if priority is not None:
            gen_ai_task["priority"] = priority

        # Build base task configuration
        task_config = {
            "task_key": job_run_name,
            "run_if": "ALL_SUCCESS",
            "timeout_seconds": 0,
            "email_notifications": email_notifications,
        }

        if use_foreach:
            # TODO: we will need to pass in the list of YAML paths and names for each sweep iteration
            # Create unique experiment name for sweep with date

            date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
            gen_ai_task["mlflow_experiment_name"] = mlflow_experiment_name + "_sweep_" + date_str

            # Generate ForEach inputs (currently all the same, will be varied later)
            foreach_inputs = self._generate_foreach_inputs(
                iterations=foreach_iterations,
                base_script_path=launch_script,
                base_yaml_path=yaml_config_path,
                experiment_name=mlflow_experiment_name + "_sweep_" + date_str,
            )

            # Create nested task structure
            nested_task = {
                "task_key": f"{job_run_name}_task",
                "gen_ai_compute_task": gen_ai_task,
                "timeout_seconds": 0,
                "email_notifications": email_notifications,
            }

            # Add retry logic to nested task if specified
            if max_retries > 0:
                nested_task["max_retries"] = max_retries
                nested_task["retry_on_timeout"] = True

            # Wrap in ForEach task
            task_config["for_each_task"] = {
                "inputs": json.dumps(foreach_inputs),
                "concurrency": 3,
                "task": nested_task,
            }
        else:
            # Original behavior - direct gen_ai_compute_task
            task_config["gen_ai_compute_task"] = gen_ai_task

            # Add retry configuration if max_retries is specified
            if max_retries > 0:
                task_config["max_retries"] = max_retries
                task_config["retry_on_timeout"] = True

        payload = {
            "run_name": job_run_name,
            "timeout_seconds": timeout_seconds,
            "tasks": [task_config],
        }

        usage_policy_id = get_usage_policy_id()
        if usage_policy_id:
            payload["usage_policy_id"] = usage_policy_id

        if budget_policy_id:
            payload["budget_policy_id"] = budget_policy_id

        return payload

    def _generate_foreach_inputs(
        self,
        iterations: int,
        base_script_path: str,
        base_yaml_path: Optional[str],
        experiment_name: str,
    ) -> list[dict[str, str]]:
        """Generate hardcoded ForEach inputs for testing.

        Creates N iterations with the same script/yaml paths.
        This is a placeholder for now, will be replaced with actual list of YAML paths from user input.
        TODO: Replace with actual list of YAML paths from user input.

        Args:
            iterations: Number of iterations to generate
            base_script_path: Base training script path
            base_yaml_path: Base YAML config path (optional)
            experiment_name: Base MLflow experiment name

        Returns:
            List of input dicts for ForEach task
        """
        inputs = []

        for i in range(iterations):
            input_dict = {
                "script_path": base_script_path,
                "experiment_name": f"{experiment_name}_{i}",
            }

            if base_yaml_path:
                input_dict["yaml_path"] = base_yaml_path

            inputs.append(input_dict)

        return inputs


def _is_air_workload(run: dict) -> bool:
    """Check if the job run is an AIR (AI/ML) workload based on its parameters.

    Determines whether a job run is an AI/ML job by checking for the presence
    of specific task structure and parameters that indicate it was launched
    through the serverless GPU compute system.

    Supports both direct gen_ai_compute_task and foreach tasks with nested gen_ai_compute_task.

    Args:
        run: Job run dictionary from the Databricks jobs API

    Returns:
        True if the job appears to be an AIR job, False otherwise
    """
    tasks = run.get("tasks")
    if tasks is None or not isinstance(tasks, list) or len(tasks) == 0:
        return False

    first_task = tasks[0]

    # Check for direct gen_ai_compute_task
    gen_ai_compute_task = first_task.get("gen_ai_compute_task")
    if gen_ai_compute_task is not None:
        training_script_path = gen_ai_compute_task.get("training_script_path")
        if training_script_path is not None:
            return True

    # Check for foreach task with nested gen_ai_compute_task
    for_each_task = first_task.get("for_each_task")
    if for_each_task is not None:
        nested_task = for_each_task.get("task", {})
        nested_gen_ai_task = nested_task.get("gen_ai_compute_task")
        if nested_gen_ai_task is not None:
            training_script_path = nested_gen_ai_task.get("training_script_path")
            if training_script_path is not None:
                return True

    return False
