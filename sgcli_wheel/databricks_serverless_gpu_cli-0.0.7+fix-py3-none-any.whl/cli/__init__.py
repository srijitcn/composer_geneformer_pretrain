"""Databricks Serverless GPU CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "0.0.7"
__git_sha__ = "f78064ddc80e77f392997095a8c5beed8650ba36"
