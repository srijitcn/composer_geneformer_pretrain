"""Databricks Serverless GPU CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "0.0.6"
__git_sha__ = "b1faaec1561638cfb5140ac8a8e979e68dc9e016"
