"""Databricks Serverless GPU CLI package."""

# NOTE: version and git sha are determined at release time; the versions listed here are placeholders
__version__ = "0.0.6"
__git_sha__ = "d8bb4e9b288f8f63bf96d68c2d3cef2473a6be1a"
