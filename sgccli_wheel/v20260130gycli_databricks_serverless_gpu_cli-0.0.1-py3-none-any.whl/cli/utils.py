"""CLI-compatible utility functions for Databricks API access.

This module provides utilities for accessing Databricks APIs from a local CLI environment,
without dependencies on notebook context (dbutils, IPython, etc.).
"""

import functools
import logging
import os
import random
import shutil
import string
import subprocess
import time
from enum import Enum
from pathlib import Path
from textwrap import dedent
from typing import Optional, List, Dict, Any, Tuple, Callable, Type, Union
import configparser
from databricks.sdk import WorkspaceClient
from databricks.sdk.errors.platform import NotFound
import tempfile
from packaging.requirements import Requirement
from cli.compute import GPUType

log = logging.getLogger(__name__)


def generate_unique_run_identifier(length: int = 6) -> str:
    """Generate a unique alphanumeric identifier for run names.

    Args:
        length: Length of the identifier (default: 6)

    Returns:
        str: Random alphanumeric identifier (lowercase letters and digits)
    """
    chars = string.ascii_lowercase + string.digits
    return "".join(random.choice(chars) for _ in range(length))


def _extract_status_code(exc: BaseException) -> Optional[int]:
    """
    Best-effort extraction of an HTTP status code from common exception shapes:
    - Databricks SDK errors often expose .status_code
    - requests.HTTPError exposes .response.status_code
    - some wrappers expose .response.status
    """
    # Databricks SDK (and many HTTP wrappers)
    code = getattr(exc, "status_code", None)
    if isinstance(code, int):
        return code

    # requests.HTTPError and similar
    resp = getattr(exc, "response", None)
    if resp is not None:
        code = getattr(resp, "status_code", None)
        if isinstance(code, int):
            return code
        code = getattr(resp, "status", None)
        if isinstance(code, int):
            return code

    return None


def retry(
    exceptions_to_check: Union[Type[Exception], Tuple[Type[Exception], ...]],
    tries: int = 4,
    delay_s: int = 3,
    backoff_s: int = 2,
    logger: Optional[logging.Logger] = None,
    log_level: int = logging.WARNING,
    retry_if: Optional[Callable[[BaseException], bool]] = None,
) -> Callable:
    """Retry decorator with exponential backoff_s.

    retry_if: optional predicate; if provided, only retry when retry_if(exc) is True.
    """
    if tries < 1:
        raise ValueError("tries must be >= 1")
    if delay_s < 0:
        raise ValueError("delay_s must be >= 0")
    if backoff_s < 1:
        raise ValueError("backoff_s must be >= 1")

    def deco(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _delay = delay_s
            last_exc: Optional[BaseException] = None

            for attempt in range(1, tries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions_to_check as e:
                    last_exc = e

                    # If a predicate is provided and it says "don't retry", re-raise immediately
                    if retry_if is not None and not retry_if(e):
                        raise

                    if attempt >= tries:
                        raise

                    if logger is not None:
                        logger.log(
                            log_level,
                            "Retryable failure (attempt %d/%d): %r. Retrying in %ss...",
                            attempt,
                            tries,
                            e,
                            _delay,
                        )
                    time.sleep(_delay)
                    _delay *= backoff_s

            raise last_exc  # type: ignore[misc]

        return wrapper

    return deco


def is_http_5xx(exc: BaseException) -> bool:
    code = _extract_status_code(exc)
    return code is not None and 500 <= code < 600


# ---------------- Authentication ----------------


def find_profile_for_host(host: str) -> Optional[str]:
    """Find a profile in databrickscfg that matches the given host.

    Args:
        host: The workspace host URL to match (e.g., "https://example.databricks.com")

    Returns:
        Optional[str]: The profile name if found, None otherwise.
    """
    # Get config file location
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    # Normalize the target host for comparison
    target_host = host.rstrip("/")
    if not target_host.startswith("http://") and not target_host.startswith("https://"):
        target_host = f"https://{target_host}"

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Search through all profiles for a matching host
        for section in config.sections():
            if config.has_option(section, "host"):
                profile_host = config.get(section, "host").rstrip("/")
                # Normalize profile host
                if not profile_host.startswith("http://") and not profile_host.startswith("https://"):
                    profile_host = f"https://{profile_host}"

                if profile_host == target_host:
                    log.debug("Found matching profile '%s' for host %s", section, target_host)
                    return section

        log.warning("No matching profile found for host %s in %s", target_host, config_path)
        return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def find_host_for_profile(profile: str) -> Optional[str]:
    """Find the host URL for a given profile in databrickscfg.

    Args:
        profile: The profile name to look up (e.g., "DEFAULT", "my-profile")

    Returns:
        Optional[str]: The host URL if found, None otherwise.
    """
    # Get config file location
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Check if the profile exists
        # Note: ConfigParser treats DEFAULT specially - it's accessed via defaults() not has_section()
        if profile == "DEFAULT":
            # Check if DEFAULT section has a host
            if config.has_option("DEFAULT", "host"):
                host = config.get("DEFAULT", "host").rstrip("/")
                # Normalize host to include https:// if missing
                if not host.startswith("http://") and not host.startswith("https://"):
                    host = f"https://{host}"
                log.debug("Found host '%s' for profile '%s'", host, profile)
                return host
            else:
                log.warning("Profile '%s' does not have a 'host' field", profile)
                return None
        else:
            # Regular profile section
            if not config.has_section(profile):
                log.warning("Profile '%s' not found in %s", profile, config_path)
                return None

            # Get the host from the profile
            if config.has_option(profile, "host"):
                host = config.get(profile, "host").rstrip("/")
                # Normalize host to include https:// if missing
                if not host.startswith("http://") and not host.startswith("https://"):
                    host = f"https://{host}"
                log.debug("Found host '%s' for profile '%s'", host, profile)
                return host
            else:
                log.warning("Profile '%s' does not have a 'host' field", profile)
                return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def get_default_profile() -> Optional[str]:
    """Get the default profile name from databrickscfg.

    Returns:
        Optional[str]: The default profile name if found (typically "DEFAULT"), None otherwise.
    """
    config_file = os.environ.get("DATABRICKS_CONFIG_FILE")
    if not config_file:
        config_file = str(Path.home() / ".databrickscfg")

    config_path = Path(config_file)
    if not config_path.exists():
        log.debug("Databricks config file not found at: %s", config_path)
        return None

    try:
        config = configparser.ConfigParser()
        config.read(config_path)

        # Check if DEFAULT profile exists
        # Note: ConfigParser treats DEFAULT specially, so we need to check if it has options
        if config.has_option("DEFAULT", "host") or len(config.defaults()) > 0:
            return "DEFAULT"

        # If no DEFAULT section, return None
        return None

    except Exception as e:
        log.error("Failed to parse databrickscfg file at %s: %s", config_path, e)
        return None


def log_auth_context(verbose: bool = False) -> None:
    """Log the authentication context being used for Databricks API calls.

    With verbose=True (debug level):
    - Logs which environment variables are set (DATABRICKS_AUTH_TYPE, DATABRICKS_TOKEN, DATABRICKS_CONFIG_PROFILE)
    - Logs their values (except DATABRICKS_TOKEN, just logs that it's set)

    With verbose=False (info level):
    - Logs the workspace URL and profile being used

    Args:
        verbose: If True, log detailed debug information about env vars
    """
    env = os.environ
    auth_vars = {
        "DATABRICKS_AUTH_TYPE": env.get("DATABRICKS_AUTH_TYPE"),
        "DATABRICKS_TOKEN": env.get("DATABRICKS_TOKEN"),
        "DATABRICKS_CONFIG_PROFILE": env.get("DATABRICKS_CONFIG_PROFILE"),
        "DATABRICKS_HOST": env.get("DATABRICKS_HOST"),
    }

    if verbose:
        for key, val in auth_vars.items():
            if not val:
                log.debug(f"{key} is not set")
            elif key == "DATABRICKS_TOKEN":
                log.debug(f"{key} is set")
            else:
                log.debug(f"{key} is set: %s", val)

    if auth_vars["DATABRICKS_TOKEN"] and auth_vars["DATABRICKS_HOST"]:
        log.info("Using PAT token for authentication")
        log.info("Using Workspace set by DATABRICKS_HOST: %s", auth_vars["DATABRICKS_HOST"])
        return

    # Determine profile and workspace using fallbacks
    active_profile = auth_vars["DATABRICKS_CONFIG_PROFILE"] or get_default_profile()
    workspace_url = auth_vars["DATABRICKS_HOST"] or (find_host_for_profile(active_profile) if active_profile else None)

    # Log info level message based on availability
    if active_profile and workspace_url:
        log.info("Using Profile: [%s] with Workspace: %s", active_profile, workspace_url)
    elif active_profile:
        log.info("Using Profile: [%s] (workspace not configured)", active_profile)
    elif workspace_url:
        log.info("Using Workspace: %s (no profile configured)", workspace_url)
    else:
        log.info("No authentication context configured")


def get_workspace_client(workspace_host: Optional[str] = None) -> WorkspaceClient:
    """Get a WorkspaceClient instance with appropriate configuration.

    Authentication priority:
    1. Use DATABRICKS_CONFIG_PROFILE environment variable if set
    2. Find matching profile in ~/.databrickscfg (or DATABRICKS_CONFIG_FILE)
       and use profile-based auth
    3. If no profile found, fall back to default WorkspaceClient() which will use
       'databricks auth token' command

    Args:
        workspace_host: Optional workspace host URL. If not provided, checks DATABRICKS_HOST
                       environment variable, then uses default config.

    Returns:
        WorkspaceClient: Configured workspace client instance.
    """
    # If no workspace_host provided, check DATABRICKS_HOST environment variable
    if not workspace_host:
        workspace_host = os.environ.get("DATABRICKS_HOST")

    if workspace_host:
        # Ensure host has https:// prefix
        host = workspace_host
        if not host.startswith("http://") and not host.startswith("https://"):
            host = f"https://{host}"

        # Step 1: Check if DATABRICKS_CONFIG_PROFILE is set
        profile = os.environ.get("DATABRICKS_CONFIG_PROFILE")
        if profile:
            log.debug("Using DATABRICKS_CONFIG_PROFILE='%s' for authentication", profile)
            os.environ.pop("DATABRICKS_TOKEN", None)
            return WorkspaceClient(profile=profile)

        # Step 2: Try to find a matching profile in databrickscfg
        profile = find_profile_for_host(host)
        if profile:
            log.debug("Using profile '%s' from databrickscfg for authentication", profile)
            # Add this line so following calls to this function can use profile
            os.environ["DATABRICKS_CONFIG_PROFILE"] = profile
            return WorkspaceClient(profile=profile)

        # Step 3: Fall back to default (will use 'databricks_token')
        log.debug("No token or profile found, falling back to 'databricks auth token' command")
        return WorkspaceClient(host=host)

    return WorkspaceClient()


# ---------------- Enums ----------------


class ScriptType(str, Enum):
    """Type of script to execute."""

    PYTHON = "python"
    BASH = "bash"
    COMMAND = "command"


# Default launch command for distributed training (using torchrun with c10d rendezvous)
DEFAULT_LAUNCH_CMD = "torchrun --nproc_per_node {nproc_per_node} --nnodes {nodes} --node_rank {node_rank} --rdzv_backend c10d --rdzv_endpoint {rdzv_endpoint}"


class _SafeDict(dict):
    """Dictionary that returns missing keys as format string placeholders."""

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


def _get_launch_cmd(gpus: int, nproc_per_node: int, nodes: int) -> str:
    """Generate the distributed training launch command.

    Args:
        gpus: Total number of GPUs to allocate.
        nproc_per_node: Number of processes per node.
        nodes: Number of nodes.

    Returns:
        str: The formatted launch command string.
    """
    launch_cmd_to_format = (
        DEFAULT_LAUNCH_CMD
        if "DATABRICKS_INTERNAL_LAUNCH_CMD" not in os.environ
        else os.environ["DATABRICKS_INTERNAL_LAUNCH_CMD"]
    )
    return launch_cmd_to_format.format_map(
        _SafeDict(
            gpus=gpus,
            nproc_per_node=nproc_per_node,
            nodes=nodes,
            node_rank="${NODE_RANK:-0}",
            rdzv_endpoint="${MASTER_ADDR:-127.0.0.1}:${MASTER_PORT:-29400}",
        )
    )


def _get_bash_cmd(gpus: int, nproc_per_node: int, python_file: str) -> str:
    """Generate the bash command for running distributed training.

    Args:
        gpus: Total number of GPUs to allocate.
        nproc_per_node: Number of processes per node.
        python_file: Path to the Python script to execute.

    Returns:
        str: The complete bash command string.
    """
    nodes = max(1, gpus // 8)
    return f"{_get_launch_cmd(gpus=gpus, nproc_per_node=nproc_per_node, nodes=nodes)} {python_file}\n"


def _extract_repo_name(git_repo: str) -> str:
    """Extract the repository name from a git URL.

    Args:
        git_repo: Git repository URL.

    Returns:
        str: The extracted repository name without the .git extension.
    """
    repo_name = git_repo.rstrip("/").split("/")[-1]
    # Remove .git extension if present
    if repo_name.endswith(".git"):
        repo_name = repo_name[:-4]
    return repo_name


def get_compute_options(gpu_type: GPUType, host: Optional[str] = None) -> List[Dict[str, Any]]:
    """Get available compute options for a specific GPU type.

    Args:
        gpu_type (GPUType): The GPU type to query options for.

    Returns:
        List[Dict[str, Any]]: List of available compute options for the specified GPU type.
    """
    method = "GET"
    endpoint = "compute-options"
    headers: dict[str, str] = {
        "Content-Type": "application/json",
    }
    payload = {}
    action = {
        "method": method,
        "path": f"/api/2.0/genai-mapi/air/{endpoint}",
        "headers": headers,
        "query": payload,
    }
    w = get_workspace_client(host)
    compute_options = w.api_client.do(**action).get("options", None)
    return [compute_option for compute_option in compute_options if compute_option["gpu_type"] == gpu_type.value]


def get_dl_runtime_image() -> str:
    """Get the deep learning runtime image to use.

    This is used as a fallback when client_image is not specified in YAML.

    Priority order for dl_runtime_image selection:
    1. client_image field in YAML environment section (checked in _build_jobs_payload)
    2. DATABRICKS_DL_RUNTIME_IMAGE environment variable (checked here)
    3. Default value 'CLIENT-GPU-4' (returned here)

    Returns:
        str: The runtime image name. Reads from DATABRICKS_DL_RUNTIME_IMAGE env var
    """
    image = os.environ.get("DATABRICKS_DL_RUNTIME_IMAGE", "CLIENT-GPU-4")
    log.debug(f"Using DL runtime image: {image}")
    return image


def get_usage_policy_id() -> Optional[str]:
    """Get the usage policy ID.

    Returns:
        Optional[str]: The usage policy ID from DATABRICKS_USAGE_POLICY_ID env var,
                      or None.
    """
    policy_id = os.environ.get("DATABRICKS_USAGE_POLICY_ID")
    if policy_id:
        log.debug(f"Using usage policy: {policy_id}")
    return policy_id


def get_user_workspace_dir() -> str:
    """Get the user's workspace directory path.

    Returns:
        str: The workspace directory path. Reads from DATABRICKS_USER env var
             or DATABRICKS_INTERNAL_USER_WORKSPACE_DIR, or uses a default.
    """
    workspace_user = os.environ.get("DATABRICKS_USER")
    if not workspace_user:
        import getpass

        workspace_user = getpass.getuser()

    return os.environ.get("DATABRICKS_INTERNAL_USER_WORKSPACE_DIR", f"/Workspace/Users/{workspace_user}@databricks.com")


def get_cli_launch_dir(experiment_name: str) -> str:
    """Get the directory for CLI launch artifacts.

    Args:
        experiment_name: The experiment name to create a subdirectory for.

    Returns:
        str: Path to the CLI launch directory under .serverless_gpu/cli_launch.
    """
    base_path = get_user_workspace_dir()
    import time

    timestamp = int(time.time())
    return os.path.join(base_path, ".serverless_gpu", "cli_launch", f"{experiment_name}_{timestamp}")


def upload_file_to_workspace(local_path: str, workspace_path: str) -> str:
    """Upload a local file to the Databricks Workspace.

    Args:
        local_path: Path to the local file to upload.
        workspace_path: Target workspace path. Can be:
            - Workspace files path:  /Workspace/Users/... or /Workspace/Shared/...
            - Legacy path:          /Users/... or /Shared/...
          If ends with /, the local filename will be appended.
        use_rest_api: If True, use direct REST API instead of SDK (limited to ~10MB).

    Returns:
        str: The final workspace path where the file was uploaded.

    Raises:
        RuntimeError: If workspace API is unavailable or timing out.
    """
    from pathlib import Path

    import signal
    from contextlib import contextmanager
    from databricks.sdk.service import workspace as ws

    @contextmanager
    def timeout_handler(seconds: int):
        """Context manager to timeout long-running operations."""

        def handle_timeout(signum, frame):
            raise TimeoutError(f"Operation timed out after {seconds} seconds")

        old_handler = signal.signal(signal.SIGALRM, handle_timeout)
        signal.alarm(seconds)
        try:
            yield
        finally:
            signal.alarm(0)
            signal.signal(signal.SIGALRM, old_handler)

    w = get_workspace_client()

    # --- Normalize workspace path (DO NOT strip /Workspace) ---
    path = workspace_path.strip()
    if not path.startswith("/"):
        path = "/" + path

    # If path ends with /, append the local filename
    if path.endswith("/"):
        path = path.rstrip("/") + f"/{Path(local_path).name}"

    # Ensure parent directory exists with timeout
    try:
        with timeout_handler(30):
            try:
                w.workspace.mkdirs(str(Path(path).parent))
            except Exception as e:
                error_msg = str(e).lower()
                if "503" in error_msg or "unavailable" in error_msg or "timeout" in error_msg:
                    raise RuntimeError(
                        "Workspace API is currently unavailable (503 Service Unavailable). "
                        "This is typically a temporary issue with the workspace infrastructure. "
                        "Please try again in a few minutes or contact your workspace admin."
                    ) from e
                raise
    except TimeoutError as e:
        raise RuntimeError(
            "Workspace directory creation timed out after 30 seconds. "
            "The workspace API may be experiencing issues. "
            "Please check workspace availability and try again later."
        ) from e

    # --- Upload using streaming API (no 10MB limit on content) ---
    try:
        with timeout_handler(60):  # slightly longer for big files
            with open(local_path, "rb") as f:
                w.workspace.upload(
                    path=path,
                    content=f,  # file-like object
                    format=ws.ImportFormat.AUTO,  # let Databricks decide notebook vs file
                    overwrite=True,
                )
    except TimeoutError as e:
        raise RuntimeError(
            "Workspace file upload timed out. "
            "The workspace API may be experiencing issues or the file is very large. "
            "Please check workspace availability and try again."
        ) from e
    except Exception as e:
        error_msg = str(e).lower()
        if "503" in error_msg or "unavailable" in error_msg or "timeout" in error_msg:
            raise RuntimeError(
                "Workspace API is currently unavailable (503 Service Unavailable). "
                "This is typically a temporary issue with the workspace infrastructure. "
                "Please try again in a few minutes or contact your workspace admin."
            ) from e
        raise

    log.debug(f"Uploaded {local_path} to workspace {path} using SDK upload()")
    return path


def upload_file_to_volume(local_path: str, volume_path: str) -> str:
    """Upload a local file to a Databricks Volume.

    Args:
        local_path: Path to the local file to upload.
        volume_path: Target volume path. Must start with /Volumes/.
                    If ends with /, the local filename will be appended.

    Returns:
        str: The final volume path where the file was uploaded.

    Raises:
        ValueError: If volume_path doesn't start with /Volumes/.
    """
    w = get_workspace_client()

    # Normalize volume path
    path = volume_path.strip()
    if not path.startswith("/Volumes/"):
        raise ValueError(f"Volume path must start with '/Volumes/', got: {path}")

    # If path ends with /, append the local filename
    if path.endswith("/"):
        path = path.rstrip("/") + f"/{Path(local_path).name}"

    parent = os.path.dirname(path)
    w.files.create_directory(parent)

    # Upload file to volume using Files API
    w.files.upload(
        file_path=path,
        contents=open(local_path, "rb"),
        overwrite=True,
    )
    log.debug(f"Uploaded {local_path} to volume {path}")
    return path


def upload_python_script_as_zip(local_script_path: str, workspace_dir: str) -> Tuple[str, str]:
    """Upload a Python script to workspace with .dat extension.

    We upload with .dat extension to prevent workspace from treating it as a notebook
    or auto-extracting it. The bash script will copy it to $HOME and rename back to .py.

    Args:
        local_script_path: Path to the local .py file to upload.
        workspace_dir: Workspace directory to upload the script to.

    Returns:
        Tuple[str, str]: A tuple containing:
            - workspace_dat_path: Path to the uploaded .dat file in workspace
            - script_filename: Original Python filename (with .py extension)
    """
    script_path = Path(local_script_path)
    script_filename = script_path.name

    # Upload with .dat extension to avoid notebook conversion or auto-extraction
    workspace_dat_path = os.path.join(workspace_dir, f"{script_path.stem}.dat")
    uploaded_path = upload_file_to_workspace(local_script_path, workspace_dat_path)

    log.info(f"Uploaded Python script as .dat file: {uploaded_path}")
    return uploaded_path, script_filename


def upload_parameters_as_yaml(parameters: Dict[str, Any], func_dir: str) -> str:
    """Upload parameters dict as a YAML file to workspace.

    Args:
        parameters: Dictionary containing hyperparameters/config.
        func_dir: Remote workspace directory to upload to.

    Returns:
        str: Remote workspace path to the uploaded YAML file.
    """
    import yaml

    # Create temporary YAML file with parameters
    with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False, encoding="utf-8") as f:
        temp_params_file = f.name
        yaml.safe_dump(parameters, f, default_flow_style=False, sort_keys=False)

    try:
        # Upload to workspace
        remote_path = os.path.join(func_dir, "hyperparameters.yaml")
        uploaded_path = upload_file_to_workspace(temp_params_file, remote_path)
        log.debug(f"Uploaded hyperparameters YAML to: {uploaded_path}")
        return uploaded_path
    finally:
        # Clean up temp file
        try:
            os.unlink(temp_params_file)
        except Exception as e:
            log.warning(f"Failed to delete temp parameters file {temp_params_file}: {e}")


def _parse_docker_image_url(docker_image_url: str) -> tuple[str, str, str]:
    """Parse docker image URL into registry, image path, and tag.

    Only supports format: organization/repository:tag
    Registry is always docker.io

    Args:
        docker_image_url: Docker image URL string in format "organization/repository:tag"

    Returns:
        Tuple of (registry, image_project_repo, tag) where registry is always "docker.io"

    Raises:
        ValueError: If the URL format is invalid
    """
    # Tag is required - must have :
    if ":" not in docker_image_url:
        raise ValueError(
            f"Invalid docker image URL format: '{docker_image_url}'. "
            f"Tag is required. Expected format: 'organization/repository:tag'"
        )

    # Split by : to separate tag
    image_path, tag = docker_image_url.rsplit(":", 1)

    # Must be exactly organization/repository (2 parts)
    parts = image_path.split("/")
    if len(parts) != 2:
        raise ValueError(
            f"Invalid docker image URL format: '{docker_image_url}'. "
            f"Expected format: 'organization/repository:tag' (exactly 2 path components)"
        )

    # Always use docker.io as registry
    registry = "docker.io"
    image_project_repo = image_path

    return registry, image_project_repo, tag


def build_sandbox_cli_script(
    docker_image_url: str,
    script_type: ScriptType,
    target_script_path: str,
) -> str:
    """Build sandbox CLI command for running script in custom docker container.

    Args:
        docker_image_url: Docker image URL (e.g., "pytorch/pytorch:2.0.0")
        script_type: Type of script (BASH or PYTHON)
        target_script_path: Path to the script to execute

    Returns:
        Shell script content for running the script via sandbox CLI

    Raises:
        ValueError: If docker image URL format is invalid
    """
    # Parse docker image URL
    try:
        registry, image_project_repo, tag = _parse_docker_image_url(docker_image_url)
    except ValueError as e:
        raise ValueError(f"Failed to parse docker image URL: {e}") from e

    # TODO(CNXT-1648): The code below doesn't work for multi-node GPU jobs yet.
    if script_type in (ScriptType.BASH, ScriptType.COMMAND):
        # For bash scripts and inline commands, use direct entrypoint without shell wrapper
        entrypoint = f"/bin/sh,{target_script_path}"
    else:
        # For python scripts, use shell wrapper with python3
        entrypoint = f'/bin/sh,-c,"python3 {target_script_path}"'

    return dedent(f"""\
        # Run script in custom docker container using sandbox CLI
        echo "Running script in custom docker image: {docker_image_url}"
        /sandbox/sandbox-cli -socket /sandbox/sandbox.sock launch \\
            -entrypoint {entrypoint} \\
            -image-repo-url {registry} \\
            -image-project-repo {image_project_repo} \\
            -image-tag {tag} \\
            -auth-server {registry} \\
            -mounts /tmp:/tmp,$HOME:$HOME
        """)


def prepare_launch_script_simple(
    gpus: int,
    gpus_per_node: int,
    workspace_zip_path: Optional[str],
    script_filename: str,
    func_dir: str,
    git_repo: Optional[str] = None,
    git_branch: Optional[str] = None,
    git_secret: Optional[str] = None,
    script_type: ScriptType = ScriptType.PYTHON,
    tar_workspace_path: Optional[str] = None,
    env_variables: Optional[Dict[str, str]] = None,
    env_variables_secrets: Optional[Dict[str, str]] = None,
    requirements_filename: Optional[str] = None,
    parameters_yaml_path: Optional[str] = None,
    sanity_check_script_path: Optional[str] = None,
    mlflow_system_metrics_script_path: Optional[str] = None,
    docker_image_url: Optional[str] = None,
    run_name: Optional[str] = None,
) -> str:
    """Create a launch script for distributed training or bash script execution.

    This creates a bash script that sets up the environment and runs either a Python script
    with distributed training (torchrun) or a user bash script directly.

    Args:
        gpus: Total number of GPUs to allocate for the workload.
        gpus_per_node: Number of GPUs per compute node.
        workspace_zip_path: Path to the .dat file in workspace (containing the script).
                           None if using git workflow.
        script_filename: Name of the script or path relative to repo root.
        func_dir: Remote workspace directory where the launch script should be uploaded.
        git_repo: Optional git repository URL to clone from.
        git_branch: Optional git branch to checkout (defaults to main/master if not specified).
        git_secret: Optional Databricks secret reference in format "scope/key" for git authentication.
        script_type: Type of script, bash or python.
        tar_workspace_path: Optional path to tarball in workspace to extract before running script.
        env_variables: Optional dict of regular environment variables to export.
        env_variables_secrets: Optional dict mapping "scope/key" to "ENV_VAR_NAME" for secrets.
        requirements_filename: Optional name of requirements.yaml file (e.g., 'requirements.yaml') uploaded to workspace.
        parameters_yaml_path: Optional path to hyperparameters YAML file in workspace.
        sanity_check_script_path: Optional path to node sanity check script in workspace.
        mlflow_system_metrics_script_path: Optional path to MLflow system metrics monitoring script in workspace.
        docker_image_url: Optional custom docker image URL in format "organization/repository:tag" (e.g., "pytorch/pytorch:2.0.1").
                         Tag is required. Registry is always docker.io. When provided, the script will be run using sandbox CLI with the custom docker image.

    Returns:
        str: Remote workspace path to the uploaded launch script.
    """
    # Default to empty dict if None
    if env_variables is None:
        env_variables = {}

    # Prepare script components
    dbruntime_version = os.environ.get("DATABRICKS_RUNTIME_VERSION", "15.4")

    # Determine requirements.yaml path - always in func_dir (uploaded from local machine)
    if requirements_filename:
        requirements_yaml_path = os.path.join(func_dir, requirements_filename)
    else:
        requirements_yaml_path = None

    # Build bash script header
    script_content = dedent(f"""\
        #!/bin/bash
        set -e

        # Record start time
        START_TIME=$(date +%s)
        echo "Environment setup started at $(date)"

        # Error handler: sleep if failure occurs in first 30 seconds
        handle_error() {{
            local exit_code=$?
            local current_time=$(date +%s)
            local elapsed=$((current_time - START_TIME))

            echo "ERROR: Script failed with exit code $exit_code after ${{elapsed}}s"

            if [ $elapsed -lt 30 ]; then
                sleep 30
            fi

            exit $exit_code
        }}

        copy_with_retry() {{
            local src="$1"
            local dst="$2"
            local max_retries=5
            local base_delay=1
            local attempt=0

            until cp "$src" "$dst"; do
                attempt=$((attempt + 1))
                if ((attempt >= max_retries)); then
                    echo "Failed after $max_retries attempts" >&2
                    return 1
                fi
                
                # Exponential backoff_s: 1, 2, 4, 8, 16...
                delay_s=$((base_delay * (2 ** (attempt - 1))))
                echo "Attempt $attempt failed. Retrying in ${{delay_s}}s..." >&2
                sleep "$delay_s"
            done
        }}


        # Trap errors and call handler
        trap 'handle_error' ERR

        # Set environment variables
        export DATABRICKS_RUNTIME_VERSION={dbruntime_version}
        export NCCL_DEBUG=WARN
    """)

    # Python script uses specific python environment
    if script_type == ScriptType.PYTHON:
        script_content += dedent("""\
            # Set PYTHONPATH to include databricks python paths
            export PYTHONPATH=$PYTHONPATH:/databricks/python3/lib/python3.12/site-packages
            export PATH=$PATH:/.pythonenv/bin

            """)

    # MLflow configuration for experiment tracking
    # These environment variables enable MLflow to automatically integrate with Databricks:
    # - MLFLOW_TRACKING_URI=databricks: Configures MLflow to use Databricks as the tracking server,
    #   allowing experiment runs, metrics, and parameters to be logged to the Databricks workspace.
    # - MLFLOW_SYSTEM_METRICS_NODE_ID: Enables system metrics collection (CPU, GPU, memory) with
    #   unique node identifiers in distributed training scenarios.
    script_content += dedent("""\
        # MLflow configuration for experiment tracking
        # MLFLOW_TRACKING_URI: Directs MLflow to use Databricks as the tracking backend
        # MLFLOW_SYSTEM_METRICS_NODE_ID: Enables system metrics collection with node identification
        export MLFLOW_TRACKING_URI=databricks
        export MLFLOW_SYSTEM_METRICS_NODE_ID="node_${NODE_RANK:-0}"

        """)

    # Export hyperparameters path if provided
    if parameters_yaml_path:
        script_content += dedent(f"""\
            # Export hyperparameters YAML file path
            export HYPERPARAMETERS_PATH=/Workspace{parameters_yaml_path}

            """)

    # User-provided environment variables (skip if using custom docker image)
    if env_variables and not docker_image_url:
        script_content += "# Export user-defined environment variables\n"
        for var_name, var_value in env_variables.items():
            # Escape single quotes in the value for bash shell safety
            escaped_value = var_value.replace("'", "'\\''")
            script_content += f"export {var_name}='{escaped_value}'\n"
        script_content += "\n"

    # Fetch and export secrets as environment variables (skip if using custom docker image)
    if env_variables_secrets and not docker_image_url:
        # Upload the get_env_secrets.py helper script with .dat extension
        # (to avoid workspace treating it as a notebook)
        get_env_secrets_local = str(Path(__file__).parent / "get_env_secrets.py")
        get_env_secrets_remote = os.path.join(func_dir, "get_env_secrets.dat")
        upload_file_to_workspace(get_env_secrets_local, get_env_secrets_remote)

        # Build the command-line arguments for the secrets script
        secrets_args = ""
        for env_var_name, secret_ref in env_variables_secrets.items():
            scope, key = secret_ref.split("/", 1)
            secrets_args += f" --secret {env_var_name} {scope} {key}"

        script_content += dedent(f"""\
            # Fetch secrets from Databricks Secrets and export as environment variables
            echo 'Fetching secrets from Databricks Secrets...'
            copy_with_retry /Workspace{get_env_secrets_remote} $HOME/get_env_secrets.py
            python3 $HOME/get_env_secrets.py{secrets_args}

            # Source the secrets into current environment
            if [ -f $HOME/secrets_env.sh ]; then
                source $HOME/secrets_env.sh
                rm $HOME/secrets_env.sh
                echo 'Successfully exported all secrets as environment variables'
            else
                echo 'ERROR: Failed to create secrets environment file'
                exit 1
            fi

            """)

    # Add script acquisition section (git clone or workspace copy)
    if git_repo:
        # Git-based workflow: clone the repository
        script_content += f"# Clone git repository: {git_repo}\n"
        script_content += "git_clone_start_time=$(date +%s)\n"
        script_content += "echo 'Starting git clone...'\n"

        # Extract repo name from git_repo URL for git-based workflow
        repo_name = _extract_repo_name(git_repo)
        repo_dir = f"$HOME/{repo_name}"

        if git_secret and "/" in git_secret:
            # Retrieve PAT from Databricks Secrets
            scope, key = git_secret.split("/", 1)
            script_content += dedent(f"""\
                # Retrieving git PAT from Databricks Secrets using WorkspaceClient
                echo 'Retrieving git credentials from Databricks Secrets...'
                echo 'Scope: {scope}, Key: {key}'
                GIT_PAT=$(python3 <<'PYTHON_EOF'
                from databricks.sdk import WorkspaceClient
                w = WorkspaceClient()
                secret = w.dbutils.secrets.get(scope='{scope}', key='{key}')
                print(secret, end='')
                PYTHON_EOF
                )
                if [ -z "$GIT_PAT" ]; then
                  echo "ERROR: Failed to retrieve git PAT from Databricks Secrets"
                  exit 1
                fi
                echo "Git credentials retrieved successfully"
                echo "PAT length: ${{#GIT_PAT}} characters"

                REPO_URL=$(echo "{git_repo}" | sed "s|https://|https://${{GIT_PAT}}@|")
                echo "Cloning repository..."
                git clone "$REPO_URL" {repo_dir}

                """)
        else:
            # Clone without authentication
            if git_secret and "/" not in git_secret:
                log.warning(
                    f"Invalid git_secret format: {git_secret}. Expected 'scope/key'. Cloning without authentication."
                )
            script_content += "echo 'Cloning repository...'\n"
            script_content += f"git clone {git_repo} {repo_dir}\n\n"

        script_content += dedent("""\
            git_clone_end_time=$(date +%s)
            git_clone_duration=$((git_clone_end_time - git_clone_start_time))
            echo "Git clone completed in ${git_clone_duration}s"

            """)

        script_content += f"cd {repo_dir}\n"

        if git_branch:
            script_content += f"git checkout {git_branch}\n"

        script_content += "\n"
        target_script_path = f"{repo_dir}/{script_filename}"
    else:
        # Workspace-based workflow: copy script from workspace
        target_script_path = f"$HOME/{script_filename}"
        script_content += dedent(f"""\
            # Copy script from workspace
            copy_with_retry /Workspace{workspace_zip_path} {target_script_path}

            """)

    # Add dependencies installation section
    # Requirements.yaml is ALWAYS uploaded to func_dir from local machine
    if not docker_image_url and requirements_yaml_path:
        script_content += dedent(f"""\
            # Install dependencies from requirements.yaml
            requirements_install_start_time=$(date +%s)
            if [ -f {requirements_yaml_path} ]; then
                echo "Installing dependencies from requirements.yaml: {requirements_yaml_path}..."
                # Parse YAML and run multiple pip install commands
                # This supports scoped flags (--no-deps, --no-build-isolation) per dependency
                python3 -c "
import yaml
import subprocess
import sys
import shlex

# Affects specific dependency
SCOPED_FLAGS = {{'--no-deps', '--no-build-isolation', '--no-cache-dir', '--force-reinstall'}}

# Affects all dependencies
STICKY_PREFIXES = {{'--index-url', '--extra-index-url', '--find-links', '-f', '--trusted-host'}}

try:
    with open('{requirements_yaml_path}', 'r') as f:
        data = yaml.safe_load(f) or {{}}

    deps = data.get('dependencies', [])
    if not deps:
        print('No dependencies found in requirements.yaml')
        sys.exit(0)

    sticky = []          # apply to every pip call (index urls, find-links, trusted-host)
    bulk = []            # installed together with deps enabled
    pending = []         # scoped flags collected for the next requirement-ish entry
    scoped = []          # list of per-item installs: (flags + requirement tokens)

    for entry in deps:
        tokens = shlex.split(str(entry))
        if not tokens:
            continue

        # sticky settings (e.g., '--index-url https://...')
        if tokens[0] in STICKY_PREFIXES:
            sticky.extend(tokens)
            continue

        # scoped flag line like: '--no-deps'
        if len(tokens) == 1 and tokens[0] in SCOPED_FLAGS:
            pending.append(tokens[0])
            continue

        # scoped flag inline like: '--no-deps https://...whl'
        if tokens[0] in SCOPED_FLAGS:
            pending.append(tokens[0])
            tokens = tokens[1:]
            if not tokens:
                continue

        if pending:
            scoped.append(pending + tokens)
            pending = []
        else:
            bulk.extend(tokens)

    if pending:
        print(f'ERROR: scoped flag(s) with no following dependency: {{pending}}', file=sys.stderr)
        sys.exit(1)

    # Install bulk dependencies with normal resolution
    if bulk:
        print(f'Installing {{len(bulk)}} dependencies with dependency resolution...')
        cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade'] + sticky + bulk
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            print('ERROR: Failed to install dependencies')
            print('\\nPossible causes:')
            print('  - Dependency conflicts between packages')
            print('  - Inaccessible packages (private repos, incorrect URLs)')
            print('  - Network issues preventing package downloads')
            print('  - Invalid package specifications in requirements.yaml')
            print('\\nPip output:')
            print('STDOUT:', result.stdout)
            print('STDERR:', result.stderr)
            sys.exit(1)

        print(result.stdout)

    # Install scoped dependencies individually
    for i, item in enumerate(scoped, 1):
        print(f'Installing scoped dependency {{i}}/{{len(scoped)}} with flags: {{item[:-1]}}...')
        cmd = [sys.executable, '-m', 'pip', 'install', '--upgrade'] + sticky + item
        result = subprocess.run(cmd, capture_output=True, text=True)

        if result.returncode != 0:
            print('ERROR: Failed to install dependencies')
            print('\\nPossible causes:')
            print('  - Dependency conflicts between packages')
            print('  - Inaccessible packages (private repos, incorrect URLs)')
            print('  - Network issues preventing package downloads')
            print('  - Invalid package specifications in requirements.yaml')
            print('\\nPip output:')
            print(f'STDOUT:', result.stdout)
            print(f'STDERR:', result.stderr)
            sys.exit(1)

        print(result.stdout)

    print('Successfully installed all dependencies')
except Exception as e:
    print(f'ERROR: Failed to process requirements.yaml: {{e}}', file=sys.stderr)
    import traceback
    traceback.print_exc()
    sys.exit(1)
"
                requirements_install_end_time=$(date +%s)
                requirements_install_duration=$((requirements_install_end_time - requirements_install_start_time))
                echo "Dependency installation completed in ${{requirements_install_duration}}s"
            else
                echo "ERROR: requirements.yaml not found at {requirements_yaml_path}"
                exit 1
            fi

            """)

    # Extract tarball if provided
    if tar_workspace_path:
        script_content += "# Extract directory tarball\n"
        script_content += "tarball_extract_start_time=$(date +%s)\n"
        # Check if path is from Volumes or Workspace
        if tar_workspace_path.startswith("/Volumes/"):
            # Volumes path - copy to $HOME first, then extract
            script_content += dedent(f"""\
                TAR_PATH="{tar_workspace_path}"
                if [ -f "$TAR_PATH" ]; then
                    echo "Copying tarball from Volumes..."
                    copy_with_retry "$TAR_PATH" $HOME/data.tar.gz
                    echo "Extracting tarball..."
                    tar -xzf $HOME/data.tar.gz -C $HOME/
                    rm $HOME/data.tar.gz
                    tarball_extract_end_time=$(date +%s)
                    tarball_extract_duration=$((tarball_extract_end_time - tarball_extract_start_time))
                    echo "Tarball extraction completed in ${{tarball_extract_duration}}s"
                else
                    echo "ERROR: Tarball not found at {tar_workspace_path}"
                    exit 1
                fi

                """)
        else:
            # Workspace path - extract directly
            script_content += dedent(f"""\
                if [ -f /Workspace{tar_workspace_path} ]; then
                    echo "Extracting tarball from Workspace..."
                    tar -xzf /Workspace{tar_workspace_path} -C $HOME/
                    tarball_extract_end_time=$(date +%s)
                    tarball_extract_duration=$((tarball_extract_end_time - tarball_extract_start_time))
                    echo "Tarball extraction completed in ${{tarball_extract_duration}}s"
                else
                    echo "ERROR: Tarball not found at /Workspace{tar_workspace_path}"
                    exit 1
                fi

                """)

    # Run sanity check script if provided
    if sanity_check_script_path:
        script_content += dedent(f"""\
            # Run node sanity check script
            echo "Running node sanity check..."
            bash /Workspace{sanity_check_script_path}
            """)

    # Start MLflow system metrics monitoring as a background sidecar process
    # Only start on local rank 0 to avoid duplicate metrics (one per node, not per GPU)
    if mlflow_system_metrics_script_path:
        script_content += dedent(f"""\
            # Start MLflow system metrics monitoring in background
            if [ -n "${{MLFLOW_RUN_ID:-}}" ] && [ "${{LOCAL_RANK:-0}}" = "0" ]; then
                echo "Starting MLflow system metrics monitoring..."
                python3 /Workspace{mlflow_system_metrics_script_path} \\
                    --run-id "${{MLFLOW_RUN_ID}}" \\
                    --parent-pid $$ \\
                    --sampling-interval 2 \\
                    --node-id "node_${{NODE_RANK:-0}}" \\
                    2>&1 &
                MLFLOW_METRICS_PID=$!
                echo "MLflow system metrics monitor started with PID $MLFLOW_METRICS_PID"
            fi

            """)

    # Update MLflow run name (always set, either custom or job run name)
    # Only runs on rank 0 node
    if run_name:
        # Escape single quotes for bash
        escaped_run_name = run_name.replace("'", "'\\''")
        script_content += dedent(f"""\
            # Update MLflow run name (only on rank 0 node)
            if [ -n "${{MLFLOW_RUN_ID:-}}" ]; then
                # Check if this is rank 0 node
                if [ "${{NODE_RANK:-0}}" = "0" ]; then
                    echo "MLflow run name set to: {run_name}"
                    python3 -c '
            import os
            from databricks.sdk import WorkspaceClient

            mlflow_run_id = os.environ.get("MLFLOW_RUN_ID")
            run_name = "{escaped_run_name}"

            if mlflow_run_id:
                try:
                    w = WorkspaceClient()
                    w.api_client.do(
                        "POST",
                        "/api/2.0/mlflow/runs/update",
                        body={{"run_id": mlflow_run_id, "run_name": run_name}},
                    )
                    print(f"Successfully updated MLflow run name to: {{run_name}}")
                except Exception as e:
                    print(f"Warning: Failed to update MLflow run name: {{e}}")
            ' || true
                fi
            fi

            """)

    script_content += dedent("""\
        # Mark the start of user code execution
        user_code_start_time=$(date +%s)
        echo "Environment setup completed, starting user code execution..."

        """)

    # Add script execution section
    if docker_image_url:
        script_content += build_sandbox_cli_script(
            docker_image_url=docker_image_url,
            script_type=script_type,
            target_script_path=target_script_path,
        )
    elif script_type in (ScriptType.BASH, ScriptType.COMMAND):
        script_content += dedent(f"""\
            # Run the bash script directly
            chmod +x {target_script_path}
            {target_script_path}
            """)
    else:
        # Python script - use distributed training with torchrun
        script_content += "# Run the training script with distributed training\n"
        script_content += _get_bash_cmd(gpus=gpus, nproc_per_node=gpus_per_node, python_file=target_script_path)

    # Add timing summary at the end
    script_content += dedent("""
        # Calculate and display execution time
        END_TIME=$(date +%s)
        TOTAL_DURATION=$((END_TIME - START_TIME))
        ENV_SETUP_DURATION=$((user_code_start_time - START_TIME))
        USER_CODE_DURATION=$((END_TIME - user_code_start_time))

        echo "================================"
        echo "Execution Summary"
        echo "================================"
        echo "Environment setup time: ${ENV_SETUP_DURATION}s"
        echo "User code execution time: ${USER_CODE_DURATION}s"
        echo "Execution completed at $(date)"
        echo "================================"
        """)

    # Write script to temporary file
    with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False, encoding="utf-8") as f:
        temp_launch_script = f.name
        f.write(script_content)

    try:
        # Upload to remote workspace
        remote_launch_script_path = os.path.join(func_dir, "launch_script.sh")
        remote_path = upload_file_to_workspace(temp_launch_script, remote_launch_script_path)

        log.debug(f"Created and uploaded launch script to: {remote_path}")
        return remote_path
    finally:
        # Clean up the local temporary file
        try:
            os.unlink(temp_launch_script)
        except Exception as e:
            log.warning(f"Failed to delete temporary launch script {temp_launch_script}: {e}")


def get_gpu_pool_id(gpu_type: GPUType) -> Optional[str]:
    """
    Get the GPU pool ID for a given GPU type.
    Priority order:
    1. DATABRICKS_USE_RESERVED_GPU_POOL=false (explicit opt-out overrides everything)
    2. DATABRICKS_REMOTE_GPU_POOL_ID environment variable (explicit pool selection)
    3. Auto-detected pool from notebook session (if not opted out)
    4. DATABRICKS_USE_RESERVED_GPU_POOL=true (explicit opt-in overrides inherited OD usage from notebook session)
    5. Default to on-demand (None)

    Args:
        gpu_type (GPUType): The GPU type to get the GPU pool ID for.

    Returns:
        Optional[str]: The GPU pool ID for the given GPU type.
    """
    compute_options = get_compute_options(gpu_type)
    if len(compute_options) == 0:
        raise Exception(
            f"No compute options found for {gpu_type.value}. Please contact your workspace provider to obtain access to Serverless GPU Compute."
        )

    pool_compute_options = [opt for opt in compute_options if "reserved_pool" in opt]

    # Check if explicitly opted out of pools
    # Priority: DATABRICKS_USE_RESERVED_GPU_POOL (latest) > DATABRICKS_USE_POOL (new) > SGC_USE_POOL (old) > constant default
    use_pool_env = False
    if use_pool_env in ["false", "0", "no"]:
        log.info("DATABRICKS_USE_RESERVED_GPU_POOL=false, using on-demand compute")
        return None

    # Check if user specified a specific pool
    override_pool_id = os.environ.get("DATABRICKS_REMOTE_GPU_POOL_ID", os.environ.get("REMOTE_GPU_POOL_ID", None))
    if override_pool_id:
        if pool_compute_options and override_pool_id in [opt["reserved_pool"]["id"] for opt in pool_compute_options]:
            log.info(f"Using DATABRICKS_REMOTE_GPU_POOL_ID={override_pool_id}")
            return override_pool_id
        else:
            raise Exception(
                f"The GPU pool ID {override_pool_id} is not available for {gpu_type.value}. "
                f"Available pools: {[opt['reserved_pool']['id'] for opt in pool_compute_options]}."
                f"Alternatively, try using On-Demand compute instead! (unset DATABRICKS_REMOTE_GPU_POOL_ID or REMOTE_GPU_POOL_ID)"
            )

    # Auto-detect if notebook is pool-attached
    detected_pool_id = False
    if detected_pool_id:
        # Verify it's valid for this GPU type
        if pool_compute_options and detected_pool_id in [opt["reserved_pool"]["id"] for opt in pool_compute_options]:
            log.info(f"Using auto-detected pool {detected_pool_id}")
            return detected_pool_id
        else:
            log.warning(
                f"Detected pool {detected_pool_id} not available for {gpu_type.value}, falling back to on-demand"
            )

    # Check if explicitly opted into pools
    if use_pool_env in ["true", "1", "yes"]:
        if len(pool_compute_options) == 0:
            log.warning("DATABRICKS_USE_RESERVED_GPU_POOL=true but no pools available, using on-demand")
            return None
        pool_id = pool_compute_options[0]["reserved_pool"]["id"]
        log.info(f"DATABRICKS_USE_RESERVED_GPU_POOL=true, using pool {pool_id}")
        return pool_id

    # Default to on-demand
    log.info("Using on-demand compute (default)")
    return None


IGNORED_PREFIXES = (
    "#",
    "-r ",
    "--requirement ",
    "-c ",
    "--constraint ",
    "--extra-index-url",
    "--index-url",
    "--find-links",
    "--trusted-host",
    "--no-binary",
    "--only-binary",
)


def validate_requirements_syntax(req_file: str) -> list[str]:
    """
    Returns a list of human-readable errors. Empty list == valid.
    Does not contact the network or import pip.
    """
    errors = []
    p = Path(req_file)
    if not p.exists():
        return [f"File not found: {req_file}"]

    for i, raw in enumerate(p.read_text().splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # ignore known options/directives; they're valid for pip but not Requirement()
        if any(line.startswith(pref) for pref in IGNORED_PREFIXES):
            continue
        # allow VCS/URL/paths to pass basic shape check; Requirement supports url@name
        try:
            r = Requirement(line)
            # force-parse common parts so we catch typos early
            _ = r.specifier  # type: SpecifierSet
            if r.marker:  # type: Marker|None
                _ = r.marker  # will raise on invalid marker expr
        except Exception as e:
            errors.append(f"Line {i}: {line!r} → {e.__class__.__name__}: {e}")
    return errors


def get_git_sha(repo_path: Path) -> Optional[str]:
    """Get the current git commit SHA for a repository.

    Args:
        repo_path: Path to the git repository.

    Returns:
        str: The current git commit SHA, or None if not a git repo or error occurs.
    """
    import subprocess

    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        log.warning(f"Failed to get git SHA for {repo_path}")
        return None


def has_uncommitted_changes(repo_path: Path) -> bool:
    """Check if a git repository has uncommitted changes.

    Args:
        repo_path: Path to the git repository.

    Returns:
        bool: True if there are uncommitted changes, False otherwise.
    """
    import subprocess

    try:
        # Check for uncommitted changes (staged or unstaged)
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True,
        )
        return bool(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        log.warning(f"Failed to check git status for {repo_path}")
        return False


def check_workspace_file_exists(workspace_path: str) -> bool:
    """Check if a file exists in Databricks Workspace.

    Args:
        workspace_path: Path to the file in workspace (e.g., /Users/user@db.com/.serverless_gpu/...)

    Returns:
        bool: True if the file exists, False otherwise.
    """
    w = get_workspace_client()

    # Normalize path: remove /Workspace prefix if present
    path = workspace_path.strip()
    if path.startswith("/Workspace/"):
        path = path[len("/Workspace") :]
    if not path.startswith("/"):
        path = "/" + path

    try:
        w.workspace.get_status(path)
        return True
    except NotFound:
        return False
    except Exception as e:
        log.error(f"Failed to check if file exists at {workspace_path}: {e}")
        return False


def check_volume_file_exists(volume_path: str) -> bool:
    """Check if a file exists in a Databricks Volume.

    Args:
        volume_path: Path to the file in the volume (must start with /Volumes/).

    Returns:
        bool: True if the file exists, False otherwise.
    """
    w = get_workspace_client()
    try:
        w.files.get_metadata(volume_path)
        return True
    except NotFound:
        return False
    except Exception as e:
        log.error(f"Failed to check if file exists at {volume_path}: {e}")
        return False


def create_shallow_clone(source_repo_path: Path, git_ref: str, ref_type: str = "head") -> tuple[Path, str]:
    """Create a shallow git clone of a repository at a specific commit or branch.

    This creates a temporary shallow clone with --depth 1 to exclude git history
    from the tarball, significantly reducing tarball size.

    Args:
        source_repo_path: Path to the source git repository.
        git_ref: Git reference to clone (commit SHA, branch name, or "HEAD").
        ref_type: Type of reference - "commit", "branch", or "head".

    Returns:
        tuple: (clone_path, resolved_sha) where resolved_sha is the actual commit SHA

    Raises:
        RuntimeError: If git operations fail.
    """
    try:
        # For branch and commit references, fetch from remote in the source repo first
        # This ensures the ref exists locally before we try to clone it
        if ref_type == "branch":
            log.debug(f"Fetching branch {git_ref} from remote in source repository")
            try:
                # Fetch the branch from origin to ensure it exists locally
                subprocess.run(
                    ["git", "fetch", "origin", f"{git_ref}:{git_ref}"],
                    cwd=source_repo_path,
                    capture_output=True,
                    text=True,
                    check=True,
                )
            except subprocess.CalledProcessError as e:
                # If the branch already exists locally, the fetch might fail with "already exists"
                # Check if the branch exists locally
                result = subprocess.run(
                    ["git", "rev-parse", "--verify", f"refs/heads/{git_ref}"],
                    cwd=source_repo_path,
                    capture_output=True,
                    text=True,
                )
                if result.returncode != 0:
                    # Branch doesn't exist locally or on remote
                    raise RuntimeError(
                        f"Branch '{git_ref}' does not exist in repository {source_repo_path} or its remote. "
                        "Please verify the branch name is correct and has been pushed to the remote."
                    ) from e
        elif ref_type == "commit":
            log.debug(f"Fetching commit {git_ref} from remote in source repository")
            # Check if commit exists locally first
            result = subprocess.run(
                ["git", "cat-file", "-e", git_ref],
                cwd=source_repo_path,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                # Commit doesn't exist locally, try to fetch it from remote
                try:
                    subprocess.run(
                        ["git", "fetch", "origin", git_ref],
                        cwd=source_repo_path,
                        capture_output=True,
                        text=True,
                        check=True,
                    )
                except subprocess.CalledProcessError as e:
                    raise RuntimeError(
                        f"Commit '{git_ref}' does not exist in repository {source_repo_path} or its remote. "
                        "Please verify the commit SHA is correct."
                    ) from e

        # Create temporary directory for shallow clone
        temp_dir = Path(tempfile.mkdtemp(prefix="shallow_clone_"))
        clone_path = temp_dir / source_repo_path.name

        log.debug(f"Creating shallow clone from {source_repo_path} to {clone_path}")

        # Initial shallow clone with all branches
        subprocess.run(
            [
                "git",
                "clone",
                "--depth",
                "1",
                "--no-single-branch",
                f"file://{source_repo_path.absolute()}",
                str(clone_path),
            ],
            capture_output=True,
            text=True,
            check=True,
        )

        # Fetch and checkout based on ref_type
        if ref_type == "commit":
            # Commit was already fetched in source repo, now just checkout
            log.debug(f"Checking out commit {git_ref}")
            subprocess.run(
                ["git", "checkout", git_ref],
                cwd=clone_path,
                capture_output=True,
                text=True,
                check=True,
            )
            resolved_sha = git_ref

        elif ref_type == "branch":
            # Branch should now be available locally in the clone
            log.debug(f"Checking out branch {git_ref}")
            subprocess.run(
                ["git", "checkout", git_ref],
                cwd=clone_path,
                capture_output=True,
                text=True,
                check=True,
            )
            # Get the SHA of the checked-out branch HEAD
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=clone_path,
                capture_output=True,
                text=True,
                check=True,
            )
            resolved_sha = result.stdout.strip()

        else:  # ref_type == "head"
            # Just checkout HEAD (already cloned with depth 1)
            subprocess.run(
                ["git", "checkout", git_ref],
                cwd=clone_path,
                capture_output=True,
                text=True,
                check=True,
            )
            # Get the SHA of HEAD
            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=clone_path,
                capture_output=True,
                text=True,
                check=True,
            )
            resolved_sha = result.stdout.strip()

        log.debug(f"Successfully created shallow clone at {clone_path}, SHA: {resolved_sha}")
        return clone_path, resolved_sha

    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.lower() if e.stderr else ""

        # Provide specific error messages for common cases
        if "could not read from remote repository" in error_msg:
            raise RuntimeError(
                f"Failed to access git repository at {source_repo_path}. " "Ensure the path is a valid git repository."
            ) from e
        elif "couldn't find remote ref" in error_msg or "does not exist" in error_msg:
            if ref_type == "commit":
                raise RuntimeError(
                    f"Commit '{git_ref}' does not exist in repository {source_repo_path}. "
                    "Please verify the commit SHA is correct."
                ) from e
            elif ref_type == "branch":
                raise RuntimeError(
                    f"Branch '{git_ref}' does not exist in repository {source_repo_path}. "
                    "Please verify the branch name is correct."
                ) from e

        # Generic error message
        log.error(f"Failed to create shallow clone: {e.stderr}")
        # Clean up temp directory on failure
        if "temp_dir" in locals():
            shutil.rmtree(temp_dir, ignore_errors=True)
        raise RuntimeError(f"Failed to create shallow git clone: {e.stderr}") from e


def cleanup_temp_directory(temp_path: Path) -> None:
    """Safely remove a temporary directory and all its contents.

    Args:
        temp_path: Path to the temporary directory to remove.
    """
    try:
        if temp_path.exists():
            shutil.rmtree(temp_path)
            log.debug(f"Cleaned up temporary directory: {temp_path}")
    except Exception as e:
        log.warning(f"Failed to clean up temporary directory {temp_path}: {e}")
