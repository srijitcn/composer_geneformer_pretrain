"""YAML configuration schema and validation using Pydantic.

This module defines the complete schema for training YAML configuration files,
including validation rules for all fields and nested structures.
"""

from pydantic import BaseModel, Field, field_validator, model_validator, ConfigDict
import re
from typing import Optional, Dict, Any, Literal


from cli.compute import GPUType, get_gpus_per_node

# Only allows alphanumeric characters, hyphens, dots, and underscores
REGEX_ALLOWED_CHARS = r"^[\w.-]+$"


class WorkspaceConfig(BaseModel):
    """Workspace configuration for specifying Databricks workspace."""

    model_config = ConfigDict(extra="forbid")

    host: Optional[str] = None

    @field_validator("host")
    @classmethod
    def validate_host(cls, v: Optional[str]) -> Optional[str]:
        """Validate workspace host is not empty if provided."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("workspace.host cannot be empty")
        return v


class DockerImageConfig(BaseModel):
    """Docker image configuration for custom containers."""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(description="Docker image URL in format 'organization/repository:tag'")

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        """Validate docker image URL is not empty."""
        v = v.strip()
        if not v:
            raise ValueError("docker_image.url cannot be empty")
        return v


class EnvironmentConfig(BaseModel):
    """Environment configuration for dependencies and variables."""

    model_config = ConfigDict(extra="forbid")

    dependencies: Optional[str] = None
    env_variables: Optional[Dict[str, str]] = None
    env_variables_secrets: Optional[Dict[str, str]] = None
    docker_image: Optional[DockerImageConfig] = None

    @field_validator("env_variables_secrets")
    @classmethod
    def validate_secrets(cls, v: Optional[Dict[str, str]]) -> Optional[Dict[str, str]]:
        """Validate secret references are in 'scope/key' format."""
        if v is not None:
            for var_name, secret_ref in v.items():
                if "/" not in secret_ref or len(secret_ref.split("/")) != 2:
                    raise ValueError(
                        f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                        f"Expected format 'scope/key' (e.g., my_scope/hf_token)"
                    )
                parts = secret_ref.split("/")
                if not parts[0] or not parts[1]:
                    raise ValueError(
                        f"Invalid secret reference '{secret_ref}' for variable '{var_name}'. "
                        f"Scope and key cannot be empty"
                    )
        return v

    @model_validator(mode="after")
    def handle_docker_image(self) -> "EnvironmentConfig":
        """Validate that docker_image cannot coexist with other environment fields."""
        # Check docker_image conflicts with other fields
        if self.docker_image is not None:
            conflicting_fields = []
            if self.dependencies is not None:
                conflicting_fields.append("dependencies")
            if self.env_variables is not None:
                conflicting_fields.append("env_variables")
            if self.env_variables_secrets is not None:
                conflicting_fields.append("env_variables_secrets")

            if conflicting_fields:
                fields_str = ", ".join(conflicting_fields)
                raise ValueError(
                    f"When 'docker_image' is specified under 'environment', "
                    f"the following fields are not allowed: {fields_str}. "
                    f"Please remove these fields or remove 'docker_image'."
                )
        return self


class ComputeConfig(BaseModel):
    """Compute configuration for GPU resources."""

    model_config = ConfigDict(extra="forbid")

    gpus: int = Field(gt=0, description="Number of GPUs (must be positive)")
    gpu_type: str = Field(description="Type of GPU (e.g., 'h100_80gb', 'a10')")
    gpu_node_pool_id: Optional[str] = None
    gpu_pool_name: Optional[str] = None

    @field_validator("gpu_type")
    @classmethod
    def validate_gpu_type(cls, v: str) -> str:
        """Validate GPU type is recognized."""
        try:
            GPUType(v)
        except (ValueError, KeyError):
            valid_types = ", ".join([f"'{t.value}'" for t in GPUType])
            raise ValueError(f"Invalid gpu_type '{v}'. Must be one of: {valid_types}")
        return v

    @model_validator(mode="after")
    def validate_gpu_count(self) -> "ComputeConfig":
        """Validate GPU count matches hardware topology (multiples of GPUs per node)."""
        gpu_type_enum = GPUType(self.gpu_type)
        gpus_per_node = get_gpus_per_node(gpu_type_enum)

        if self.gpus % gpus_per_node != 0:
            raise ValueError(
                f"Invalid GPU count for {self.gpu_type}: {self.gpus}. "
                f"{self.gpu_type} requires multiples of {gpus_per_node} GPUs. "
            )
        return self

    @model_validator(mode="after")
    def validate_pool_fields(self) -> "ComputeConfig":
        """Validate that only one of gpu_node_pool_id or gpu_pool_name is specified."""
        if self.gpu_node_pool_id and self.gpu_pool_name:
            raise ValueError("Cannot specify both 'gpu_node_pool_id' and 'gpu_pool_name'. " "Please use only one.")
        return self


class RepoSnapshotConfig(BaseModel):
    """Repository snapshot configuration for code tarballs."""

    model_config = ConfigDict(extra="forbid")

    local_repo_path: Optional[str] = None
    remote_volume: Optional[str] = None
    git_commit: Optional[str] = None
    git_branch: Optional[str] = None

    @field_validator("remote_volume")
    @classmethod
    def validate_volume(cls, v: Optional[str]) -> Optional[str]:
        """Validate volume path starts with /Volumes/."""
        if v is not None and not v.startswith("/Volumes/"):
            raise ValueError(
                "repo_snapshot.remote_volume must start with '/Volumes/' "
                "(e.g., '/Volumes/catalog/schema/volume/path')"
            )
        return v


class SnapshotSourceConfig(BaseModel):
    """Snapshot workflow: tar local directory and upload."""

    model_config = ConfigDict(extra="forbid")

    repo_path: str = Field(description="Local directory to snapshot")
    remote_volume: Optional[str] = None

    @field_validator("repo_path")
    @classmethod
    def validate_path(cls, v: str) -> str:
        """Validate repo_path is not empty."""
        if not v or not v.strip():
            raise ValueError("repo_path cannot be empty")
        return v.strip()

    @field_validator("remote_volume")
    @classmethod
    def validate_volume(cls, v: Optional[str]) -> Optional[str]:
        """Validate volume path starts with /Volumes/."""
        if v is not None and not v.startswith("/Volumes/"):
            raise ValueError("remote_volume must start with '/Volumes/'")
        return v


class GitCloneSourceConfig(BaseModel):
    """Git clone workflow: clone from remote repository."""

    model_config = ConfigDict(extra="forbid")

    git_repo: str = Field(description="Git repository URL")
    git_branch: Optional[str] = None
    git_commit: Optional[str] = None
    git_secret: Optional[str] = None

    @field_validator("git_repo")
    @classmethod
    def validate_repo(cls, v: str) -> str:
        """Validate git repository URL to prevent command injection.

        Only allows HTTPS URLs with alphanumeric characters, hyphens, dots, and underscores.
        Format: https://host/org/repo or https://host/org/repo.git
        """
        if not v or not v.strip():
            raise ValueError("git_repo cannot be empty")

        v = v.strip()
        error_message = f"Invalid git_repo format '{v}'. \n"
        error_message += "Must be an HTTPS URL in format 'https://host/organization/repository' or 'https://host/organization/repository.git'. \n"
        error_message += "Only alphanumeric characters, hyphens, dots, and underscores are allowed. "

        if not re.match(r"^https://[\w.-]+/[\w.-]+/[\w.-]+(\.git)?$", v):
            raise ValueError(error_message)
        return v

    @field_validator("git_branch")
    @classmethod
    def validate_branch(cls, v: Optional[str]) -> Optional[str]:
        """Validate git branch name to prevent command injection.

        Only allows alphanumeric characters, hyphens, dots, slashes, and underscores.
        """
        if v is None:
            return v

        error_message = f"Invalid git_branch format '{v}'. \n"
        error_message += "Only alphanumeric characters, hyphens, dots, slashes, and underscores are allowed. "

        if not re.match(r"^[\w./-]+$", v):
            raise ValueError(error_message)
        return v

    @field_validator("git_secret")
    @classmethod
    def validate_secret(cls, v: Optional[str]) -> Optional[str]:
        """Validate git secret reference format."""
        if v is not None:
            parts = v.split("/")
            if len(parts) != 2 or not parts[0] or not parts[1]:
                raise ValueError(
                    f"Invalid git_secret format '{v}'. " f"Expected 'scope/key' (e.g., my_scope/git_token)"
                )
        return v


class CodeSourceConfig(BaseModel):
    """Discriminated union for code source configuration."""

    model_config = ConfigDict(extra="forbid")

    type: Literal["snapshot", "git_clone"] = Field(description="Code source type")
    snapshot: Optional[SnapshotSourceConfig] = None
    git_clone: Optional[GitCloneSourceConfig] = None

    @model_validator(mode="after")
    def validate_type_matches_config(self) -> "CodeSourceConfig":
        """Enforce type matches which config is provided."""
        if self.type == "snapshot":
            if self.snapshot is None:
                raise ValueError("type='snapshot' requires snapshot configuration")
            if self.git_clone is not None:
                raise ValueError("type='snapshot' cannot have git_clone configuration")
        elif self.type == "git_clone":
            if self.git_clone is None:
                raise ValueError("type='git_clone' requires git_clone configuration")
            if self.snapshot is not None:
                raise ValueError("type='git_clone' cannot have snapshot configuration")
        return self


class YamlConfig(BaseModel):
    """Complete YAML configuration schema for training runs."""

    model_config = ConfigDict(extra="forbid")

    # Required fields
    experiment_name: str
    environment: EnvironmentConfig
    compute: ComputeConfig

    # Script fields
    python_script: Optional[str] = None
    bash_script: Optional[str] = None
    command: Optional[str] = None

    # Optional fields
    workspace: Optional[WorkspaceConfig] = None
    git_repo: Optional[str] = None
    git_branch: Optional[str] = None
    git_secret: Optional[str] = None
    repo_snapshot: Optional[RepoSnapshotConfig] = None
    code_source: Optional[CodeSourceConfig] = None
    max_retries: int = Field(default=0, ge=0)
    timeout_minutes: Optional[int] = Field(default=None, ge=1)
    idempotency_token: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = Field(default=None)
    run_name: Optional[str] = None

    @field_validator("git_repo")
    @classmethod
    def validate_git_repo(cls, v: Optional[str]) -> Optional[str]:
        """Validate git repository URL to prevent command injection.

        Only allows HTTPS URLs with alphanumeric characters, hyphens, dots, and underscores.
        Format: https://host/org/repo or https://host/org/repo.git
        """
        if v is None:
            return v

        error_message = f"Invalid git_repo format '{v}'. \n"
        error_message += "Must be an HTTPS URL in format 'https://host/organization/repository' or 'https://host/organization/repository.git'. \n"
        error_message += "Only alphanumeric characters, hyphens, dots, and underscores are allowed. "

        return cls._validate_pattern(v, r"^https://[\w.-]+/[\w.-]+/[\w.-]+(\.git)?$", error_message)

    @field_validator("git_branch")
    @classmethod
    def validate_git_branch(cls, v: Optional[str]) -> Optional[str]:
        """Validate git branch name to prevent command injection.

        Only allows alphanumeric characters, hyphens, dots, slashes, and underscores.
        """
        if v is None:
            return v

        error_message = f"Invalid git_branch format '{v}'. \n"
        error_message += "Only alphanumeric characters, hyphens, dots, slashes, and underscores are allowed. "
        return cls._validate_pattern(v, r"^[\w./-]+$", error_message)

    @field_validator("git_secret")
    @classmethod
    def validate_git_secret(cls, v: Optional[str]) -> Optional[str]:
        """Validate git secret reference format."""
        if v is not None:
            parts = v.split("/")
            if len(parts) != 2 or not parts[0] or not parts[1]:
                raise ValueError(
                    f"Invalid git_secret format '{v}'. " f"Expected format 'scope/key' (e.g., my_scope/git_token)"
                )
        return v

    @field_validator("idempotency_token")
    @classmethod
    def validate_idempotency_token(cls, v: Optional[str]) -> Optional[str]:
        """Validate idempotency token is not empty and within length limits."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("idempotency_token cannot be empty")
            if len(v) > 64:
                raise ValueError("idempotency_token must be 64 characters or less")
        return v

    @field_validator("run_name")
    @classmethod
    def validate_mlflow_run_name(cls, v: Optional[str]) -> Optional[str]:
        """Validate MLflow run name is not empty if provided."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("run_name cannot be empty")
        return v

    @classmethod
    def _validate_pattern(cls, v: Optional[str], pattern: str, error_message: str) -> Optional[str]:
        """Validate string with a regex pattern.

        Only allows alphanumeric characters, hyphens, dots, slashes, and underscores.
        """
        if v is not None:
            if not re.match(pattern, v):
                raise ValueError(error_message)
        return v

    @field_validator("python_script")
    @classmethod
    def validate_python_script(cls, v: Optional[str]) -> Optional[str]:
        """Validate python script filename to prevent command injection.

        Only allows alphanumeric characters, hyphens, dots, and underscores in the filename.
        This prevents shell command injection when the script name is used in bash commands.
        """

        if v is not None:
            file_name = v.split("/")[-1]
            return cls._validate_pattern(
                file_name,
                REGEX_ALLOWED_CHARS,
                f"Invalid python_script filename '{file_name}'. "
                f"Only alphanumeric characters, hyphens, dots, and underscores are allowed in the filename.",
            )

    @field_validator("bash_script")
    @classmethod
    def validate_bash_script(cls, v: Optional[str]) -> Optional[str]:
        """Validate bash script filename to prevent command injection.

        Only allows alphanumeric characters, hyphens, dots, and underscores in the filename.
        This prevents shell command injection when the script name is used in bash commands.
        """
        if v is not None:
            file_name = v.split("/")[-1]
            return cls._validate_pattern(
                file_name,
                REGEX_ALLOWED_CHARS,
                f"Invalid bash_script filename '{file_name}'. "
                f"Only alphanumeric characters, hyphens, dots, and underscores are allowed in the filename.",
            )

    @field_validator("command")
    @classmethod
    def validate_command(cls, v: Optional[str]) -> Optional[str]:
        """Validate command is not empty and not too long."""
        if v is not None:
            v = v.strip()
            if not v:
                raise ValueError("command cannot be empty")

            # Check line count
            line_count = len(v.splitlines())
            if line_count > 100:
                raise ValueError(
                    f"command is too long ({line_count} lines). "
                    f"Commands longer than 100 lines should use 'bash_script' instead. "
                    f"Create a separate .sh file and reference it with 'bash_script: path/to/script.sh'"
                )
        return v

    @model_validator(mode="after")
    def validate_script_fields(self) -> "YamlConfig":
        """Ensure exactly one script field is provided."""
        fields_provided = [
            self.python_script is not None,
            self.bash_script is not None,
            self.command is not None,
        ]

        if sum(fields_provided) > 1:
            raise ValueError(
                "Cannot specify multiple script fields. "
                "Choose exactly one: 'python_script', 'bash_script', or 'command'"
            )

        if sum(fields_provided) == 0:
            raise ValueError("Must specify exactly one script field: " "'python_script', 'bash_script', or 'command'")

        return self
