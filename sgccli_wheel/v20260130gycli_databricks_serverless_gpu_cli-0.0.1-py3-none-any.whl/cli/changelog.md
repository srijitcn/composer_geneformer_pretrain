# CLI Changelog

## Developer Instructions

When you make a non-trivial change to CLI add your change to the changelog as part of your PR. 
Follow the format:

CLI version 

- [Jira (as applicable)] Description

Example: 

Version 0.0.1 

- [CTNX-1583] Fix xyz


## Release Manager Instructions
When you bump up the Version in __init__.py update the future version here so that developers put there changes in the correct area. 

----------------------------------------
# Start of CLI Changelog

Version 0.0.1

- Add your changes here (ALWAYS ADD TO THE TOP)

[CNXT-1624] Validate fields and gpu num during workload submission

[CNXT-1538] Add Streaming Logs capability. 
